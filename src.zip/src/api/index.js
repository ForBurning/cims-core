import axios from '@/utils/axios'
import utils from '@/utils/utils'

/**
 * api
 */
const userId = utils.getUserInfo('id');
const userName = utils.getUserInfo('name');
const pageSize = process.env.VUE_APP_page_size * 1;

const API = {
	system: {
		//退出系统
		logout: () => axios.$post('/uc/api/account/logout'),
	},
	uc: {
		authenticatedAccount: (accountId, password)=> axios.$post('/uc/api/account/authenticatedAccount', {accountId, password: utils.md5(password)})
	},
	edm: {
		getPage: () => axios.$post('/eln/api/PCExperiment/Page', {
			pageIndex: 1,
			pageSize: pageSize
		}),
	},
	mol:{
		search: (molecule)=> axios.$post('/mol/api/mol/search', {molecule})
	},
	cims: {
		//获取物料模板详情
		getMaterielTpl: id=> axios.$get(`/cims/api/materiel/${id}`),
		// 我的领用
		fetchRequestData: (requestType) => axios.$post('/cims/api/requests/requestsInfo', {
			requesterId: userId,
			requestsInfoType: requestType,
			count: 6,
			requestType: 'chemicalReagents'
		}),
		//领用统计
		fetchRequestStatisticData: () => axios.$post('/cims/api/report/custom/requests', {
			startDate: utils.getPrevWeek(),
			endDate: utils.getcurDate(),
			createUserId: userId
		}),
		//领用统计
		fetchRequestStatisticData1: (options) => axios.$post('/cims/api/report/custom/requests', Object.assign({
			pageIndex: 1,
			pageSize: pageSize,
			createUserId: userId,
		}, options)),
		//领用审批
		fetchRequestApproveData: () => axios.$post('/cims/api/requests/requestsApprovalInfo', {
			approverId: userId,
			count: 6,
			requestType: 'chemicalReagents'
		}),
		//申购审批
		fetchApplicantApproveData: () => axios.$post('/cims/api/purchases/approvingHistory', {
			pageIndex: 1,
			pageSize: 6,
			purchaseType: 'chemicalReagents'
		}),
		//获取申购单详情
		getApplicant: (id) => axios.$get(`/cims/api/purchases/${id}`),
		//修改申购单
		editApplicant: (id, options) => axios.$put(`/cims/api/purchases/${id}`, options),
		//获取领用单详情
		getRequestApproveDetail: (id) => axios.$get(`/cims/api/requests/approvalDetails/${id}`),
		//获取审批流程
		getFlows: (id) => axios.$get(`/cims/api/orderFlow/flowNode/${id}`),
		//我的申购
		fetchApplicantData: () => axios.$post('/cims/api/purchases/page', {
			pageIndex: 1,
			pageSize: 6,
			purchasesState: 'processed',
			purchaseType: "chemicalReagents"
		}),
		//审批统计
		fetchApproveStatisticData: () => axios.$post('/cims/api/report/custom/approve', {
			startDate: utils.getPrevWeek(),
			endDate: utils.getcurDate(),
			createUserId: userId
		}),
		//审批统计
		fetchApproveStatisticData1: (options) => axios.$post('/cims/api/report/custom/approve', Object.assign({
			pageIndex: 1,
			pageSize: pageSize,
			createUserId: userId,
		}, options)),
		//通知公告
		fetchNoticeData: () => axios.$get('/cims/api/notices/noticesInfo', {
			count: 8
		}),
		//通知公告分页
		fetchNoticePageData: (options) => axios.$post('/cims/api/notices/Page', {
			pageSize: pageSize,
			...options
		}),
		//通知公告详情
		fetchNoticeDetailData: (id) => axios.$get(`/cims/api/notices/${id}`),
		//我借用的
		fetchBorrowedData: () => axios.$post('/cims/api/bottleBorrow/myBorrow', {
			count: 6,
			createUserId: userId
		}),
		//我借出的
		fetchLendData: (options) => axios.$post('/cims/api/bottleBorrow/bottleLend/myLend', {
			count: 6,
			lenderId: userId
		}),
		//试剂借出
		LendTA: (options) => axios.$post('/cims/api/bottleBorrow/bottleLend', {
			lender: userName,
			lenderId: userId,
			...options
		}),
		//TA的借用
		fetchPostLendData: () => axios.$post('/cims/api/bottleBorrow/ranking', {
			count: 6,
			requesterId: userId
		}),
		//TA的借用分页
		fetchLendPageData: (options) => axios.$post('/cims/api/bottleBorrow/rankingPage', {
			requesterId: userId,
			...options
		}),
		fetchBottleBorrowData: (id) => axios.$get(`/cims/api/bottleBorrow/${id}`),
		fetchBottleBorroRequestsData: (options) => axios.$post('/cims/api/bottleBorrow/requests', {
			pageSize: pageSize,
			requesterId: userId,
			...options
		}),
		fetchMyBorrowData: (options) => axios.$post('/cims/api/bottleBorrow/myBorrowPage', {
			pageSize: pageSize,
			createUserId: userId,
			...options
		}),
		fetchMyLendData: (options) => axios.$post('/cims/api/bottleBorrow/bottleLend/myLendPage', {
			pageSize: pageSize,
			lenderId: userId,
			...options
		}),
		confirmBottleReceive: (id) => axios.$put(`/cims/api/bottleBorrow/receive/${id}`),
		//未读消息
		fetchUnreadMessageData: () => axios.$get('/cims/api/messages/unreadCount', {
			receiverId: userId,
			messageType: ''
		}),
		//我的收藏
		fetchFavoriteData: () => axios.$get('/cims/api/favorites/count'),
		//领用车信息
		fetchShoppingCartData: () => axios.$get(`/cims/api/requests/cartCount/${userId}`),
		//molFile加载试剂
		fetchMolFileSearchData: (molecule, pageIndex = 1) => axios.$post('/cims/api/mol/search', {
			molecule,
			pageIndex
		}),
		//molFile加载试剂
		fetchSOIdsSearchData: (sourceOrganIds) => axios.$post('/cims/api/compounds/mol/search', {
			sourceOrganIds
		}),
		//可用瓶数
		fetchBottleInventoryData: (compoundIds) => axios.$post('/cims/api/compounds/manyBottleInventoryQuantity', {
			compoundIds
		}),
		//是否收藏
		fetchIsFavoriteData: (compoundIds) => axios.$post('/cims/api/favorites/hasFavorite', {
			compoundIds,
			userId
		}),
		
		//可以领用的试剂
		fetchAvailableBottleData: (options) => axios.$post(
			'/cims/api/bottles/availableBottles', {
				userId: userId,
				pageSize,
				...options
			}),
		//理论可以领用的试剂
		fetchTheoryBottleData: (compoundId, purity, bottleType, supplier, origin) => axios.$post(
			'/cims/api/bottles/theoryBottles', {
				userId: userId,
				compoundId,
				purity,
				bottleType,
				supplier,
				origin,
			}),
		//添加到领用车
		addToCart: (item, fileType) => axios.$post('/cims/api/requests/join', {
			userId: userId,
			fkID: item.ID,
			amount: 300,
			foreignKeyId: item.WarehouseId,
			chinName: item.ChinName,
			compoundId: item.CompoundId,
			requestType: fileType * 1,
			requesterId: userId,
			requester: userName,
			requestUnit: item.Unit,
			requestQuantity: item.CurrentQuantity,
			barcode: item.Barcode,
			lab: utils.getCimsInfo().UserInfo.LabName,
			phone: utils.getUserInfo('all').MobilePhone,
			warehouseId: item.WarehouseId
		}),
		//化合物详情
		getCompound: (materielId) => axios.$post('/cims/api/compounds/detail', {
			userId,
			materielId
		}),
		//试剂详情
		getReagent: (barcode) => axios.$post('/cims/api/bottles/detail', {
			requesterId: userId,
			barcode
		}),
		//物料详情
		getMateriel: (MaterielNumber) => axios.$get(`/cims/api/materiel/detail/${MaterielNumber}`),
		//物料详情
		getMaterielById: (id) => axios.$get(`/cims/api/materiel/${id}`),
		//试剂领用-全部
		fetchRequestTab1: (options) => axios.$post('/cims/api/requests/history', Object.assign(options, {
			pageSize: pageSize,
			requesterId: userId,
		})),
		//试剂领用-待审批
		fetchRequestTab2: (options) => axios.$post('/cims/api/requests/approvingHistory', Object.assign(options, {
			pageSize: pageSize,
			requesterId: userId,
		})),
		//试剂领用-待签收
		fetchRequestTab3: (options) => axios.$post('/cims/api/requests/receivingHistory', Object.assign(options, {
			pageSize: pageSize,
			requesterId: userId,
		})),
		//试剂领用-已拒绝
		fetchRequestTab4: (options) => axios.$post('/cims/api/requests/refusedHistory', Object.assign(options, {
			pageSize: pageSize,
			requesterId: userId,
		})),
		//试剂领用-已签收
		fetchRequestTab5: (options) => axios.$post('/cims/api/requests/receiveHistory', Object.assign(options, {
			pageSize: pageSize,
			requesterId: userId,
		})),
		//试剂领用-已退库
		fetchRequestTab6: (options) => axios.$post('/cims/api/requests/returnStockHistory', Object.assign(options, {
			pageSize: pageSize,
			requesterId: userId,
		})),
		//试剂领用-已报废
		fetchRequestTab7: (options) => axios.$post('/cims/api/requests/scrapHistory', Object.assign(options, {
			pageSize: pageSize,
			requesterId: userId,
		})),
		//领用审批
		fetchRequestApproveTab1: (options) => axios.$post('/cims/api/requests/approval', Object.assign(options, {
			pageSize: pageSize,
			approverId: userId
		})),
		//领用审批
		fetchRequestApproveTab2: (options) => axios.$post('/cims/api/requests/approvalHistory', Object.assign(options, {
			pageSize: pageSize,
			approverId: userId,
		})),
		//领用审批
		fetchRequestApproveTab3: (options) => axios.$post('/cims/api/requests/approvalRefusedHistory', Object.assign(options, {
			pageSize: pageSize,
			approverId: userId,
		})),
		//领用审批-批量同意
		requestApproveYes: (options) => axios.$post('/cims/api/requests/approve', {
			approveList: options
		}),
		//领用审批-批量拒绝
		requestApproveNo: (options) => axios.$post('/cims/api/requests/refuse', {
			approveList: options
		}),
		//我的申购
		fetchMyApplicantData: (options) => axios.$post('/cims/api/purchases/page', Object.assign(options, {
			pageSize: pageSize
		})),
		//我的申购-已拒绝
		fetchMyApplicantRefuseData: (options) => axios.$post('/cims/api/purchases/refused/page', Object.assign(options, {
			pageSize: pageSize
		})),
		//我的申购审批-待审批
		fetchMyApplicantApproveDataTab1: (options) => axios.$post('/cims/api/purchases/approvingHistory', Object.assign(
			options, {
				pageSize: pageSize
			})),
		//我的申购审批-已审批
		fetchMyApplicantApproveDataTab2: (options) => axios.$post('/cims/api/purchases/approvedHistory', Object.assign(
			options, {
				pageSize: pageSize
			})),
		//我的申购审批-已拒绝
		fetchMyApplicantApproveDataTab3: (options) => axios.$post('/cims/api/purchases/refusedHistory', Object.assign(
			options, {
				pageSize: pageSize
			})),
		//申购审批-批量同意
		applicantApproveYes: (options) => axios.$post('/cims/api/purchases/approve', {
			approveList: options.map(item => {
				item.approveUser = userId;
				return item
			})
		}),
		//申购审批-批量拒绝
		applicantApproveNo: (options) => axios.$post('/cims/api/purchases/refuse', {
			approveList: options.map(item => {
				item.approveUser = userId;
				return item
			})
		}),
		//我的申购-批量提交
		batchSubmitApplicant: (purchasesCommitList) => axios.$post('/cims/api/purchases/commit', {
			purchasesCommitList
		}),
		//我的申购-批量删除
		batchDeleteApplicant: (list) => axios.$delete('/cims/api/purchases', {
			data: list
		}),
		//我的申购-批量撤回
		batchRecallApplicant: (options) => axios.$post('/cims/api/purchases/revoke', options),
		//申购单审批详情
		getPurchase: (id) => axios.$get(`/cims/api/purchases/approveDetail/${id}`),
		//申购单详情
		getBttlesInventory: (options) => axios.$post('/cims/api/bottles/inventory', options),
		//根据化合物，获取已经审批通过并且是未到货状态的采购信息
		fetchPurchasesCompoundArriveData: (options) => axios.$post('/cims/api/purchases/compound/arrive', options),
		//申购单详情
		getShoppingCart: (options) => axios.$get(`/cims/api/requests/cart/${userId}`, options),
		//cims配置信息
		getOrganizationConfig: (code) => axios.$get(`/cims/api/organizationConfig/${code}`),
		//cims组织配置信息
		getSystemConfig: (code) => axios.$get(`/cims/api/organizationConfig/configValue/${code}`),
		//删除领用车
		deleteShoppingCart: (options) => axios.$delete('/cims/api/requests', {
			data: options
		}),
		//提交领用车
		submitShoppingCart: (options) => axios.$post('/cims/api/requests/commit', {
			requesterId: userId,
			...options
		}),
		//领用详情
		fetchRequestDetail: (id) => axios.$get(`/cims/api/requests/requestsDetails/${id}`),
		//领用详情
		fetchRequestDocDetail: (id, requestType) => axios.$post(`/cims/api/docFiles/requestsDetails`, {
			requestCode: id,
			requestType: requestType
		}),
		//加载字典
		fetchDicItem: (dic) => axios.$get(`/cims/api/dictionary/dicItem/${dic}`),
		//加载项目
		fetchProjects: () => axios.$get('/cims/api/projects/my'),
		//加载项目
		fetchMyProjects: () => axios.$get('/cims/api/projects/my'),
		//提交领用单
		submitApplicant: (options) => axios.$post('/cims/api/purchases/join', options),
		//提交领用单
		submitDocFiles: (options) => axios.$post('/cims/api/requests/docFilesCommit', options),
		//提交spz
		submitSpzFiles: (options) => axios.$post('/cims/api/requests/ColumnsCommit', options),
		//玻璃耗材-报废申请
		submitConsumablesScraps: (options) => axios.$post('/cims/api/consumablesScraps', Object.assign(options, {
			wastager: userName,
			applicant: userName,
			applicantId: userId,
			scrapType: 1
		})),
		//我的收藏
		fetchFavoriteData: (options) => axios.$post('/cims/api/favorites/page', {
			pageSize,
			createUserId: userId,
			...options
		}),
		//我的收藏
		getFavoriteCount: () => axios.$get('/cims/api/favorites/count'),
		//我的消息
		fetchMessageData: (options) => axios.$post('/cims/api/messages/page', Object.assign(options, {
			pageSize: pageSize,
			receiverId: userId,
		})),
		//设为已读
		batchReadMessage: (options) => axios.$put('/cims/api/messages/setAsRead', options),
		//批量删除
		batchDeleteMessage: (options) => axios.$delete('/cims/api/messages', {
			data: options
		}),
		//我的申购
		fetchPurchaseTab1: (options) => axios.$post('/cims/api/purchases/processedPage', Object.assign(options, {
			pageSize: pageSize,
		})),
		fetchPurchaseTab2: (options) => axios.$post('/cims/api/purchases/pendingPage', Object.assign(options, {
			pageSize: pageSize,
		})),
		//cas校验
		isCasExist: (casNumber) => axios.$get(`/cims/api/compounds/isExists/${casNumber}`),
		//根据cas号获取单个化合物资源对象
		findCompoundSourceByCas: (casNumber) => axios.$get(`/cims/api/compoundSource/findCompoundSource/${casNumber}`),
		//我的申购-选择物料
		fetchMaterielsPageData: (options) => axios.$post('/cims/api/materiel/page', {
			pageSize,
			...options
		}),
		purchasesHandle: (options) => axios.$post('/cims/api/purchases/handle', Object.assign(options, {
			purchaser: userName,
		})),
		//采购单--批量接收
		purchasesUpdateHandle: (options) => axios.$post('/cims/api/purchases/purchasesUpdate', options),
		//采购单--批量收货
		purchasesReceivedHandle: (options) => axios.$post('/cims/api/purchases/arrive', {
			userName,
			...options
		}),
		//采购单--结算
		settleAccountsHandle: (options) => axios.$post('/cims/api/purchases/settleAccounts', options),
		//采购单-批量导出
		batchExportPurchase: (options) => axios.$post('/cims/api/purchases/export', options),

		tkOperation: (options) => axios.$post('/cims/api/returnStockApplication/batchReturnStock', {
			applicant: userName,
			...options
		}),
		bfOperation: (options) => axios.$post('/cims/api/scrapApplication/batchScrap', {
			applicant: userName,
			...options
		}),
		cfOperation: (options) => axios.$post('/cims/api/requests/batchStore', options),
		//发布借用-搜索化合物
		fetchBorrowCanViewRequestHistoryData: (options) => axios.$post('/cims/api/compounds/page', {
			pageSize: pageSize,
			...options
		}),
		//发布借用-化合物领用记录
		fetchDeliveredRequestsData: (options) => axios.$post('/cims/api/requests/deliveredRequests/', options),
		//
		postBorrowInfo: (options) => axios.$post('/cims/api/bottleBorrow/', {
			createUser: userName,
			createUserId: userId,
			...options
		}),
		//加载物料类型
		fetchMaterielTypesData: () => axios.$post('/cims/api/materielCustomTemplate/templates'),
		//加载仓库
		fetchWarehousesData: () => axios.$get(`/cims/api/warehouses/users/${userId}`),
		//关键字搜索物料
		fetchMaterielsData: (options) => axios.$post('/cims/api/materiel/search', {
			pageSize: 30,
			...options
		}),
		//是否收藏检验
		isFavoritCheck: (materielIds) => axios.$post('/cims/api/favorites/hasFavorite', {
			userId,
			materielIds
		}),
		//添加到收藏
		addToFavorite: (options) => axios.$post('/cims/api/favorites', {
			createUserId: userId,
			...options
		}),
		//取消收藏
		cancelFavorite: (id) => axios.$delete(`/cims/api/Favorites/${id}/${userId}`),
		//提交领用车
		submitRequest: (options) => axios.$post('/cims/api/requests/join', {
			requester: userName,
			requesterId: userId,
			userId,
			...options
		}),
		//提交领用车
		fetchRequestHistory: (options) => axios.$post('/cims/api/requests/latest', {
			pageSize,
			...options
		}),
		//加载物料类型
		fetchMaterielType: () => axios.$post('/cims/api/materielCustomTemplate/templates'),
		//我的项目-管理员
		fetchProjectManagerData: (options) => axios.$post('/cims/api/projects/manage/page', {
			pageSize,
			...options
		}),
		//我的项目-普通成员
		fetchProjectData: (options) => axios.$post('/cims/api/projects/page', {
			pageSize,
			...options
		}),
		//我的项目-获取当前组织下的用户列表
		fetchProjectMemberData: (options) => axios.$post('/cims/api/users/page', {
			pageSize,
			...options
		}),
		//我的项目-新建项目
		newProject: (options) => axios.$post('/cims/api/projects', {
			createUserId: userId,
			createUser: userName,
			...options
		}),
		//我的项目-删除项目
		deleteProject: (id) => axios.$delete('/cims/api/projects', {
			data: [id]
		}),
		//我的项目-编辑项目
		editProject: (id, options) => axios.$put(`/cims/api/projects/${id}`, options),
		//我的项目-项目详情
		fetchProject: (id) => axios.$get(`/cims/api/projects/${id}`),
		//我的项目-启用禁用项目
		toggleProjectState: (options) => axios.$post('/cims/api/projects/enable', options),
		//废弃收集-配置项
		fetchChemicalConfigData: () => axios.$get('/cims/api/chemicalWasteType/findAllType'),
		//废弃收集-新增
		addChemicalData: (options) => axios.$post('/cims/api/chemicalWaste', {
			createUserId: userId,
			createUser: userName,
			...options
		}),
		//废弃收集-编辑
		editChemicalData: (id, options) => axios.$put(`/cims/api/chemicalWaste/${id}`, {
			createUserId: userId,
			createUser: userName,
			...options
		}),
		//废弃分页
		fetchWasteData: (options) => axios.$post('/cims/api/chemicalWaste/page', {
			pageSize,
			...options
		}),
		//废弃分页-删除
		deleteWaste: (id) => axios.$delete('/cims/api/chemicalWaste', {
			data: [id]
		}),
		//废弃分页-获取详情
		getWaste: (id) => axios.$get(`/cims/api/chemicalWaste/${id}`),
	}
}

export default API
