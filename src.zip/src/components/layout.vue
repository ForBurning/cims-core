<template>
<div class="page">
    <Layout>
        <div class="header">
            <div class="nav">
                <Row type="flex" justify="end" class="code-row-bg view-section">
                    <Col>
                    <Dropdown class="menu" placement="bottom-start" id="userCenter">
                        <a href="javascript:void(0)">
                            Hi：
                            <span class="user-name">{{userName}}</span>
                            <Icon type="ios-arrow-down"></Icon>
                        </a>
                        <DropdownMenu slot="list">
                            <Row>
                                <Col span="8">
                                <img class="user-pic" :src="`${appPrefix + userPic}`" />
                                </Col>
                                <Col span="16">
                                <div class="name">{{userName}}</div>
                                <div class="user-center">
                                    <a :href="userCenter">{{$t('nav.person')}}</a>
                                    <a :href="appPrefix + '/message'">
                                        {{$t('nav.message')}}
                                        <span>{{unreadMessageCount}}</span>
                                    </a>
                                </div>
                                </Col>
                            </Row>
                            <div class="menu-title">{{$t('nav.my')}}</div>
                            <Row class="menu-item" type="flex">
                                <Col v-if="roles.REQUEST">
                                <a :href="appPrefix + '/request'">{{$t('nav.request')}}</a>
                                </Col>
                                <Col v-if="roles.APPLY">
                                <a :href="appPrefix + '/applicant'">{{$t('nav.applicant')}}</a>
                                </Col>
                                <Col v-if="roles.PURCHASE">
                                <a :href="appPrefix + '/purchase'">{{$t('nav.purchase')}}</a>
                                </Col>
                                <Col>
                                <a :href="appPrefix + '/projects'">{{$t('nav.projects')}}</a>
                                </Col>
                                <Col>
                                <a :href="appPrefix + '/favorite'">{{$t('nav.favorite')}}</a>
                                </Col>
                            </Row>
                            <div class="menu-title" v-if="roles.ORDERAPPROVE || roles.APPLYAPPROVE">
                                <i class="audit-small-icon"></i>
                                {{$t('nav.approve')}}
                            </div>
                            <Row class="menu-item" type="flex">
                                <Col v-if="roles.ORDERAPPROVE">
                                <a :href="appPrefix + '/requestApprove'">{{$t('nav.requestApprove')}}</a>
                                </Col>
                                <Col v-if="roles.APPLYAPPROVE">
                                <a :href="appPrefix + '/applicantApprove'">{{$t('nav.applicantApprove')}}</a>
                                </Col>
                            </Row>

                            <div class="menu-title">
                                <i class="borrow-small-icon"></i>
                                {{$t('nav.borrow')}}
                            </div>
                            <Row class="menu-item" type="flex">
                                <Col>
                                <a :href="appPrefix + '/borrow'">{{$t('nav.myBorrow')}}</a>
                                </Col>
                                <Col>
                                <a :href="appPrefix + '/borrow/post'">{{$t('nav.post')}}</a>
                                </Col>
                            </Row>

                            <div class="menu-title" v-if="roles.REQUEST || roles.ORDERAPPROVE">
                                <i class="static-small-icon"></i>
                                {{$t('nav.statistic')}}
                            </div>
                            <Row class="menu-item" type="flex">
                                <Col v-if="roles.REQUEST">
                                <a :href="appPrefix + '/requestStatistic'">{{$t('nav.requestStatistic')}}</a>
                                </Col>
                                <Col v-if="roles.ORDERAPPROVE">
                                <a :href="appPrefix + '/approveStatistic'">{{$t('nav.approveStatistic')}}</a>
                                </Col>
                            </Row>
                        </DropdownMenu>
                    </Dropdown>
                    </Col>
                    <Col class="logout">
                    <div @click="logout">{{$t('nav.logout')}}</div>
                    </Col>
                    <Col>
                    <i class="waste-icon"></i>
                    <a :href="appPrefix + '/waste'" style="line-height: 34px;color: #999;">{{$t('nav.waste')}}</a>
                    </Col>
                </Row>
            </div>
            <div class="search-wrapper">
                <div class="search" id="search" :class="{fixed: fixed}">
                    <Row class="view-section" type="flex" justify="space-between">
                        <Col>
                        <a :href="appPrefix">
                            <img src="@/assets/img/logo.png" class="logo" />
                        </a>
                        </Col>
                        <Col class="flex-1">
                        <Row type="flex" class="search-section" id="searchSection">
                            <Col class="flex-1">
                            <input v-model="keywords" autocomplete="off" spellcheck="false" type="text" :placeholder="$t('nav.search')" class="ivu-input ivu-input-default search-input" @keyup.enter="search" />
                            </Col>
                            <Col>
                            <Dropdown trigger="click" placement="bottom-end" class="ketcher-switch">
                                <a href="javascript:void(0)" class="search-panel"></a>
                                <DropdownMenu slot="list">
                                    <iframe :src="appPrefix + '/ketcher'" class="ketcher-panel" id="ketcher-id"></iframe>
                                    <div class="clear"></div>
                                    <div class="ketcher-search-btn" @click="subSearch">
                                        <i></i>
                                        {{$t('nav.structSearch')}}
                                    </div>
                                </DropdownMenu>
                            </Dropdown>
                            </Col>
                            <Col>
                            <div class="ivu-input-group-append ilab-input-search ilab-btn" @click="search">{{$t('btn.search')}}</div>
                            </Col>
                        </Row>
                        </Col>
                        <Col>
                        <a :href="appPrefix + '/cart'" class="shop-cart">
                            <i class="cart-ico"></i>
                            <span>{{$t('nav.cart')}}</span>
                            <span id="cart-number" v-if="shoppingCartCount>0">({{shoppingCartCount}})</span>
                        </a>
                        </Col>
                    </Row>
                </div>
            </div>
            <div class="breadcrumb" v-if="breadcrumbs.length">
                <div class="view-section">
                    {{$t('nav.location')}}：
                    <span>
                        <a :href="appPrefix">{{$t('nav.home')}}</a>
                    </span>
                    <span v-for="item in breadcrumbs" :key="item.txt" :value="item.href">
                        <Icon type="ios-arrow-forward" />
                        <a :href="appPrefix + item.href" v-if="item.href">{{item.txt}}</a>
                        <span v-else>{{item.txt}}</span>
                    </span>
                </div>
            </div>
        </div>
        <Content class="view-section">
            <slot name="content" ref="content"></slot>
            <div id="fixed-slider-menu">
                <div class="menu-item">
                    <a :href="appPrefix + '/favorite'">
                        <Icon type="md-star-outline" />
                    </a>
                    <a :href="appPrefix + '/favorite'" class="menu-item-tip">{{$t('nav.myFavorite')}}</a>
                    <span class="sub-num" v-if="favoriteCount">{{favoriteCount}}</span>
                </div>
                <div class="menu-item my-cart transition" id="sliderCart">
                    <a :href="appPrefix + '/cart'">
                        <img src="../assets/img/sliderC.png" />
                    </a>
                    <a class="menu-item-tip" :href="appPrefix + '/cart'">{{$t('nav.cart')}}</a>
                    <span class="sub-num" v-if="shoppingCartCount>0">{{shoppingCartCount}}</span>
                </div>
                <div class="menu-item">
                    <a :href="appPrefix + '/message'">
                        <img src="../assets/img/sliderM.png" />
                    </a>
                    <a :href="appPrefix + '/message'" class="menu-item-tip">{{$t('nav.myMessage')}}</a>
                    <span class="sub-num" v-if="unreadMessageCount > 0">{{unreadMessageCount}}</span>
                </div>
            </div>
        </Content>
        <Footer>
            <Row type="flex" class="view-section">
                <Col span="12">© 2016 - 2019 苏州创腾软件有限公司</Col>
                <Col span="12">物料信息管理平台</Col>
            </Row>
        </Footer>
    </Layout>
    <valid-login ref="modal"></valid-login>
    <no-auth :no-auth="noAuth"></no-auth>
</div>
</template>

<script>
import validLogin from "@/components/validLogin";
import noAuth from "@/components/noAuth";
import utils from "@/utils/utils";
import api from "@/api";
import moment from "moment";
import bus from "@/utils/bus";

export default {
    name: "layout",
    components: {
        validLogin,
        noAuth
    },
    props: {
        breadcrumbs: {
            type: Array,
            default () {
                return [];
            }
        }
    },
    data() {
        return {
            appPrefix: process.env.VUE_APP_prefix,
            userCenter: process.env.VUE_APP_user_center,
            userName: utils.getUserInfo("name"),
            userPic: utils.getUcInfo().AccountInfo.Photo,
            unreadMessageCount: 0,
            favoriteCount: 0,
            keywords: "",
            fileType: "0",
            shoppingCartCount: 0,
            roles: utils.getCimsInfo().RoleCodes,
            fixed: false,
            noAuth:{
                modal: false,
                message: ''
            }
        };
    },
    methods: {
        /**
         * @description 获取未读消息数据
         */
        async fetchUnreadMessageData() {
            const resp = await api.cims.fetchUnreadMessageData();
            if (resp.code == process.env.VUE_APP_code) {
                this.unreadMessageCount = resp.response;
            }
        },
        /**
         * @description 获取我的收藏数据
         */
        async getFavoriteCount() {
            const resp = await api.cims.getFavoriteCount();
            if (resp.code == process.env.VUE_APP_code) {
                this.favoriteCount = resp.response;
            }
        },
        /**
         * @description 获取领用车数据
         */
        async fetchShoppingCartData() {
            const resp = await api.cims.fetchShoppingCartData();
            if (resp.code == process.env.VUE_APP_code) {
                this.shoppingCartCount = resp.response;
            }
        },
        /**
         * @description 领用车数量+1
         */
        async setFavoriteCount(count = 1) {
            await utils.sleep(900);
            this.favoriteCount += count;
        },
        /**
         * @description 领用车数量+1
         */
        async setCartCount(count = 1) {
            await utils.sleep(900);
            this.shoppingCartCount += count;
        },
        /**
         * @description 退出系统
         */
        async logout() {
            const resp = await api.system.logout();
            if (resp.code == process.env.VUE_APP_code) {
                utils.turnToLoginPage(true);
            } else {
                this.$Message.error(resp.message);
            }
        },
        /**
         * @description 全文搜索
         */
        search() {
            if (this.keywords) {
                window.location.href = `${this.appPrefix}/search?keywords=${this.keywords}`;
            } else {
                window.location.href = `${this.appPrefix}/search`;
            }
        },
        /**
         * @description 结构式搜索
         */
        async subSearch() {
            let molFile = utils.getMolfile();
            if (molFile) {
                const resp = await api.mol.search(molFile);
                if (resp.code == process.env.VUE_APP_code) {
                    this.$session.set("materielIds", resp.response);
                    window.location.href = `${this.appPrefix}/search?molSerch=true`;
                } else {
                    this.$Message.error(resp.message);
                }
            }
        },
        bodyScroll() {
            window.onscroll = () => {
                this.fixed =
                    (document.documentElement.scrollTop || document.body.scrollTop) > 34;
            };
        },
        noActionLockScreen() {
            const ucCookie = utils.cookie.get(process.env.VUE_APP_uc_cookie);
            if (ucCookie) {
                const newTime = moment().valueOf(),
                    lastActionTime = utils.cookie.get(process.env.VUE_APP_lastActionTime),
                    screenLockTime = ucCookie.NoActionLogout * 60 * 1000;
                if (newTime - lastActionTime > screenLockTime) {
                    this.$refs.modal.show();
                } else {
                    this.$refs.modal.hide();
                }
            }
        },
        screenLock() {
            const ucCookie = utils.cookie.get(process.env.VUE_APP_uc_cookie);
            if (ucCookie) {
                this.noActionLockScreen();

                window.addEventListener("mousemove", () => {
                    if (this.$refs.modal.isHide()) {
                        utils.cookie.set(process.env.VUE_APP_lastActionTime, moment().valueOf(), 1);
                    }
                });

                setInterval(() => {
                    const ucCookie = utils.cookie.get(process.env.VUE_APP_uc_cookie);
                    if (ucCookie) {
                        this.noActionLockScreen();
                    } else {
                        utils.turnToLoginPage(true);
                    }
                }, 1000);
            }
        },
        busEvent(){
            bus.$on('boo', (noAuth)=>{
                Object.assign(this.noAuth, noAuth)
            })
        }
    },
    created() {
        this.keywords = decodeURIComponent(utils.getParams("keywords"));
    },
    mounted() {
        this.busEvent();
        this.bodyScroll();
        this.fetchUnreadMessageData();
        this.fetchShoppingCartData();
        this.getFavoriteCount();
        this.screenLock();
    }
};
</script>

<style lang="less" scoped>
@-moz-keyframes email-animation {
    0% {
        color: #999999;
    }

    40% {
        color: #f96100;
    }

    100% {
        color: #f96100;
    }
}

@keyframes email-animation {
    0% {
        color: #999999;
    }

    40% {
        color: #f96100;
    }

    100% {
        color: #f96100;
    }
}

@-webkit-keyframes email-animation {
    0% {
        color: #999999;
    }

    40% {
        color: #f96100;
    }

    100% {
        color: #f96100;
    }
}

.page {
    .header {
        .nav {
            width: 100%;
            height: 34px;
            background: #f8f8f8;
            border-bottom: 1px solid #e9e9e9;

            >div {
                background: #f8f8f8;

                >div {
                    font-size: 15px;
                    color: #999;
                    cursor: pointer;
                }

                .menu {
                    color: #999;
                    margin-right: 6px;

                    /deep/ .ivu-dropdown-rel {
                        padding: 0 12px;
                        line-height: 34px;

                        a {
                            color: #999;
                        }

                        .user-name {
                            display: inline-block;
                            padding-left: 4px;
                        }
                    }

                    /deep/ .ivu-select-dropdown {
                        margin: 0;
                        padding: 10px 15px;
                        border-radius: 0;
                        width: 250px;

                        .ivu-dropdown-menu {
                            >.ivu-row {
                                margin: 0 0 10px 5px;
                            }
                        }

                        .user-pic {
                            width: 50px;
                            height: 50px;
                            border-radius: 100%;
                        }

                        .name {
                            color: #9e9e9e;
                            font-size: 14px;
                            font-weight: bold;
                            color: #9e9e9e;
                            line-height: 28px;
                            margin-top: 7px;
                        }

                        .user-center {
                            text-align: left;
                            line-height: 16px;

                            a {
                                color: #999;
                                display: inline-block;
                                margin-right: 5px;
                            }

                            span {
                                color: #ef0216;
                            }
                        }

                        a:hover {
                            text-decoration: underline;
                        }

                        .menu-title {
                            color: #686868;
                            font-weight: bold;
                            margin: 0 0 10px 5px;
                            line-height: 16px;

                            .audit-small-icon {
                                display: inline-block;
                                background: url(../assets/img/index_icon.png) -71px -7px no-repeat;
                                width: 17px;
                                height: 19px;
                                background-position: -72px -33px;
                                top: -2px;
                                float: left;
                                margin-right: 1px;
                                position: relative;
                            }

                            .static-small-icon {
                                display: inline-block;
                                width: 18px;
                                height: 20px;
                                background: url(../assets/img/index_icon.png) -8px -35px no-repeat;
                                position: relative;
                                top: 1px;
                                float: left;
                                margin-right: 1px;
                            }

                            .borrow-small-icon {
                                display: inline-block;
                                background: url(../assets/img/index_icon.png) -38px -8px no-repeat;
                                position: relative;
                                width: 18px;
                                height: 20px;
                                background-position: -40px -34px;
                                float: left;
                            }
                        }

                        .menu-item {
                            color: #9e9e9e;
                            margin: 0 0 10px 5px;

                            .ivu-col {
                                flex: 1;
                            }

                            a {
                                color: #999;
                            }
                        }
                    }

                    &:hover {
                        background-color: #ffffff;

                        .ivu-dropdown-rel {
                            a {
                                color: #1388ff;
                            }
                        }
                    }
                }

                .logout {
                    margin-right: 12px;
                    line-height: 34px;

                    &:hover {
                        color: #ff0000;
                    }
                }

                .waste-icon {
                    display: inline-block;
                    width: 20px;
                    height: 20px;
                    background: url(../assets/img/index_icon.png) -230px -30px no-repeat;
                    position: relative;
                    top: 3px;
                    margin-right: 2px;

                    +a:hover {
                        text-decoration: underline;
                    }
                }

                .ivu-icon-md-mail {
                    font-size: 23px;
                    line-height: 34px;

                    &.active {
                        -moz-animation: email-animation 1s ease-in 0.5s infinite;
                        -o-animation: email-animation 1s ease-in 0.5s infinite;
                        animation: email-animation 1s ease-in 0.5s infinite;
                        -webkit-animation: email-animation 1s ease-in 0.5s infinite;
                    }
                }

                .liquor-collection {
                    margin-left: 12px;
                    line-height: 34px;

                    a {
                        color: #999;
                    }

                    i {
                        display: inline-block;
                        width: 20px;
                        height: 20px;
                        background: url(../assets/img/index_icon.png) -230px -30px no-repeat;
                        position: relative;
                        top: 3px;
                        margin-right: 2px;
                    }
                }
            }
        }
    }

    .search-wrapper {
        height: 143px;
        background-color: #ffffff;
    }

    .search {
        height: 143px;
        border-bottom: 1px solid #e9e9e9;
        background-color: #ffffff;
        position: static;
        left: 0;
        right: 0;
        top: 0;
        z-index: 10;

        &.fixed {
            position: fixed;
            box-shadow: 0 0 5px #888;
        }

        .logo {
            margin: 28px 30px 0 0;
        }

        .view-section {
            >.ivu-col:first-child {
                width: 296px;
            }

            >.ivu-col:last-child {
                width: 170px;
            }
        }

        .search-section {
            margin-top: 38px;
            border: 2px solid #1388ff;
            height: 44px;

            >.ivu-col:last-child {
                .ivu-input-search {
                    width: 140px;
                    line-height: 40px;
                    font-size: 16px;
                }
            }

            .ilab-input-search {
                width: 140px;
                line-height: 41px;
                font-size: 16px;
                border-radius: 0;
                border: none;
                padding: 0;
            }

            .search-input {
                height: 38px;
                border: none;
                border-radius: 0;
                font-size: 15px;
                color: #333333bf;
                margin: 1px;

                &:focus {
                    outline: none;
                    border: none;
                    box-shadow: none;
                }
            }

            .ketcher-switch {
                height: 40px;

                .search-panel {
                    display: table-cell;
                    width: 40px;
                    height: 37px;
                    background: -228px 2px url(../assets/img/search.png) no-repeat;
                    cursor: pointer;
                    z-index: 1;
                    position: relative;
                    top: 1px;
                }

                /deep/ .ivu-select-dropdown {
                    width: 592px;
                    height: 530px;
                    border: 2px solid #1388ff;
                    border-top: none;
                    padding-bottom: 18px;
                    border-radius: 0;
                    padding: 1px;
                }

                .ketcher-panel {
                    width: 100%;
                    height: 456px;
                    border: none;
                    border-bottom: 1px solid #e4e5e9;
                }

                .ketcher-search-btn {
                    padding: 0 12px;
                    width: 130px;
                    height: 36px;
                    font-size: 16px;
                    line-height: 36px;
                    border: 1px solid #3288ff;
                    color: #ffffff;
                    background-color: #1388ff;
                    cursor: pointer;
                    margin: 10px auto;

                    i {
                        display: inline-block;
                        width: 19px;
                        height: 22px;
                        background: -331px -107px url(../assets/img/search.png) no-repeat;
                        position: relative;
                        top: 4px;
                        margin-right: 5px;
                    }
                }
            }
        }

        .shop-cart {
            background: #f9f9f9;
            border: 1px solid #e5e5e5;
            line-height: 42px;
            font-size: 15px;
            width: 140px;
            margin-top: 38px;
            color: #333;
            text-align: center;
            float: right;

            .cart-ico {
                position: relative;
                margin-right: 5px;
                top: -3px;
                display: inline-block;
                width: 28px;
                height: 24px;
                vertical-align: middle;
                background: url(../assets/img/ico.png) -29px 0;
            }

            &:hover {
                color: #1388fe;

                .cart-ico {
                    background-position-x: -59px;
                }
            }
        }
    }

    .breadcrumb {
        line-height: 44px;
        font-size: 16px;
        border-bottom: 1px solid #e9e9e9;
        background-color: #f9f9f9;
        color: #999999;

        a {
            color: #3497ea;
        }

        .ivu-icon-ios-arrow-forward {
            padding: 0 6px;
        }
    }

    .ivu-layout-footer {
        border-top: 1px solid #e9e9e9;
        padding: 0;

        .ivu-row-flex {
            font-size: 15px;
            line-height: 50px;

            .ivu-col:last-child {
                text-align: right;
            }
        }
    }
}
</style>
