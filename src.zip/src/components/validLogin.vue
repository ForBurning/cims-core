<template>
<div @keyup.enter="submit">
    <Modal :transfer="false" v-model="modal" :width="width" :mask-closable="false" :closable="false" :title="$t('page.screenLock')">
        <Form ref="form" :model="form" :rules="rule" :label-width="75">
            <Form-item :label="$t('page.psd')" prop="password">
                <Input type="password" :placeholder="$t('message.placeholder', [$t('page.psd')])" v-model="form.password"></Input>
            </Form-item>
        </Form>
        <div slot="footer">
            <Button type="text" @click="logout">{{$t('nav.logout')}}</Button>
            <Button type="primary" :loading="loading" @click="submit">
                <span v-if="status === 1">{{btnTxt}}</span>
                <span v-else-if="status === 2">{{btnTxt}}...</span>
                <span v-else>
                    <Icon type="checkmark-round"></Icon>
                    {{btnTxt}}{{$t('btn.success')}}
                </span>
            </Button>
        </div>
    </Modal>
</div>
</template>

<script>
import api from "@/api";
import utils from "@/utils/utils";
export default {
    name: "modalComponent",
    props: {
        title: {
            type: String,
            default () {
                return this.$i18n.t('columns.title');
            }
        },
        width: {
            type: Number,
            default: 520
        },
        btnTxt: {
            type: String,
            default () {
                return this.$i18n.t('nav.login');
            }
        }
    },
    data() {
        return {
            form: {
                password: ""
            },
            rule: {
                password: [{
                    required: true,
                    message: this.$i18n.t('message.placeholder', [this.$i18n.t('page.psd')]),
                    trigger: "change"
                }]
            },
            loading: false,
            modal: false,
            status: 1 //1:未提交 2:提交中 3:提交完成
        };
    },
    methods: {
        isShow() {
            return this.modal === true;
        },
        isHide() {
            return this.modal === false;
        },
        show() {
            if (!this.modal) {
                this.$refs.form.resetFields();
                this.modal = true;
            }
        },
        hide() {
            this.modal = false;
        },
        //表单提交
        async submit() {
            const valid = await this.$refs.form.validate();
            if (valid) {
                const cookie = utils.getUcInfo();
                this.committing();
                const resp = await api.uc.authenticatedAccount(cookie.AccountInfo.ID, this.form.password);
                this.finish(resp);
            }
        },
        //提交中
        committing() {
            this.loading = true;
            this.status = 2;
        },
        //操作完成时，关闭模态框
        close(cb) {
            setTimeout(() => {
                this.loading = false;
                this.status = 3;
                setTimeout(() => this.reset(cb), 400);
            }, 1500);
        },
        //状态还原
        reset(cb) {
            this.modal = false;
            setTimeout(() => {
                this.loading = false;
                this.status = 1;
                typeof cb === "function" && cb();
            }, 400);
        },
        //处理失败
        stop() {
            setTimeout(() => {
                this.loading = false;
                this.status = 1;
            }, 1000);
        },
        //事件处理完成回到
        finish(resp, cb) {
            if (resp.code == process.env.VUE_APP_code) {
                utils.cookie.set(process.env.VUE_APP_lastActionTime, new Date().getTime());
                this.close(cb);
            } else {
                this.stop();
            }
        },
        async logout() {
            const resp = await api.system.logout();
            if (resp.code == process.env.VUE_APP_code) {
                utils.cookie.set(process.env.VUE_APP_lastActionTime, new Date().getTime());
                this.modal = false;
                utils.turnToLoginPage(true);
            }
        }
    }
};
</script>
