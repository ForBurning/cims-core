<template>
<div>
    <Modal v-model="modal" :width="width" :footer-hide="footerHide" :title="title">
        <slot></slot>
        <div slot="footer">
            <Button type="primary" :loading="loading" @click="submit">
                <span v-if="status === 1">{{confirmTxt}}</span>
                <span v-else-if="status === 2">{{confirmTxt}}...</span>
                <span v-else>
                    <Icon type="checkmark-round"></Icon>{{confirmTxt}}{{$t('btn.success')}}
                </span>
            </Button>
            <Button type="text" @click="hide">{{cancelTxt}}</Button>
        </div>
    </Modal>
</div>
</template>

<script>
export default {
    name: "modalComponent",
    props: {
        title: {
            type: String,
            default() {
                return this.$t("columns.title");
            }
        },
        width: {
            type: Number,
            default: 520
        },
        width: {
            type: Number,
            default: 520
        },
        footerHide: {
            type: Boolean,
            default: false
        },
        confirmTxt: {
            type: String,
            default(){
                return this.$t("btn.defaultConfirm");
            }
        },
        cancelTxt: {
            type: String,
            default(){
                return this.$t("btn.cancel");
            }
        }
    },
    data() {
        return {
            loading: false,
            modal: false,
            status: 1 //1:未提交 2:提交中 3:提交完成
        }
    },
    methods: {
        show() {
            this.modal = true;
        },
        hide() {
            this.modal = false;
        },
        //表单提交
        submit() {
            this.$emit("click")
        },
        //提交中
        committing() {
            this.loading = true;
            this.status = 2;
        },
        //操作完成时，关闭模态框
        close(cb) {
            setTimeout(() => {
                this.loading = false;
                this.status = 3;
                setTimeout(() => this.reset(cb), 400);
            }, 1500)
        },
        //状态还原
        reset(cb) {
            this.modal = false;
            setTimeout(() => {
                this.loading = false;
                this.status = 1;
                typeof (cb) === 'function' && cb();
            }, 400);
        },
        //处理失败
        stop() {
            setTimeout(() => {
                this.loading = false;
                this.status = 1;
            }, 1000)
        },
        //事件处理完成回到
        finish(resp, cb) {
            if (resp.code == process.env.VUE_APP_code) {
                this.close(cb);
            } else {
                this.stop();
            }
        }
    }
}
</script>
