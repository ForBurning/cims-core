<template>
<Modal :transfer="false" v-model="noAuth.modal" :width="width" :mask-closable="false" :closable="false" :title="$t('page.noAuth')">
    {{noAuth.message}}
    <div slot="footer">
        <Button type="primary" @click="logout">{{$t('btn.reLogin')}}</Button>
    </div>
</Modal>
</template>

<script>
import utils from "@/utils/utils";
import moment from "moment";
export default {
    name: "noAuth",
    props: {
        width: {
            type: Number,
            default: 520
        },
        noAuth:{
          type:Object,
          default:()=>{
            return {
                modal: false,
                message: ''
            }
          }
        }
    },
    data() {
        return {
            
        };
    },
    methods: {
        logout() {
            utils.turnToLoginPage();
        }
    },
};
</script>
