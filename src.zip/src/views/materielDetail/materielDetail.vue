<template>
<ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content materiel-detail">
        <div class="page-info">
            <div class="chinName">物料详情</div>
            <div class="chemName">Material Detail</div>
        </div>
        <div class="detail">
            <div class="category">{{$t('page.materialDetail')}}</div>
            <div class="title">
                <img src="@/assets/img/d1.png" />
                {{$t('page.materialInfo')}}
            </div>
            <Row type="flex" :class="{'border-bottom': isCompound}">
                <Col>
                <div class="struct-img">
                    <div v-if="isCompound" :style="{backgroundImage: `url(${structurePrefix}${encodeURIComponent(dto.Photo)})`}"></div>
                    <div v-else :style="{backgroundImage: `url(${addRandom2Url(materielPrefix + dto.Photo)})`}"></div>
                </div>
                </Col>

                <Col class="flex-1" v-if="isCompound">
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('form.chinName')}}：</span>
                    {{dto.ChinName}}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('form.chemName')}}：</span>
                    {{dto.ChemName}}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('form.chinAlias')}}：</span>
                    {{dto.Alias}}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('form.chemAlias')}}：</span>
                    {{dto.ChemAlias}}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="8">
                    <span class="key">{{$t('page.materielNumber')}}：</span>
                    {{dto.MaterielNumber }}
                    </Col>
                    <Col span="8">
                    <span class="key">{{$t('columns.CASNumber')}}：</span>
                    {{dto.CASNumber}}
                    </Col>
                    <Col span="8">
                    <span class="key">{{$t('columns.mdl')}}：</span>
                    {{dto.MDLNumber }}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="8">
                    <span class="key">{{$t('page.molecularWeight')}}：</span>
                    {{dto.MolecularWeight }}
                    </Col>
                    <Col span="8">
                    <span class="key">{{$t('page.molecularFormula')}}：</span>
                    {{dto.MolecularFormula}}
                    </Col>
                    <Col span="8">
                    <span class="key">{{$t('page.accurateMass')}}：</span>
                    {{dto.ExactMass }}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('page.appearance')}}：</span>
                    {{dto.AppearanceCharacter}}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('page.stereoisomerDescription')}}</span>
                    {{dto.SteroisomerDesc}}
                    </Col>
                </Row>
                </Col>
                <Col class="flex-1" v-else>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('page.materielNumber')}}：</span>
                    {{dto.MaterielNumber}}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('form.chinName')}}：</span>
                    {{dto.ChinName}}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('form.chinAlias')}}：</span>
                    {{dto.Alias }}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('columns.categoryName')}}：</span>
                    {{dto.CategoryName}}
                    </Col>
                </Row>
                <Row type="flex" v-if="!isCompound">
                    <neo-custom-form :domain="cimsmanage" :data="customFormData" mode="view" hasColon></neo-custom-form>
                </Row>
                </Col>
            </Row>
            <div class="title" v-if="isCompound">
                <img src="@/assets/img/d2.png" />
                {{$t('page.chemProperty')}}
            </div>
            <Row type="flex" v-if="isCompound">
                <Col span="6">
                <span class="key">{{$t('page.density')}}：</span>
                {{dto.Density}}
                </Col>
                <Col span="6">
                <span class="key">{{$t('page.meltlingPoint')}}：</span>
                {{dto.MeltlingPoint }}
                </Col>
                <Col span="6">
                <span class="key">{{$t('page.boilingPoint')}}：</span>
                {{dto.BoilingPoint }}
                </Col>
                <Col span="6">
                <span class="key">{{$t('page.flashPoint')}}：</span>
                {{dto.FlashPoint }}
                </Col>
            </Row>
            <Row type="flex" v-if="isCompound">
                <Col span="6">
                <span class="key">PSA：</span>
                {{dto.PSA}}
                </Col>
                <Col span="6">
                <span class="key">LogP：</span>
                {{dto.LogP }}
                </Col>
                <Col span="6">
                <span class="key">{{$t('page.refractiveIndex')}}：</span>
                {{dto.RefractiveIndex }}
                </Col>
                <Col span="6">
                <span class="key">{{$t('page.vapourPressure')}}：</span>
                {{dto.VapourPressure }}
                </Col>
            </Row>
            <Row type="flex" class="border-bottom" v-if="isCompound">
                <Col span="24">
                <span class="key">{{$t('page.stability')}}：</span>
                {{dto.Stability}}
                </Col>
            </Row>

            <div class="title" v-if="isCompound">
                <img src="@/assets/img/d3.png" />
                {{$t('page.sAndr')}}
            </div>
            <Row type="flex" v-if="isCompound">
                <Col span="24">
                <span class="key">{{$t('page.incompatibilityInfo')}}：</span>
                {{dto.IncompatibilityInfo && dto.IncompatibilityInfo.Name}}
                </Col>
                <Col span="24">
                <span class="key">{{$t('page.storageCondition')}}：</span>
                {{dto.StorageCondition}}
                </Col>
                <Col span="5">
                <span class="key">{{$t('page.toxic')}}：</span>
                {{dto.Toxic > 0 ? $t('page.yes') : $t('page.no')}}
                </Col>
                <Col span="5">
                <span class="key">{{$t('page.pretoxic')}}：</span>
                {{dto.Pretoxic > 0 ? $t('page.yes') : $t('page.no') }}
                </Col>
                <Col span="5">
                <span class="key">{{$t('page.dangerous')}}：</span>
                {{dto.Dangerous > 0 ? $t('page.yes') : $t('page.no') }}
                </Col>
            </Row>
            <Row type="flex" v-if="isCompound">
                <Col span="24">
                <span class="key">{{$t('page.gb')}}：</span>
                <span v-for="item in dto.Symbol ? dto.Symbol.split(',') : []" :key="item">
                    <img src="@/assets/img/爆炸物.png" v-if="item === $t('page.gb1')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/腐蚀性.png" v-else-if="item === $t('page.gb2')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/高压气体.png" v-else-if="item === $t('page.gb3')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/环境危害.png" v-else-if="item === $t('page.gb4')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/健康危害.png" v-else-if="item === $t('page.gb5')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/氧化物.png" v-else-if="item === $t('page.gb6')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/易燃物.png" v-else-if="item === $t('page.gb7')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/有毒物质.png" v-else-if="item === $t('page.gb8')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/有害.png" v-else-if="item === $t('page.gb9')" class="risk" style="margin-right:6px;" />
                </span>
                </Col>
            </Row>
            <Row type="flex" v-if="isCompound">
                <Col span="24">
                <span class="key">{{$t('page.om')}}：</span>
                {{dto.RiskSymbol}}
                </Col>
            </Row>
            <Row type="flex" v-if="isCompound">
                <Col span="24">
                <span class="key">{{$t('page.om1')}}：</span>
                {{dto.RiskPhrases}}
                </Col>
            </Row>
            <Row type="flex" v-if="isCompound">
                <Col span="24">
                <span class="key">{{$t('page.om2')}}：</span>
                {{dto.HazardInfo}}
                </Col>
            </Row>
            <Row type="flex" v-if="isCompound">
                <Col span="24">
                <span class="key">{{$t('page.om3')}}：</span>
                {{dto.SafetyPhrases}}
                </Col>
            </Row>
            <Row type="flex" v-if="isCompound">
                <Col span="24">
                <span class="key">{{$t('page.om4')}}：</span>
                {{dto.WarningStatement}}
                </Col>
            </Row>
            <Row type="flex" class="border-bottom" v-if="isCompound">
                <Col span="24">
                <span class="key">{{$t('page.om5')}}：</span>
                {{dto.StorageRequirement}}
                </Col>
            </Row>

            <div class="title" v-if="isCompound">
                <img src="@/assets/img/d5.png" />MSDS
            </div>
            <Row type="flex" class="border-bottom" v-if="isCompound">
                <Col span="24">
                <span class="key">MSDS：</span>
                <a :href="dto.MSDS.replace(/#/g, '%23')" v-if="dto.MSDS" target="_blank">{{dto.MSDS.substr(dto.MSDS.lastIndexOf('/')+1)}}</a>
                <span v-else>{{$t('page.not')}}</span>
                </Col>
            </Row>

            <div class="title" v-if="isCompound">
                <img src="@/assets/img/d2.png" />
                {{$t('page.toxicityInfo')}}
            </div>
            <Row type="flex" class="border-bottom" v-if="isCompound">
                <Col span="24">
                <span class="key">{{$t('page.toxicityInfo')}}：</span>
                <a :href="dto.ToxicityInfo.replace(/#/g, '%23')" v-if="dto.ToxicityInfo" target="_blank">{{dto.ToxicityInfo.substr(dto.ToxicityInfo.lastIndexOf('/')+1)}}</a>
                <span v-else>{{$t('page.not')}}</span>
                </Col>
            </Row>

            <div class="title" v-if="isCompound">
                <img src="@/assets/img/d4.png" />
                {{$t('page.other')}}
            </div>
            <Row type="flex" class="border-bottom no-border" v-if="isCompound">
                <Col span="6">
                <span class="key">{{$t('page.customNumber')}}：</span>
                {{dto.CASNumber}}
                </Col>
                <Col span="6">
                <span class="key">{{$t('form.waste19')}}：</span>
                {{dto.Origin }}
                </Col>
                <Col span="6">
                <span class="key">{{$t('page.OHS1')}}：</span>
                {{dto.OHSNumber }}
                </Col>
                <Col span="6">
                <span class="key">{{$t('page.OHS2')}}：</span>
                {{dto.OHSName }}
                </Col>
            </Row>
        </div>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from "@/components/layout.vue";
import neoCustomForm from "@neotrident/neo-custom-form";
import utils from "@/utils/utils";
import api from "@/api";
import Vue from "vue";
import Vddl from "vddl"
Vue.use(Vddl);
import Vuebar from 'vuebar'
Vue.use(Vuebar);

export default {
    name: "reagent-page",
    components: {
        ilabLayout,
        neoCustomForm
    },
    created() {
        this.id = utils.getParams("id") * 1;
    },
    data() {
        return {
            breadcrumbs: [{
                txt: this.$i18n.t("page.materialDetail")
            }],
            id: "",
            isCompound: true,
            structurePrefix: process.env.VUE_APP_structure_img_url,
            materielPrefix: process.env.VUE_APP_materiel_img_url,
            cimsmanage: process.env.VUE_APP_cimsmanage,
            dto: {
                Symbol: "",
                ToxicityInfo: ""
            },
            data: [],
            columns: [{
                    title: this.$i18n.t("columns.requestCode"),
                    key: "RequestCode"
                },
                {
                    title: this.$i18n.t("form.projectCode"),
                    key: "ProjectCode"
                },
                {
                    title: this.$i18n.t("columns.requestQuantity"),
                    key: "RequestQuantity"
                },
                {
                    title: this.$i18n.t("columns.requestUnit"),
                    key: "RequestUnit"
                },
                {
                    title: this.$i18n.t("columns.requester"),
                    key: "Requester"
                },
                {
                    title: this.$i18n.t("columns.requestDate"),
                    key: "RequestDate",
                    width: 180
                },
                {
                    title: this.$i18n.t("columns.operation"),
                    slot: "Action",
                    align: "center",
                    width: 200
                }
            ],
            customFormData: []
        };
    },
    methods: {
        //物料详情
        async getMateriel() {
            if (this.id) {
                const resp = await api.cims.getMaterielById(this.id);
                if (resp.code == process.env.VUE_APP_code) {
                    this.dto = resp.response.MaterielEntity;
                    if (resp.response.MaterielDataEntity.CustomColumnsValues) {
                        this.customFormData = JSON.parse(resp.response.MaterielDataEntity.CustomColumnsValues);
                    }
                }
            }
        },
        //化合物详情
        async getCompound() {
            if (this.id) {
                const resp = await api.cims.getCompound(this.id);
                if (resp.code == process.env.VUE_APP_code) {
                    Object.assign(resp.response, resp.response.MaterielInfo);
                    this.dto = resp.response;
                }
            }
        },
        //领用历史
        openApplicantHistory(data) {
            this.data1 = data;
            this.modal1 = true;
        },
        //审批历史
        openApproveHistory(data) {
            this.data2 = data;
            this.modal2 = true;
        },
        //结构式图片URL添加随机数
        addRandom2Url: (url) => utils.addRandom2Url(url)
    },
    mounted() {
        this.isCompound = utils.getParams('categoryCode') === process.env.VUE_APP_CR;
        if (this.isCompound) {
            this.getCompound();
        } else {
            this.getMateriel();
        }
    }
};
</script>

<style lang="less" scoped>
.content {
    .detail {
        border: 1px solid #ddd;
        padding: 0 30px 30px 30px;
        font-size: 15px;

        .category {
            font-size: 16px;
            font-weight: bold;
            display: block;
            margin: -1px -30px;
            border-top: 1px solid #ddd;
            border-bottom: 1px solid #ddd;
            padding: 8px 30px;
            margin-bottom: 30px;
        }

        .title {
            font-size: 16px;
            color: #3496ed;
            font-weight: bold;
            margin-bottom: 6px;

            img {
                position: relative;
                top: 3px;
                margin-right: 10px;
            }
        }

        .ivu-row-flex {
            padding-left: 25px;

            .key {
                display: inline-block;
                width: 120px;
                text-align: right;
            }

            &.border-bottom {
                border-bottom: 1px solid #ddd;
                margin-bottom: 20px;
                padding-bottom: 15px;

                &.no-border {
                    border-bottom: none;
                }
            }
        }

        .struct-img {
            text-align: center;
            border-right: 1px solid #ddd;
            margin-bottom: 24px;
            padding-right: 12px;
            width: 190px;

            div {
                background-position: center center;
                background-repeat: no-repeat;
                background-size: contain;
                height: 165px;
                margin-right: 12px;
            }
        }

        .ivu-col {
            padding: 8px 0;
        }

        .ivu-table-wrapper {
            margin-bottom: 35px;
        }

        .chinName {
            margin: 16px 0 6px 0;
            text-overflow: ellipsis;
            white-space: nowrap;
            overflow: hidden;
        }

        .time {
            margin-top: 8px;
        }

        .content {
            font-size: 14px;
        }

        .chemName {
            color: #a3a3a3;
            text-overflow: ellipsis;
            white-space: nowrap;
            overflow: hidden;
        }
    }
}
</style>
<style lang="less">
.materiel-detail {
    .neo-form {
        width: 100%;

        .neo-body {

            .form-row-item .component {
                padding-left: 16px;

                .component-title {
                    width: 120px;
                    padding-right: 6px;
                }
            }

            .component.container-row-item {
                padding-left: 0;
            }
        }
    }

}
</style>
