<template>
  <ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
      <div class="page-info">
        <div class="chinName">领用详情</div>
        <div class="chemName">Request Details</div>
      </div>
      <Row class="request-steps" type="flex">
        <Col>
          <div class="request-code">{{$t("columns.requestCode")}}：{{details.RequestCode}}</div>
          <div>{{requestType}}</div>
        </Col>
        <Col class="flex-1">
          <div class="flow" v-cloak>
            <div class="step-1" v-cloak>
              <img src="@/assets/img/flow.png" />
              <div>{{$t("btn.submitRequest")}}</div>
            </div>
            <div
              class="step-2"
              v-bind:class="{'active': details.RequestState < 19}"
              v-if="details.ApproveState !== -1"
              v-cloak
            >
              <img src="@/assets/img/step2.png" />
              <div>{{$t("page.approveFlow1")}}</div>
            </div>
            <div class="step-2" v-if="details.ApproveState === -1" v-cloak>
              <img src="@/assets/img/refuse.png" />
              <div>{{$t("page.approveFlow2")}}</div>
            </div>
            <div
              class="step-3"
              v-bind:class="{'active': details.RequestState === 19 || details.RequestState === 200}"
              v-if="details.ApproveState !== -1"
              v-cloak
            >
              <img src="@/assets/img/step3-1.png" v-if="details.RequestState < 19" />
              <img src="@/assets/img/step3.png" v-if="details.RequestState >= 19" />
              <div>{{$t("page.approveFlow3")}}</div>
            </div>
            <div
              class="step-4"
              v-bind:class="{'active': details.RequestState === 201}"
              v-if="details.ApproveState !== -1"
              v-cloak
            >
              <img src="@/assets/img/step4-1.png" v-if="details.RequestState <= 200" />
              <img src="@/assets/img/step4.png" v-if="details.RequestState > 200" />
              <div>{{$t("page.approveFlow4")}}</div>
            </div>
            <div
              class="step-5"
              v-bind:class="{'active': details.RequestState === 300}"
              v-if="details.ApproveState !== -1 && details.DeliveryFlag === 1"
              v-cloak
            >
              <img src="@/assets/img/step5-4.png" v-if="details.RequestState < 300" />
              <img src="@/assets/img/step5-3.png" v-if="details.RequestState >= 300" />
              <div>{{$t("page.approveFlow5")}}</div>
            </div>
            <div
              class="step-5"
              v-bind:class="{'active': details.RequestState === 301 || details.RequestState === 400}"
              v-if="details.ApproveState !== -1 && details.DeliveryFlag === 2"
              v-cloak
            >
              <img src="@/assets/img/step5-2.png" v-if="details.RequestState < 301" />
              <img src="@/assets/img/step5-1.png" v-if="details.RequestState >= 301" />
              <div>{{$t("page.approveFlow6")}}</div>
            </div>

            <div
              class="step-6"
              v-bind:class="{'active': details.RequestState === 500}"
              v-if="details.ApproveState !== -1"
              v-cloak
            >
              <img src="@/assets/img/step6-1.png" v-if="details.RequestState < 500" />
              <img src="@/assets/img/step6.png" v-if="details.RequestState === 500" />
              <div>{{$t("tour.buttonStop")}}</div>
            </div>
            <div
              class="flow-line"
              v-bind:class="{'refusedLine': details.ApproveState === -1}"
              v-cloak
            ></div>
          </div>
        </Col>
      </Row>

      <div class="request-middle">
        <div class="time-line">
          <p
            v-for="item in details.StateHistory"
            :key="item.CreateTime"
          >[{{item.CreateTime}}]: {{item.Comment}}</p>
          <div class="line"></div>
        </div>
      </div>

      <div class="page-info materiel-info">
        <div class="chinName">{{$t("page.requestMateriel")}}</div>
      </div>
      <Table :columns="columns" :data="data"></Table>
    </div>
  </ilab-layout>
</template>
<script>
import ilabLayout from "@/components/layout.vue";
import api from "@/api";
import enums from "@/utils/enums";
import utils from "@/utils/utils";

export default {
  name: "request-detail",
  components: {
    ilabLayout
  },
  data() {
    return {
      breadcrumbs: [
        {
          txt: this.$i18n.t("nav.claimHistory"),
          href: "/request"
        },
        {
          txt: this.$i18n.t("nav.requestDetails")
        }
      ],
      details: {},
      requestType: "",
      columns: [
        {
          title: this.$i18n.t("columns.requestCode"),
          key: "RequestCode"
        },
        {
          title: this.$i18n.t("columns.CASNumber"),
          key: "CASNumber"
        },
        {
          title: this.$i18n.t("columns.bottleName"),
          key: "BottleName"
        },
        {
          title: this.$i18n.t("columns.projectCode"),
          key: "ProjectCode"
        },
        {
          title: this.$i18n.t("columns.requestQuantity"),
          key: "RequestDate",
          render: (h, params) => {
            return h(
              "div",
              params.row.RequestQuantity + params.row.RequestUnit
            );
          }
        },
        {
          title: this.$i18n.t("columns.requestDate"),
          key: "RequestDate"
        }
      ],
      data: []
    };
  },
  mounted() {
    const id = utils.getParams("id");
    this.fetchRequestDetail(id);
  },
  methods: {
    async fetchRequestDetail(id) {
      const resp = await api.cims.fetchRequestDetail(id);

      if (resp.code == process.env.VUE_APP_code) {
        this.details = resp.response;
        this.data = [resp.response];
        this.requestType =
          resp.response.ApproveState === -1
            ? this.$i18n.t("tab.rejected")
            : enums.requestStateTxt(this.$i18n)[resp.response.RequestState];
      } else {
        this.$Message.error(resp.message);
      }
    }
  }
};
</script>

<style lang="less" scoped>
.content {
  .materiel-info .chinName:after {
    display: none;
  }
}
</style>
