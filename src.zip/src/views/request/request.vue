<template>
<ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
        <div class="page-info">
            <div class="chinName">我的领用</div>
            <div class="chemName">Claim History</div>
        </div>

        <Tabs v-model="name" class="ilab-tabs" :animated="false" @on-click="onTabsClick">
            <TabPane :label="$t('page.all')" name="1">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.requestCode')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.requestDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="reagentColumns1" :data="data" :total="total" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="RequestCode">
                        <a :href="appPrefix + '/request/detail?id=' + row.RequestCode">{{row.RequestCode}}</a>
                    </template>
                    <template slot-scope="{ row }" slot="Action">
                        <div style="white-space: nowrap;">
                            <Button size="small" :to="`${appPrefix}/applicant/add?id=${row.Barcode}&type=2`" :disabled="roles.APPLY?false:true">{{$t('nav.applicant')}}</Button>
                            <Button type="primary" size="small" @click="openModal('tkModal', row)" :disabled="row | calcDisabled">{{$t('btn.return')}}</Button>
                            <Button type="primary" size="small" :disabled="row | calcDisabled" @click="openModal('bfModal', row)">{{$t('btn.scrapp')}}</Button>
                            <Button type="primary" size="small" :disabled="row | calcDisabled" @click="openModal('cfModal', row)">{{$t('btn.store')}}</Button>
                        </div>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
            </TabPane>
            <TabPane :label="$t('tab.approving')" name="2">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.requestCode')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.requestDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="reagentColumns2" :data="data" :total="total" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="RequestCode">
                        <a :href="appPrefix + '/request/detail?id=' + row.RequestCode">{{row.RequestCode}}</a>
                    </template>
                    <template slot-scope="{ row }" slot="Action1">
                        <div style="white-space: nowrap;">
                            <Button size="small" :to="appPrefix + '/requestApprove/detail?id=' + row.RequestCode">{{$t('btn.approveDetail')}}</Button>
                        </div>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
            </TabPane>
            <TabPane :label="$t('tab.receipting')" name="3">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.requestCode')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.requestDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="reagentColumns3" :data="data" :total="total" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="RequestCode">
                        <a :href="appPrefix + '/request/detail?id=' + row.RequestCode">{{row.RequestCode}}</a>
                        <span v-html="isExpiry(row.ExpiryDate)"></span>
                    </template>
                    <template slot-scope="{ row }" slot="Action1">
                        <div style="white-space: nowrap;">
                            <Button size="small" :to="appPrefix + '/requestApprove/detail?id=' + row.RequestCode">{{$t('btn.approveDetail')}}</Button>
                        </div>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
            </TabPane>
            <TabPane :label="$t('tab.rejected')" name="4">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.requestCode')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.requestDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="reagentColumns4" :data="data" :total="total" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="RequestCode">
                        <a :href="appPrefix + '/request/detail?id=' + row.RequestCode">{{row.RequestCode}}</a>
                    </template>
                    <template slot-scope="{ row }" slot="Action1">
                        <div style="white-space: nowrap;">
                            <Button size="small" :to="appPrefix + '/requestApprove/detail?id=' + row.RequestCode">{{$t('btn.approveDetail')}}</Button>
                        </div>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
            </TabPane>
            <TabPane :label="$t('tab.signed')" name="5">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.requestCode')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.requestDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="reagentColumns5" :data="data" :total="total" :noDataText="noDataText" ref="table5" @on-select="getSelectCount" @on-select-all="getSelectCount" @on-select-all-cancel="getSelectCount" @on-select-cancel="getSelectCount">
                    <template slot-scope="{ row }" slot="RequestCode">
                        <a :href="appPrefix + '/request/detail?id=' + row.RequestCode">{{row.RequestCode}}</a>
                        <span v-html="isExpiry(row.ExpiryDate)"></span>
                    </template>
                    <template slot-scope="{ row }" slot="RequestAction">
                        <Button size="small" :to="`${appPrefix}/applicant/add?id=${row.Barcode}&type=2`" :disabled="roles.APPLY?false:true">{{$t('nav.applicant')}}</Button>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />

                <Row class="batch-operation" v-if="total > 0">
                    <Col span="12">
                    <Button class="select-all-btn" @click="selectAll">{{selectCount === data.length ? $t('btn.cancelAll') : $t('btn.selectAll')}}</Button>
                    </Col>
                    <Col span="12">
                    <Button size="large" type="primary" :disabled="selectCount === 0" @click="openModal('tkModal')">{{$t('btn.batchReturn')}}</Button>
                    <Button size="large" type="error" :disabled="selectCount === 0" @click="openModal('bfModal')">{{$t('btn.batchScrapp')}}</Button>
                    <Button size="large" type="error" :disabled="selectCount === 0" @click="openModal('cfModal')">{{$t('btn.batchStore')}}</Button>
                    </Col>
                </Row>
            </TabPane>
            <TabPane :label="$t('tab.returned')" name="6">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.requestCode')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.requestDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="reagentColumns6" :data="data" :total="total" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="RequestCode">
                        <a :href="appPrefix + '/request/detail?id=' + row.RequestCode">{{row.RequestCode}}</a>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
            </TabPane>
            <TabPane :label="$t('tab.scrapped')" name="7">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.requestCode')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.requestDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="reagentColumns7" :data="data" :total="total" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="RequestCode">
                        <a :href="appPrefix + '/request/detail?id=' + row.RequestCode">{{row.RequestCode}}</a>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
            </TabPane>
        </Tabs>

        <Modal :title="$t('btn.return')" v-model="tkModal" @on-ok="tkOk" :loading="loading">
            <Form ref="tkForm" :model="tkForm" :rules="tkRules" :label-width="80">
                <FormItem :label="$t('form.returnReason')" prop="comments">
                    <Select :placeholder="$t('message.placeSelect', [$t('form.returnReason')])" v-model="tkForm.comments">
                        <Option v-for="item in stockList" :value="item.Code" :key="item.Code">{{item.Name}}</Option>
                    </Select>
                </FormItem>
            </Form>
        </Modal>

        <Modal :title="$t('btn.scrapp')" v-model="bfModal" @on-ok="bfOk" :loading="loading">
            <Form ref="bfForm" :model="bfForm" :rules="bfRules" :label-width="80">
                <FormItem :label="$t('form.scrappedReason')" prop="comments">
                    <Select :placeholder="$t('message.placeSelect', [$t('form.scrappedReason')])" v-model="bfForm.comments">
                        <Option v-for="item in scrapList" :value="item.Code" :key="item.Code">{{item.Name}}</Option>
                    </Select>
                </FormItem>
            </Form>
        </Modal>

        <Modal :title="$t('btn.store')" v-model="cfModal" @on-ok="cfOk" :loading="loading">
            <Form ref="cfForm" :model="cfForm" :rules="cfRules" :label-width="80">
                <FormItem :label="$t('form.stroeLoc')" prop="storageLocation">
                    <Input type="textarea" :placeholder="$t('message.placeholder', [$t('form.stroeLoc')])" v-model="cfForm.storageLocation" :autosize="{minRows: 3,maxRows: 5}"></Input>
                </FormItem>
            </Form>
        </Modal>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from "@/components/layout.vue";
import api from "@/api";
import columns from "@/utils/columns";
import utils from "@/utils/utils";

export default {
    name: "request-page",
    components: {
        ilabLayout
    },
    data() {
        return {
            iminentExpirationDay: "",
            noDataText: this.$i18n.t("columns.noDataText"),
            total: 0,
            materielType: [],
            stockList: [],
            scrapList: [],
            roles: utils.getCimsInfo().RoleCodes,
            tkModal: false,
            bfModal: false,
            cfModal: false,
            tkForm: {
                comments: ""
            },
            tkRules: {
                comments: [{
                    required: true,
                    message: this.$i18n.t("message.notNull", [
                        this.$i18n.t("form.returnReason")
                    ]),
                    trigger: "change"
                }]
            },
            bfForm: {
                comments: ""
            },
            bfRules: {
                comments: [{
                    required: true,
                    message: this.$i18n.t("message.notNull", [
                        this.$i18n.t("form.scrappedReason")
                    ]),
                    trigger: "change"
                }]
            },
            cfForm: {
                storageLocation: ""
            },
            cfRules: {
                storageLocation: [{
                    required: true,
                    message: this.$i18n.t("message.notNull", [
                        this.$i18n.t("form.stroeLoc")
                    ]),
                    trigger: "change"
                }, {
                    validator: (rule, value, callback) => {
                        const maxLength = 20;
                        if (value.length <= maxLength) {
                            callback();
                        } else {
                            callback(
                                new Error(
                                    this.$i18n.t("message.notOver", [
                                        this.$i18n.t("form.stroeLoc"),
                                        maxLength
                                    ])
                                )
                            );
                        }
                    }
                }]
            },
            appPrefix: process.env.VUE_APP_prefix,
            fileType: 0,
            name: "1",
            breadcrumbs: [{
                txt: this.$i18n.t("nav.claimHistory")
            }],
            reagentColumns1: [
                columns.RequestCode(this.$i18n.t("columns.requestCode")),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.BottleName(this.$i18n.t("columns.bottleName")),
                columns.Purity(this.$i18n.t("columns.purity")),
                columns.RequestQuantity(this.$i18n.t("columns.requestQuantity")),
                columns.EstimatedAmount(this.$i18n.t("columns.estimatedAmount")),
                columns.ProjectCode(this.$i18n.t("columns.projectCode")),
                columns.RequestDate(this.$i18n.t("columns.requestDate")),
                columns.ShowState(this.$i18n.t("columns.state")),
                columns.StorageLocation(this.$i18n.t("form.stroeLoc")),
                columns.Action(this.$i18n.t("columns.operation"))
            ],
            reagentColumns2: [
                columns.RequestCode(this.$i18n.t("columns.requestCode")),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.BottleName(this.$i18n.t("columns.bottleName")),
                columns.Purity(this.$i18n.t("columns.purity")),
                columns.RequestQuantity(this.$i18n.t("columns.requestQuantity")),
                columns.EstimatedAmount(this.$i18n.t("columns.estimatedAmount")),
                columns.ProjectCode(this.$i18n.t("columns.projectCode")),
                columns.RequestDate(this.$i18n.t("columns.requestDate")),
                columns.ApproveUsersNames(this.$i18n.t("columns.approveUsersNames")),
                columns.Action1(this.$i18n.t("columns.operation"))
            ],
            reagentColumns3: [
                Object.assign(
                    columns.RequestCode(this.$i18n.t("columns.requestCode")), {
                        width: 170
                    }
                ),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.BottleName(this.$i18n.t("columns.bottleName")),
                columns.Purity(this.$i18n.t("columns.purity")),
                columns.RequestQuantity(this.$i18n.t("columns.requestQuantity")),
                columns.EstimatedAmount(this.$i18n.t("columns.estimatedAmount")),
                columns.ProjectCode(this.$i18n.t("columns.projectCode")),
                columns.RequestDate(this.$i18n.t("columns.requestDate")),
                columns.ShowState(this.$i18n.t("columns.state"))
            ],
            reagentColumns4: [
                columns.RequestCode(this.$i18n.t("columns.requestCode")),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.BottleName(this.$i18n.t("columns.bottleName")),
                columns.Purity(this.$i18n.t("columns.purity")),
                columns.RequestQuantity(this.$i18n.t("columns.requestQuantity")),
                columns.EstimatedAmount(this.$i18n.t("columns.estimatedAmount")),
                columns.ProjectCode(this.$i18n.t("columns.projectCode")),
                columns.RequestDate(this.$i18n.t("columns.requestDate")),
                columns.ApproveUser(this.$i18n.t("columns.approveUser")),
                columns.ApproveTime(this.$i18n.t("columns.approveTime")),
                columns.ApproveReason(this.$i18n.t("columns.approveReason")),
                columns.Action1(this.$i18n.t("columns.operation"))
            ],
            reagentColumns5: [
                columns.Select,
                Object.assign(
                    columns.RequestCode(this.$i18n.t("columns.requestCode")), {
                        width: 170
                    }
                ),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.Barcode(this.$i18n.t("columns.barcode")),
                columns.BottleName(this.$i18n.t("columns.bottleName")),
                columns.Purity(this.$i18n.t("columns.purity")),
                columns.RequestQuantity(this.$i18n.t("columns.requestQuantity")),
                columns.EstimatedAmount(this.$i18n.t("columns.estimatedAmount")),
                columns.ProjectCode(this.$i18n.t("columns.projectCode")),
                columns.ShowState(this.$i18n.t("columns.state")),
                columns.StorageLocation(this.$i18n.t("form.stroeLoc")),
                columns.Deliverer(this.$i18n.t("columns.deliverer")),
                columns.ReceiveDate(this.$i18n.t("columns.receiveDate")),
                columns.RequestAction(this.$i18n.t("columns.operation"))
            ],
            reagentColumns6: [
                columns.RequestCode(this.$i18n.t("columns.requestCode")),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.BottleName(this.$i18n.t("columns.bottleName")),
                columns.Purity(this.$i18n.t("columns.purity")),
                columns.RequestQuantity(this.$i18n.t("columns.requestQuantity")),
                columns.EstimatedAmount(this.$i18n.t("columns.estimatedAmount")),
                columns.ProjectCode(this.$i18n.t("columns.projectCode")),
                columns.RequestDate(this.$i18n.t("columns.requestDate")),
                columns.CompleteTime(this.$i18n.t("columns.completeTime")),
                columns.tkComments(this.$i18n.t("form.returnReason"))
            ],
            reagentColumns7: [
                columns.RequestCode(this.$i18n.t("columns.requestCode")),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.BottleName(this.$i18n.t("columns.bottleName")),
                columns.Purity(this.$i18n.t("columns.purity")),
                columns.RequestQuantity(this.$i18n.t("columns.requestQuantity")),
                columns.EstimatedAmount(this.$i18n.t("columns.estimatedAmount")),
                columns.ProjectCode(this.$i18n.t("columns.projectCode")),
                columns.RequestDate(this.$i18n.t("columns.requestDate")),
                columns.bfTime(this.$i18n.t("columns.bfTime")),
                columns.bfComments(this.$i18n.t("form.scrappedReason"))
            ],
            data: [],
            condition1: "",
            condition2: "",
            condition3: "",
            curTabName: "1",
            storeModal: false,
            curRows: "",
            storageLocation: "",
            loading: true,
            pageIndex: 1,
            selectCount: 0
        };
    },
    methods: {
        //获取物料近效期提醒时间
        async getIminentExpirationDay() {
            const resp = await api.cims.getOrganizationConfig("iminentExpirationDay");
            if (resp.code == process.env.VUE_APP_code) {
                this.iminentExpirationDay = resp.response;
            } else {
                this.$Message.error(resp.message);
            }
        },
        //判断近效期
        isExpiry(date) {
            const expireDateState = [this.$i18n.t("page.overExpiryTime"), this.$i18n.t("page.withExpiryTime"), this.$i18n.t("page.inExpiryTime")];
            return utils.isExpiry(this.iminentExpirationDay, date, expireDateState);
        },
        //加载物料类型
        async fetchMaterielType() {
            const resp = await api.cims.fetchMaterielType();
            this.materielType = resp.response;
        },
        //加载报废理由
        async loadStock() {
            let resp = await api.cims.fetchDicItem("returnStockReason");
            if (resp.code == process.env.VUE_APP_code) {
                this.stockList = resp.rows;
            }
        },
        //加载报废理由
        async loadScrap() {
            let resp = await api.cims.fetchDicItem("scrapReason");
            if (resp.code == process.env.VUE_APP_code) {
                this.scrapList = resp.rows;
            }
        },
        //打开模态框
        openModal(model, row) {
            if (model === "tkModal") {
                this.$refs.tkForm.resetFields();
            } else if (model === "bfModal") {
                this.$refs.bfForm.resetFields();
            } else {
                this.$refs.cfForm.resetFields();
                this.cfForm.storageLocation = row ? row.StorageLocation : "";
            }

            if (row) {
                this.curRows = [row];
            } else {
                this.curRows = this.$refs.table5.getSelection();
            }
            this[model] = true;
        },
        //关闭loading
        resetLoading() {
            this.loading = false;
            setTimeout(() => {
                this.loading = true;
            }, 0);
        },
        //{{$t('btn.return')}}
        async tkOk() {
            let valid = await this.$refs.tkForm.validate();
            if (valid) {
                let resp = await api.cims.tkOperation({
                    requestCodes: this.curRows.map(item => item.RequestCode),
                    comments: this.tkForm.comments
                });

                if (resp.code == process.env.VUE_APP_code) {
                    this.$Message.success(resp.message);
                    this.tkModal = false;
                    this.fetchData(this.pageIndex);
                } else {
                    this.$Message.error(resp.message);
                    this.resetLoading();
                }
            } else {
                this.resetLoading();
            }
        },
        //报废
        async bfOk() {
            let valid = await this.$refs.bfForm.validate();
            if (valid) {
                let resp = await api.cims.bfOperation({
                    requestCodes: this.curRows.map(item => item.RequestCode),
                    comments: this.bfForm.comments
                });

                if (resp.code == process.env.VUE_APP_code) {
                    this.$Message.success(resp.message);
                    this.bfModal = false;
                    this.fetchData(this.pageIndex);
                } else {
                    this.$Message.error(resp.message);
                    this.resetLoading();
                }
            } else {
                this.resetLoading();
            }
        },
        //存放
        async cfOk() {
            let valid = await this.$refs.cfForm.validate();
            if (valid) {
                let resp = await api.cims.cfOperation({
                    requestCodes: this.curRows.map(item => item.RequestCode),
                    storageLocation: this.cfForm.storageLocation
                });

                if (resp.code == process.env.VUE_APP_code) {
                    this.$Message.success(resp.message);
                    this.cfModal = false;
                    this.fetchData(this.pageIndex);
                } else {
                    this.$Message.error(resp.message);
                    this.resetLoading();
                }
            } else {
                this.resetLoading();
            }
        },
        //tab切换
        onTabsClick(tabName) {
            this.curTabName = tabName;
            this.condition1 = "";
            this.condition2 = "";
            this.condition3 = "";
            this.data = [];
            this.total = 0;
            this.selectCount = 0;
            this.fetchData();
        },
        //获取表格数据
        async fetchData(pageIndex = 1) {
            this.noDataText = this.$i18n.t("columns.noDataText");

            let resp = await api.cims[`fetchRequestTab${this.name}`]({
                pageIndex: pageIndex,
                requestCode: this.condition1,
                requestStartDate: this.condition2.length ? this.condition2[0] : "",
                requestEndDate: this.condition2.length ? this.condition2[1] : "",
                categoryCode: this.condition3
            });
            if (resp.code == process.env.VUE_APP_code) {
                this.data = resp.rows;
                this.total = resp.total;
            } else {
                this.data = [];
                this.noDataText = this.$i18n.t("columns.noDataText2");
            }

            this.pageIndex = pageIndex;
            this.selectCount = 0;
        },
        //全选
        selectAll() {
            const isSelectAll = this.selectCount === this.data.length;
            if (isSelectAll) {
                this.$refs.table5.selectAll(false);
                this.selectCount = 0;
            } else {
                this.$refs.table5.selectAll(true);
                this.selectCount = this.data.length;
            }
        },
        getSelectCount() {
            this.selectCount = this.$refs.table5.getSelection().length;
        }
    },
    filters: {
        calcDisabled: function (row) {
            if ([200, 400, 500, 600].includes(row.State)) {
                return true;
            } else {
                return row.RequestState !== 500 || row.ShowState !== '已签收';
            }
        }
    },
    async mounted() {
        await this.getIminentExpirationDay();
        await this.fetchData();
        await this.fetchMaterielType();
        await this.loadStock();
        await this.loadScrap();
    }
};
</script>
