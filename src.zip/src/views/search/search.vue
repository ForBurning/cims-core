<template>
<ilab-layout :breadcrumbs="breadcrumbs" ref="layout">
    <div slot="content" class="content">
        <Row class="filters">
            <Col>
            <Row type="flex">
                <Col class="key">{{$t('page.materiel')}}：</Col>
                <Col class="value">
                <span class="item" v-for="item in materielTypes" :value="item.Code" :key="item.Code" :class="{'active': item.active}" @click="onFilterClick(materielTypes,item, 'categoryCode')">{{item.Name}}</span>
                </Col>
            </Row>
            <Row type="flex">
                <Col class="key">{{$t('page.warehouse')}}：</Col>
                <Col class="value" :class="{'single-row': !isMoreUp1}">
                <span class="item" v-for="item in warehouses" :value="item.Name" :key="item.Name" :class="{'active': item.active}" @click="onFilterClick(warehouses,item, 'warehouse')">{{item.Name}}</span>
                </Col>
                <Col class="more">
                <div @click="onMoreClick('isMoreUp1')">
                    {{isMoreUp1 ? $t('page.close') : $t('page.open')}}
                    <i class="ivu-icon" :class="{'ivu-icon-ios-arrow-up':isMoreUp1 , 'ivu-icon-ios-arrow-down': !isMoreUp1}"></i>
                </div>
                </Col>
            </Row>
            <Row type="flex" class="no-bottom">
                <Col class="key">{{$t('page.supplier')}}：</Col>
                <Col class="value">
                <span class="item" v-for="(item, index) in suppliers" :value="item.Name" :key="index" :class="{'active': item.active}" @click="onFilterClick(suppliers,item, 'supplier')">{{item.Name}}</span>
                </Col>
                <Col class="more">
                <div @click="onMoreClick('isMoreUp2')">
                    {{isMoreUp2 ? $t('page.close') : $t('page.open')}}
                    <i class="ivu-icon" :class="{'ivu-icon-ios-arrow-up':isMoreUp2 , 'ivu-icon-ios-arrow-down': !isMoreUp2}"></i>
                </div>
                </Col>
            </Row>
            </Col>
        </Row>

        <div class="materiels" v-if="hasData > 0">
            <div class="materiel" v-for="item in materiels" :class="{'collapsible': item.isExpend}" :key="item.materiel.ID">
                <Row type="flex">
                    <Col class="img">
                    <img :src="addRandom2Url(structurePrefix + item.materiel.Photo)" v-if="item.materiel.CategoryCode === CR" />
                    <img :src="addRandom2Url(materielPrefix + item.materiel.Photo)" v-else />
                    </Col>
                    <Col class="detail">
                    <a :href="`${appPrefix}/materielDetail?id=${item.materiel.ID}&categoryCode=${item.materiel.CategoryCode}`" class="title" v-html="`${item.materiel.ChinName}${item.materiel.ChemName ? '/' + item.materiel.ChemName : ''}`"></a>
                    <div class="sub-title" v-html="$t('page.alias') + `：${item.materiel.Alias||''}`"></div>
                    <div class="keys" v-if="item.materiel.CategoryCode === CR">
                        <Row type="flex">
                            <Col>
                            <span class="key">{{$t('page.materielNumber')}}</span>
                            <span>：</span>
                            <span class="value" v-html="item.materiel.MaterielNumber"></span>
                            </Col>
                            <Col>
                            <span class="key">{{$t('columns.CASNumber')}}</span>
                            <span>：</span>
                            <span class="value" v-html="item.materiel.CASNumber"></span>
                            </Col>
                            <Col>
                            <span class="key w73">{{$t('columns.categoryCode')}}</span>
                            <span>：</span>
                            <span class="value" v-html="item.materiel.CategoryName"></span>
                            </Col>
                        </Row>
                        <Row type="flex">
                            <Col>
                            <span class="key">{{$t('page.molecularFormula')}}</span>
                            <span>：</span>
                            <span class="value" v-html="item.materiel.MolecularFormula"></span>
                            </Col>
                            <Col>
                            <span class="key">{{$t('page.molecularWeight')}}</span>
                            <span>：</span>
                            <span class="value" v-html="item.materiel.MolecularWeight"></span>
                            </Col>
                            <Col>
                            <span class="key"></span>
                            <span></span>
                            <span class="value"></span>
                            </Col>
                        </Row>
                    </div>
                    <div class="keys" v-else>
                        <Row type="flex">
                            <Col>
                            <span class="key">{{$t('page.materielNumber')}}</span>
                            <span>：</span>
                            <span class="value" v-html="item.materiel.MaterielNumber"></span>
                            </Col>
                        </Row>
                        <Row type="flex">
                            <Col>
                            <span class="key">{{$t('columns.categoryCode')}}</span>
                            <span>：</span>
                            <span class="value" v-html="item.materiel.CategoryName"></span>
                            </Col>
                        </Row>
                    </div>
                    </Col>
                    <Col class="action">
                    <span class="toggle" @click="toggleUpDown(item)">
                        {{item.isExpend ? $t('page.open'): $t('page.close')}}
                        <Icon :type="item.isExpend ? 'ios-arrow-down' : 'ios-arrow-up'" />
                    </span>
                    <span class="favorite" :class="{'favorited': item.isFavorit}" @click="toggleFavorite(item)">
                        <Icon :type="item.isFavorit ? 'md-star' : 'md-star-outline'" />
                        {{$t('nav.favorite')}}
                    </span>
                    <div class="buttons">
                        <Button class="i-button ml10" @click="requestHistory(item)">{{$t('page.requesthistory')}}</Button>
                    </div>
                    </Col>
                </Row>
                <div class="warning" v-if="item.materiel.Dangerous === 1 || item.materiel.Pretoxic === 1 || item.materiel.Toxic === 1">
                    <Icon type="md-warning" />
                    {{$t('page.thisReagent')}}
                    <label v-if="item.materiel.Dangerous === 1">{{$t('page.dangerous')}}</label>
                    <label v-if="item.materiel.Pretoxic === 1 || item.materiel.Toxic === 1">、</label>
                    <label v-if="item.materiel.Pretoxic === 1">{{$t('page.pretoxic')}}</label>
                    <label v-if="item.materiel.Toxic === 1">、</label>
                    <label v-if="item.materiel.Toxic === 1">{{$t('page.toxic')}}</label>
                    {{$t('page.noteUse')}}
                    <span v-if="item.materiel.Dangerous === 1">
                        <img src="../../assets/img/Dangerous.png" :alt="$t('page.dangerous')" />
                    </span>
                    <span v-if="item.materiel.Pretoxic === 1">
                        <img src="../../assets/img/Pretoxic.png" :alt="$t('page.pretoxic')" />
                    </span>
                    <span v-if="item.materiel.Toxic === 1">
                        <img src="../../assets/img/toxic.png" :alt="$t('page.toxic')" />
                    </span>
                </div>
                <div class="stocks" v-show="!item.isExpend">
                    <Table :columns="mcolumns" :data="item.stock" size="small" :width="1198">
                        <template slot-scope="{ row }" slot="Barcode">
                            <a :href="`${appPrefix}/reagentDetail?id=${row.Barcode}&materielId=${row.MaterielId}`" v-html="row.Barcode"></a>
                            <span v-html="isExpiry(row.ExpiryDate)"></span>
                        </template>
                        <template slot-scope="{ row }" slot="BottleName">
                            <span class="text-dot" v-html="row.BottleName" :title="row.BottleName.replace(/<(.*?)>/g, '')"></span>
                        </template>
                        <template slot-scope="{ row }" slot="BottleType">
                            <span class="text-dot" v-html="row.BottleType" :title="row.BottleType"></span>
                        </template>
                        <template slot-scope="{ row }" slot="Purity">
                            <span class="text-dot" v-html="row.Purity" :title="row.Purity"></span>
                        </template>
                        <template slot-scope="{ row }" slot="CurrentQuantity">{{ row.CurrentQuantity + row.Unit}}</template>
                        <template slot-scope="{ row }" slot="Sublocation">
                            <span class="text-dot" v-html="row.Sublocation" :title="row.Sublocation"></span>
                        </template>
                        <template slot-scope="{ row }" slot="CatalogNumber">
                            <span class="text-dot" v-html="row.CatalogNumber" :title="row.CatalogNumber"></span>
                        </template>
                        <template slot-scope="{ row }" slot="LotNumber">
                            <span class="text-dot" v-html="row.LotNumber" :title="row.LotNumber"></span>
                        </template>
                        <template slot-scope="{ row }" slot="Supplier">
                            <span class="text-dot" v-html="row.Supplier" :title="row.Supplier"></span>
                        </template>
                        <template slot-scope="{ row }" slot="Action">
                            <!-- 有领用角色且从库存中搜索的数据才可以领用 -->
                            <shopping-ball v-if="roles.REQUEST && searchType === 'request'" targetId="sliderCart" @click="submitRequest(row, $event)">
                                <Button class="i-button" :disabled="row.disabled">{{$t('nav.request')}}</Button>
                            </shopping-ball>
                            <Button v-if="roles.APPLY" class="i-button" :to="`${appPrefix}/applicant/add?id=${row.Barcode}&type=3`">{{$t('nav.applicant')}}</Button>
                        </template>
                    </Table>
                </div>
            </div>
            <Page :total="mtotal" show-total :page-size="30" @on-change="fetchMaterielsData" v-show="mtotal > 0" />
        </div>
        <div v-else>
            <div class="no-data" v-if="searchType === 'request'">
                <img src="@/assets/img/no-data.png" alt />
                <span>
                    库中未找到匹配的物料信息，是否在
                    <a :href="`/search?searchType=history&keywords=${keywords}&warehouse=${warehouse}&categoryCode=${categoryCode}&supplier=${supplier}`">历史领用中查找</a>
                    ? 或者您可以
                    <a v-if="roles.APPLY" :href="`${appPrefix}/applicant/add`">马上申购</a>
                </span>
            </div>
            <div class="no-data history" v-else>
                <img src="@/assets/img/history.png" alt />
                <span>
                    历史记录中未找到匹配的物料信息，是否需要提交申购申?
                    <a :href="`${appPrefix}/applicant/add`" v-if="roles.APPLY">马上申购</a>
                </span>
            </div>
        </div>

        <ilab-modal :title="$t('page.requesthistory')" :footer-hide="true" ref="requestHistory" :width="1000">
            <Table :columns="columns" :data="data" size="small">
                <template slot-scope="{ row }" slot="RequestQuantity">{{ row.RequestQuantity + row.RequestUnit}}</template>
                <template slot-scope="{ row }" slot="EstimatedAmount">{{ row.EstimatedAmount + row.RequestUnit}}</template>
                <template slot-scope="{ row }" slot="Action">
                    <a :href="`${appPrefix}/applicant/add?id=${row.Barcode}&type=3`" v-if="roles.APPLY">{{$t('nav.applicant')}}</a>
                </template>
            </Table>
            <Page :total="total" show-total :page-size="10" @on-change="fetchRequestHistory" :current="pageIndex" />
        </ilab-modal>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from "@/components/layout.vue";
import ilabModal from "@/components/modal.vue";
import shoppingBall from "@/components/shoppingBall.vue";
import api from "@/api";
import utils from "@/utils/utils";

export default {
    name: "search-page",
    components: {
        ilabLayout,
        ilabModal,
        shoppingBall
    },
    beforeMount() {
        this.keywords = utils.getParams("keywords");
        this.warehouse = utils.getParams("warehouse");
        this.categoryCode = utils.getParams("categoryCode");
        this.supplier = utils.getParams("supplier");
        this.searchType = utils.getParams("searchType") || "request";
        this.molecule = utils.getParams("molecule");
        this.materielIds = this.$session.get("materielIds");
        this.molSerch = utils.getParams("molSerch") === "true";
    },
    data() {
        return {
            appPrefix: process.env.VUE_APP_prefix,
            structurePrefix: process.env.VUE_APP_structure_img_url,
            materielPrefix: process.env.VUE_APP_materiel_img_url,
            CR: process.env.VUE_APP_CR,
            categoryCode:'',
            breadcrumbs: [{
                txt: this.$i18n.t("nav.materielList")
            }],
            pageIndex: 1,
            iminentExpirationDay: "",
            isMoreUp1: false,
            isMoreUp2: false,
            materielTypes: [],
            warehouses: [],
            suppliers: [{
                Name: this.$i18n.t("page.all"),
                Code: "",
                active: true
            }],
            keywords: "",
            
            warehouse: "",
            supplier: "",
            searchType: "request",
            molecule: "",
            materiels: [],
            filterType: "",
            curMateriel: {},
            roles: utils.getCimsInfo().RoleCodes,
            mcolumns: [{
                    slot: "Barcode",
                    title: this.$i18n.t("columns.barcode"),
                    width: 190,
                    sortable: true
                },
                {
                    slot: "BottleName",
                    title: this.$i18n.t("columns.bottleName"),
                    sortable: true
                },
                {
                    slot: "BottleType",
                    title: this.$i18n.t("columns.bottleType"),
                    width: 100,
                    sortable: true
                },
                {
                    slot: "Purity",
                    title: this.$i18n.t("columns.purity"),
                    sortable: true,
                    width: 80
                },
                {
                    slot: "CurrentQuantity",
                    title: this.$i18n.t("columns.currentQuantity"),
                    sortable: true,
                    width: 90
                },
                {
                    key: "WarehouseName",
                    title: this.$i18n.t("page.warehouse"),
                    tooltip: true,
                    width: 90,
                    sortable: true
                },
                {
                    slot: "Sublocation",
                    title: this.$i18n.t("columns.sublocation"),
                    width: 110,
                    sortable: true
                },
                {
                    slot: "CatalogNumber",
                    title: this.$i18n.t("columns.catalogNumber"),
                    sortable: true,
                    width: 100
                },
                {
                    slot: "LotNumber",
                    title: this.$i18n.t("columns.lotNumber"),
                    sortable: true,
                    width: 100
                },
                {
                    slot: "Supplier",
                    title: this.$i18n.t("page.supplier"),
                    sortable: true
                },
                {
                    slot: "Action",
                    title: this.$i18n.t("columns.operation"),
                    width: 160,
                    align: "center"
                }
            ],
            columns: [{
                    key: "BottleName",
                    title: this.$i18n.t("columns.bottleName")
                },
                {
                    key: "Requester",
                    title: this.$i18n.t("columns.requester")
                },
                {
                    key: "Phone",
                    title: this.$i18n.t("columns.phone")
                },
                {
                    key: "Barcode",
                    title: this.$i18n.t("columns.barcode"),
                    width: 130
                },
                {
                    slot: "RequestQuantity",
                    title: this.$i18n.t("columns.requestQuantity"),
                    formatter: function (val, row, index) {
                        return val + row.RequestUnit;
                    }
                },
                {
                    slot: "EstimatedAmount",
                    title: this.$i18n.t("columns.estimatedAmount"),
                    formatter: function (val, row, index) {
                        return val + row.RequestUnit;
                    }
                },
                {
                    key: "RequestDate",
                    title: this.$i18n.t("columns.requestDate")
                },
                {
                    slot: "Action",
                    title: this.$i18n.t("columns.operation"),
                    width: 160,
                    align: "center"
                }
            ],
            data: [],
            total: 0,
            mtotal: 0,
            materielIds: [],
            molSerch: false,
            hasData: true,
            canToggle: true
        };
    },
    methods: {
        //更多-切换
        onMoreClick(model) {
            this[model] = !this[model];
        },
        //选中-切换
        onFilterClick(data, filter, filterType) {
            this.filterType = filterType;
            data.map(item => {
                item.active = item.Name === filter.Name;
                if (item.active) {
                    this[filterType] = item.Code;
                }
            });

            this.fetchMaterielsData();
        },
        //收起展开
        toggleUpDown(item) {
            this.$set(item, "isExpend", !!!item.isExpend);
        },
        //加载物料类型
        async fetchMaterielTypesData() {
            var categoryCode = utils.getParams("categoryCode");

            this.materielTypes = [{
                Name: this.$i18n.t("page.all"),
                Code: "",
                active: categoryCode ? false : true
            }];
            const resp = await api.cims.fetchMaterielTypesData();
            if (resp.code == process.env.VUE_APP_code) {
                resp.response.map(item => {
                    this.materielTypes.push({
                        Name: item.CategoryName,
                        Code: item.CategoryCode,
                        active: categoryCode === item.CategoryCode
                    });
                });
            }
        },
        //加载仓库
        async fetchWarehousesData() {
            var warehouse = utils.getParams("warehouse");

            this.warehouses = [{
                Name: this.$i18n.t("page.all"),
                Code: "",
                active: warehouse ? false : true
            }];

            const resp = await api.cims.fetchWarehousesData();
            if (resp.code == process.env.VUE_APP_code) {
                resp.rows.map(item => {
                    this.warehouses.push({
                        Name: item.Name,
                        Code: item.Name,
                        active: warehouse === item.Name ? true : false
                    });
                });
            }
        },
        //获取物料近效期提醒时间
        async getIminentExpirationDay() {
            const resp = await api.cims.getOrganizationConfig("iminentExpirationDay");
            if (resp.code == process.env.VUE_APP_code) {
                this.iminentExpirationDay = resp.response;
            } else {
                this.$Message.error(resp.message);
            }
        },
        //加载物料
        async fetchMaterielsData(pageIndex = 1) {
            let data = {
                pageIndex,
                warehouse: this.warehouse,
                categoryCode: this.categoryCode,
                supplier: this.supplier,
                searchType: this.searchType
            };

            if (this.molSerch) {
                data = {
                    materielIds: this.materielIds,
                    ...data
                };
            } else {
                data = {
                    text: this.keywords,
                    ...data
                };
            }
            this.$Spin.show();
            const resp = await api.cims.fetchMaterielsData(data);

            if (resp.code == process.env.VUE_APP_code) {
                this.hasData = true;
                if (this.filterType !== "supplier") {
                    (this.supplier = ""),
                    (this.suppliers = [{
                        Name: this.$i18n.t("page.all"),
                        Code: "",
                        active: true
                    }]);
                    if (resp.response) {
                        //有供应商
                        resp.response.map(item => {
                            this.suppliers.push({
                                Name: item,
                                Code: item,
                                active: false
                            });
                        });
                    }
                }

                const materielIds = resp.rows.map(item => {
                    for (let key in item.materiel) {
                        if ((item.materiel[key] + "").includes("<span>")) {
                            item.materiel[key] = item.materiel[key].replace(
                                /<span>/g,
                                '<span class="light-tag">'
                            );
                        }
                    }

                    item.stock.map(stock => {
                        for (let key in stock) {
                            if ((stock[key] + "").includes("<span>")) {
                                stock[key] = stock[key].replace(
                                    /<span>/g,
                                    '<span class="light-tag">'
                                );
                            }
                        }
                    });

                    return item.materiel.ID;
                });

                if (materielIds.length) {
                    const resp1 = await api.cims.isFavoritCheck(materielIds);
                    if (resp1.code == process.env.VUE_APP_code) {
                        resp.rows.map(item => {
                            item.isFavorit = resp1.response[item.materiel.ID];
                        });
                    }
                }
                this.materiels = resp.rows;
            } else {
                this.hasData = false;
            }
            this.$Spin.hide();
            this.mtotal = resp.total;
            this.pageIndex = pageIndex;
        },
        //收藏-切换
        async toggleFavorite(item) {
            if (this.canToggle) {
                this.canToggle = false;
                if (item.isFavorit) {
                    const resp = await api.cims.cancelFavorite(item.materiel.ID);
                    if (resp.code == process.env.VUE_APP_code) {
                        this.$Message.success(resp.message);
                        this.$set(item, "isFavorit", false);
                        this.$refs.layout.setFavoriteCount(-1);
                    } else {
                        this.$Message.error(resp.message);
                    }
                    this.canToggle = true;
                } else {
                    //添加到收藏
                    const resp = await api.cims.addToFavorite({
                        materielId: item.materiel.ID
                    });
                    if (resp.code == process.env.VUE_APP_code) {
                        this.$Message.success(resp.message);
                        this.$set(item, "isFavorit", true);
                        this.$refs.layout.setFavoriteCount();
                    } else {
                        this.$Message.error(resp.message);
                    }
                    this.canToggle = true;
                }
            }
        },
        //判断近效期
        isExpiry(date) {
            const expireDateState = [this.$i18n.t("page.overExpiryTime"),this.$i18n.t("page.withExpiryTime"),this.$i18n.t("page.inExpiryTime")];
            return utils.isExpiry(this.iminentExpirationDay, date, expireDateState);
        },
        //领用
        async submitRequest(stock, fly) {
            this.$set(stock, "disabled", true);
            const resp = await api.cims.submitRequest({
                amount: 300,
                foreignKeyId: stock.WarehouseId,
                fKID: stock.ID,
                chinName: stock.ChinName,
                compoundId: stock.CompoundId,
                materielId: stock.MaterielId,
                requestType: 1,
                requestUnit: stock.Unit,
                requestQuantity: stock.CurrentQuantity,
                barcode: stock.Barcode,
                lab: utils.getCimsInfo().UserInfo.LabName,
                phone: utils.getUcInfo().AccountInfo.MobilePhone,
                warehouseId: stock.WarehouseId,
                bottleName: stock.BottleName,
                casNumber: stock.CASNumber,
                mdlNumber: stock.MDLNumber
            });
            if (resp.code == process.env.VUE_APP_code) {
                fly();
                this.$refs.layout.setCartCount();
            } else {
                this.$Message.warning({
                    content: resp.message,
                    onClose: () => {
                        this.$set(stock, "disabled", false);
                    }
                });
            }
        },
        //查看领用历史
        async requestHistory(item) {
            this.curMateriel = item;
            this.fetchRequestHistory();
            this.$refs.requestHistory.show();
        },
        async fetchRequestHistory(pageIndex = 1) {
            const resp = await api.cims.fetchRequestHistory({
                pageIndex,
                materielId: this.curMateriel.materiel.ID
            });
            if (resp.code == process.env.VUE_APP_code) {
                this.data = resp.rows;
                this.total = resp.total;
            } else {
                this.data = [];
            }
        },
        //结构式图片URL添加随机数
        addRandom2Url: (url) => utils.addRandom2Url(url)
    },
    async mounted() {
        this.$Spin.show();
        await this.fetchMaterielTypesData();
        await this.fetchWarehousesData();
        await this.getIminentExpirationDay();
        await this.fetchMaterielsData();
    }
};
</script>

<style lang="less" scoped>
.content {
    .filters {
        margin-top: 15px;
        border: 1px solid #e0e0e0;
        border-radius: 2px;
        color: #000;
        font-size: 13px;

        .ivu-row-flex {
            padding: 12px 0 12px 15px;
            border-bottom: 1px dashed #e0e0e0;

            &.no-bottom {
                border-bottom: none;
            }

            .key {
                width: 70px;
                text-align: right;
                color: #bfbfbf;
                padding-right: 10px;
            }

            .value {
                flex: 1;
                line-height: 26px;
                transition: 0.4s;

                &.single-row {
                    height: 26px;
                    overflow: hidden;
                }

                .item {
                    padding: 1px 6px;
                    display: inline-block;
                    cursor: pointer;
                    margin: 0 5px 0 0;
                    line-height: 22px;

                    &:not(.active):hover {
                        color: #1388ff;
                    }

                    &.active {
                        background-color: #1388ff;
                        color: #fff;
                    }
                }
            }

            .more {
                width: 100px;
                text-align: center;
                cursor: pointer;

                >div {
                    position: relative;
                    top: 3px;
                }

                &:hover {
                    color: #1388ff;
                }
            }
        }
    }

    .text-dot {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        display: block;
    }

    .materiels {
        .materiel {
            border: 1px solid #ddd;
            border-bottom: none;
            margin-top: 15px;

            .warning {
                margin: 0 12px 12px;
                border-radius: 4px;
                padding: 0 20px;
                border: 1px solid #ffa29f;
                background-color: #fff1f1;
                color: #2b2b2b;
                line-height: 36px;
                position: relative;

                .ivu-icon {
                    font-size: 20px;
                    color: #ee1b1f;
                    margin-right: 2px;
                    position: relative;
                    top: -2px;
                }

                span {
                    padding-left: 40px;
                    position: relative;
                    margin: 0 10px;
                }

                img {
                    width: 30px;
                    position: absolute;
                    top: -8px;
                    left: 0;
                    margin-left: 6px;
                }
            }

            /deep/ .light-tag {
                color: #e51c22;
            }

            &.collapsible {
                border-bottom: 1px solid #ddd;
            }

            >.ivu-row-flex {
                padding: 12px;
            }

            .img {
                height: 130px;
                width: 130px;
                padding: 5px;
                border: 1px solid #bbb;

                img {
                    max-width: 100%;
                    max-height: 100%;
                    position: relative;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                }
            }

            .detail {
                width: 894px;
                padding: 0 12px;

                .title {
                    font-size: 16px;
                    line-height: 24px;
                    .text-dot;
                    width: 100%;
                }

                .sub-title {
                    color: #101010;
                    font-size: 13px;
                    margin: 9px 0;
                    .text-dot;
                }

                .ivu-row-flex {
                    margin-top: 12px;

                    .ivu-col {
                        flex: 1;
                        height: 18px;
                        line-height: 18px;

                        span {
                            float: left;
                        }
                    }

                    .key {
                        display: inline-block;
                        min-width: 50px;
                        height: 18px;
                        overflow: hidden;
                        text-align: justify;

                        &:after {
                            display: inline-block;
                            width: 100%;
                            content: "";
                        }

                        &.w73 {
                            // width: 79px;
                        }
                    }

                    .value {
                        .text-dot;
                        padding-left: 6px;
                        // width: 190px;
                        height: 18px;
                    }
                }
            }

            .action {
                height: 130px;
                width: 150px;
                position: relative;
                text-align: center;

                span {
                    display: inline-block;
                    width: 50%;
                    font-size: 12px;
                    cursor: pointer;

                    &:hover {
                        color: #1388ff;
                    }

                    &.toggle {
                        margin-top: 55px;
                        text-align: right;
                    }

                    &.favorite {
                        &.favorited {
                            .ivu-icon {
                                color: #ff9800;

                                &:before {
                                    color: #ff9800;
                                }
                            }
                        }

                        i {
                            display: block;
                            color: #c3c3c3;
                            font-size: 24px;
                        }
                    }
                }

                .buttons {
                    margin-top: 28px;
                }
            }
        }

        .stocks {
            .ivu-table-wrapper {
                border: none;
                overflow: inherit;

                /deep/ .ivu-table {
                    overflow: inherit;
                }

                /deep/ .ivu-table-tbody .ivu-table-column-center .ivu-table-cell {
                    overflow: inherit;
                }
            }

            /deep/ .ivu-table:after {
                display: none;
            }

            /deep/ .light-tag {
                color: #e51c22;
            }

            /deep/ .ivu-table-tbody {
                td {
                    border-bottom: 1px dashed #e8eaec;
                }
            }
        }

        .i-button {
            border: 1px solid #ff6100;
            color: #ff6100;
            transition: 0.4s;
            height: 27px;
            line-height: 14px;
            border-radius: 2px;
            margin: 0 6px 0 0;

            &:last-child {
                margin-right: 0;
            }

            &.ml10 {
                margin-left: 20px;
            }

            &:disabled {
                border-color: #999;
                background-color: #dfdfdf;
                color: #9f9f9f;
            }

            &:not(:disabled):hover {
                background-color: #ff6100;
                color: #ffffff;
            }
        }
    }

    .no-data {
        margin: 50px auto 0;
        text-align: center;
        line-height: 26px;
        font-size: 15px;

        img {
            width: 170px;
            height: 130px;
        }

        span {
            position: relative;
            top: -30px;
            left: 30px;
            text-align: left;
            display: inline-block;
            width: 370px;
        }
    }
}
</style>
