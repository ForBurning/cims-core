<template>
<ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
        <div class="page-info">
            <div class="chinName">我的采购</div>
            <div class="chemName">My Procurement</div>
        </div>

        <Tabs v-model="name" class="ilab-tabs" :animated="false" @on-click="onTabsClick">
            <TabPane :label="$t('page.all')" name="1">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.bottleName')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.applicantDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="columns1" :data="data" :noDataText="noDataText" ref="table1">
                    <template slot-scope="{ row }" slot="ChinName">
                        <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />

                <Row class="batch-operation" v-if="total > 0">
                    <Col span="12">&nbsp;</Col>
                    <Col span="12">
                    <Button size="large" type="primary" @click="batchExport" :loading="exportLoading">
                        <span v-if="exportLoading">{{$t('columns.exporting')}}...</span>
                        <span v-else>{{$t('btn.exportPurchase')}}</span>
                    </Button>
                    </Col>
                </Row>
            </TabPane>

            <TabPane :label="$t('tab.receiving')" name="2">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.bottleName')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.applicantDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="columns2" :data="data" :noDataText="noDataText" ref="table2" @on-select="getSelectCount" @on-select-all="getSelectCount" @on-select-all-cancel="getSelectCount" @on-select-cancel="getSelectCount">
                    <template slot-scope="{ row }" slot="ChinName">
                        <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />

                <Row class="batch-operation" v-if="total > 0">
                    <Col span="12">
                    <Button class="select-all-btn" @click="selectAll">{{selectCount === data.length ? $t('btn.cancelAll') : $t('btn.selectAll')}}</Button>
                    </Col>
                    <Col span="12">
                    <Button size="large" type="primary" :disabled="selectCount === 0" @click="batchReceive" :loading="loading">
                        <span v-if="loading">{{$t('btn.receiving')}}...</span>
                        <span v-else>{{$t('btn.batchReceive')}}</span>
                    </Button>
                    </Col>
                </Row>
            </TabPane>

            <TabPane :label="$t('tab.received')" name="3">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.bottleName')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.applicantDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="columns2" :data="data" :noDataText="noDataText" ref="table3" @on-select="getSelectCount" @on-select-all="getSelectCount" @on-select-all-cancel="getSelectCount" @on-select-cancel="getSelectCount">
                    <template slot-scope="{ row }" slot="ChinName">
                        <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />

                <Row class="batch-operation" v-if="total > 0">
                    <Col span="12">
                    <Button class="select-all-btn" @click="selectAll">{{selectCount === data.length ? $t('btn.cancelAll') : $t('btn.selectAll')}}</Button>
                    </Col>
                    <Col span="12">
                    <Button size="large" type="primary" :disabled="selectCount === 0" @click="openModal(1)">{{$t('btn.purProcess')}}</Button>
                    <Button size="large" type="primary" @click="batchExport" :loading="exportLoading">
                        <span v-if="exportLoading">{{$t('btn.exporting')}}...</span>
                        <span v-else>{{$t('btn.exportPurchase')}}</span>
                    </Button>
                    </Col>
                </Row>
            </TabPane>

            <TabPane :label="$t('tab.receipt')" name="4">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.bottleName')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.applicantDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="columns2" :data="data" :noDataText="noDataText" ref="table4" @on-select="getSelectCount" @on-select-all="getSelectCount" @on-select-all-cancel="getSelectCount" @on-select-cancel="getSelectCount">
                    <template slot-scope="{ row }" slot="ChinName">
                        <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />

                <Row class="batch-operation" v-if="total > 0">
                    <Col span="12">
                    <Button class="select-all-btn" @click="selectAll">{{selectCount === data.length ? $t('btn.cancelAll') : $t('btn.selectAll')}}</Button>
                    </Col>
                    <Col span="12">
                    <Button size="large" type="primary" :disabled="selectCount === 0" @click="openModal(2)" :loading="loading">{{$t('btn.batchReceived')}}</Button>
                    </Col>
                </Row>
            </TabPane>

            <TabPane :label="$t('tab.arrived')" name="5">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.bottleName')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.applicantDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="columns3" :data="data" :noDataText="noDataText" ref="table5" @on-select="getSelectCount" @on-select-all="getSelectCount" @on-select-all-cancel="getSelectCount" @on-select-cancel="getSelectCount">
                    <template slot-scope="{ row }" slot="ChinName">
                        <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />

                <Row class="batch-operation" v-if="total > 0">
                    <Col span="12">
                    <Button class="select-all-btn" @click="selectAll">{{selectCount === data.length ? $t('btn.cancelAll') : $t('btn.selectAll')}}</Button>
                    </Col>
                    <Col span="12">
                    <Button size="large" type="primary" :disabled="selectCount === 0" @click="settleAccounts" :loading="loading">
                        <span v-if="loading">{{$t('btn.settlementting')}}...</span>
                        <span v-else>{{$t('btn.settlement')}}</span>
                    </Button>
                    <Button size="large" type="primary" :disabled="selectCount === 0" @click="batchExport" :loading="exportLoading">
                        <span v-if="exportLoading">{{$t('btn.exporting')}}...</span>
                        <span v-else>{{$t('btn.exporting')}}</span>
                    </Button>
                    </Col>
                </Row>
            </TabPane>
        </Tabs>

        <Modal :title="$t('form.perfectPurInfo')" v-model="modal" @on-ok="batchPurchase" :loading="modalLoading" width="1300">
            <Table :columns="purchaseColumns" :data="purchaseData" :noDataText="noDataText" ref="purchaseTable" class="ilab-table-no-bottom">
                <template slot-scope="{ row, index  }" slot="Specifications">
                    <Input :value="row.InitialQuantity" class="ilab-input-group" @on-blur="updataCell($event, 'InitialQuantity', index)">
                    <Select slot="append" style="width: 68px" v-model="row.Unit" @on-change="updataCell($event, 'Unit', index)" transfer clearable>
                        <Option v-for="item in unit" :value="item.Code" :key="item.Code">{{item.Name}}</Option>
                    </Select>
                    <Select slot="append" style="width: 68px" v-model="row.PackingUnit" clearable transfer @on-change="updataCell($event, 'PackingUnit', index)">
                        <Option v-for="item in packingUnit" :value="item.Code" :key="item.Code">{{item.Name}}</Option>
                    </Select>
                    </Input>
                </template>
                <template slot-scope="{ row, index  }" slot="Purity">
                    <Poptip trigger="focus">
                        <Input v-model="row.Purity" @on-blur="updataCell($event, 'Purity', index)"></Input>
                        <div slot="content">{{ row.Purity }}</div>
                    </Poptip>
                </template>
                <template slot-scope="{ row, index  }" slot="Number">
                    <Input :min="1" v-model="row.Number" @on-blur="updataCell($event, 'Number', index)"></Input>
                </template>
                <template slot-scope="{ row, index  }" slot="Price">
                    <Input :min="0" v-model="row.Price" @on-blur="updataCell($event, 'Price', index)"></Input>
                </template>
                <template slot-scope="{ row, index  }" slot="Supplier">
                    <Poptip trigger="focus">
                        <Input v-model="row.Supplier" @on-blur="updataCell($event, 'Supplier', index)"></Input>
                        <div slot="content">{{ row.Supplier }}</div>
                    </Poptip>
                </template>
                <template slot-scope="{ row, index  }" slot="Producer">
                    <Poptip trigger="focus">
                        <Input v-model="row.Producer" @on-blur="updataCell($event, 'Producer', index)"></Input>
                        <div slot="content">{{ row.Producer }}</div>
                    </Poptip>
                </template>
                <template slot-scope="{ row, index  }" slot="PONumber">
                    <Poptip trigger="focus">
                        <Input v-model="row.PONumber" @on-blur="updataCell($event, 'PONumber', index)"></Input>
                        <div slot="content">{{ row.PONumber }}</div>
                    </Poptip>
                </template>
                <template slot-scope="{ row, index  }" slot="LotNumber">
                    <Poptip trigger="focus">
                        <Input v-model="row.LotNumber" @on-blur="updataCell($event, 'LotNumber', index)"></Input>
                        <div slot="content">{{ row.LotNumber }}</div>
                    </Poptip>
                </template>
                <template slot-scope="{ row, index  }" slot="ExpectationPeriod">
                    <DatePicker type="date" @on-change="updataCell($event, 'ExpectationPeriod', index)" :value="row.ExpectationPeriod" split-panels transfer></DatePicker>
                </template>
            </Table>
        </Modal>

        <Modal :title="$t('form.fillReceiptInfo')" v-model="modal1" @on-ok="batchReceived" :loading="modalLoading" width="1300">
            <Table :columns="receiveColumns" :data="receiveData" :noDataText="noDataText" ref="receiveTable" class="ilab-table-no-bottom">
                <template slot-scope="{ row, index  }" slot="Specifications">
                    <Input :value="row.InitialQuantity" class="ilab-input-group" @on-blur="updataCell($event, 'InitialQuantity', index)">
                    <Select slot="append" style="width: 50px" v-model="row.Unit" clearable transfer @on-change="updataCell($event, 'Unit', index)">
                        <Option v-for="item in unit" :value="item.Code" :key="item.Name">{{item.Name}}</Option>
                    </Select>
                    <Select slot="append" style="width: 50px" v-model="row.PackingUnit" clearable transfer @on-change="updataCell($event, 'PackingUnit', index)">
                        <Option v-for="item in packingUnit" :value="item.Code" :key="item.Name">{{item.Name}}</Option>
                    </Select>
                    </Input>
                </template>
                <template slot-scope="{ row, index  }" slot="ExpiryDate">
                    <DatePicker type="date" @on-change="updataCell($event, 'ExpiryDate', index)" :value="row.ExpiryDate" split-panels transfer></DatePicker>
                </template>
                <template slot-scope="{ row, index  }" slot="Producer">
                    <Poptip trigger="focus">
                        <Input v-model="row.Producer" @on-blur="updataCell($event, 'Producer', index)"></Input>
                        <div slot="content">{{ row.Producer }}</div>
                    </Poptip>
                </template>
                <template slot-scope="{ row, index  }" slot="PONumber">
                    <Poptip trigger="focus">
                        <Input v-model="row.PONumber" @on-blur="updataCell($event, 'PONumber', index)"></Input>
                        <div slot="content">{{ row.PONumber }}</div>
                    </Poptip>
                </template>
                <template slot-scope="{ row, index  }" slot="LotNumber">
                    <Poptip trigger="focus">
                        <Input v-model="row.LotNumber" @on-blur="updataCell($event, 'LotNumber', index)"></Input>
                        <div slot="content">{{ row.LotNumber }}</div>
                    </Poptip>
                </template>
                <template slot-scope="{ row, index  }" slot="CatalogNumber">
                    <Poptip trigger="focus">
                        <Input v-model="row.CatalogNumber" @on-blur="updataCell($event, 'CatalogNumber', index)"></Input>
                        <div slot="content">{{ row.CatalogNumber }}</div>
                    </Poptip>
                </template>
                <template slot-scope="{ row, index  }" slot="WarehouseId">
                    <Select v-model="row.WarehouseId" @on-change="updataCell($event, 'WarehouseId', index)" transfer clearable>
                        <Option v-for="item in warehouses" :value="item.ID" :key="item.ID">{{item.Name}}</Option>
                    </Select>
                </template>
                <template slot-scope="{ row, index  }" slot="Origin">
                    <Select v-model="row.Origin" @on-change="updataCell($event, 'Origin', index)" transfer clearable>
                        <Option v-for="item in bottleOrigin" :value="item.Code" :key="item.Code">{{item.Name}}</Option>
                    </Select>
                </template>
            </Table>
        </Modal>

        <a href :download="$t('page.purchaseOrder')" id="file"></a>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from "@/components/layout.vue";
import api from "@/api";
import utils from "@/utils/utils";
import columns from "@/utils/columns";

export default {
    name: "purchase-page",
    components: {
        ilabLayout
    },
    data() {
        return {
            noDataText: this.$i18n.t("columns.noDataText"),
            appPrefix: process.env.VUE_APP_prefix,
            name: "1",
            breadcrumbs: [{
                txt: this.$i18n.t("nav.myProcurement")
            }],
            columns1: [
                columns.PurchaseCode(this.$i18n.t('columns.purchaseCode')),
                columns.ChinName(this.$i18n.t('columns.bottleName')),
                columns.CASNumber(this.$i18n.t('columns.CASNumber')),
                columns.Specifications(this.$i18n.t('columns.bottleType')),
                columns.Purity(this.$i18n.t('columns.bOrp')),
                columns.number(this.$i18n.t('columns.number')),
                columns.Price(this.$i18n.t('columns.price')),
                columns.TotalPrice(this.$i18n.t('columns.totalPrice')),
                columns.ApplyTime(this.$i18n.t('columns.applyTime')),
                columns.Applicant(this.$i18n.t('columns.applicant')),
                columns.ShowState(this.$i18n.t('columns.state'))
            ],
            columns2: [
                columns.Select,
                columns.PurchaseCode(this.$i18n.t('columns.purchaseCode')),
                columns.ChinName(this.$i18n.t('columns.bottleName')),
                columns.CASNumber(this.$i18n.t('columns.CASNumber')),
                columns.Specifications(this.$i18n.t('columns.bottleType')),
                columns.Purity(this.$i18n.t('columns.bOrp')),
                columns.number(this.$i18n.t('columns.number')),
                columns.Price(this.$i18n.t('columns.price')),
                columns.TotalPrice(this.$i18n.t('columns.totalPrice')),
                columns.ApplyTime(this.$i18n.t('columns.applyTime')),
                columns.Applicant(this.$i18n.t('columns.applicant')),
            ],
            columns3: [
                columns.Select,
                columns.PurchaseCode(this.$i18n.t('columns.purchaseCode')),
                columns.ChinName(this.$i18n.t('columns.bottleName')),
                columns.CASNumber(this.$i18n.t('columns.CASNumber')),
                columns.Specifications(this.$i18n.t('columns.bottleType')),
                columns.Purity(this.$i18n.t('columns.bOrp')),
                columns.number(this.$i18n.t('columns.number')),
                columns.Price(this.$i18n.t('columns.price')),
                columns.TotalPrice(this.$i18n.t('columns.totalPrice')),
                columns.ApplyTime(this.$i18n.t('columns.applyTime')),
                columns.Applicant(this.$i18n.t('columns.applicant')),
                columns.IsSettleAccounts(this.$i18n.t('columns.state'), this.$i18n)
            ],
            purchaseColumns: [{
                    key: "ChinName",
                    title: this.$i18n.t('columns.bottleName'),
                    tooltip: true
                },
                {
                    slot: "Specifications",
                    title: this.$i18n.t('columns.bottleType'),
                    width: 200
                },
                {
                    slot: "Purity",
                    title: this.$i18n.t('columns.bOrp'),
                    width: 150
                },
                {
                    slot: "Number",
                    title: this.$i18n.t('columns.number'),
                },
                {
                    slot: "Price",
                    title: this.$i18n.t('columns.price'),
                },
                {
                    slot: "Supplier",
                    title: this.$i18n.t('page.supplier'),
                },
                {
                    slot: "Producer",
                    title: this.$i18n.t('columns.producer'),
                },
                {
                    slot: "PONumber",
                    title: this.$i18n.t('columns.poNumber'),
                },
                {
                    slot: "LotNumber",
                    title: this.$i18n.t('columns.lotNumber'),
                },
                {
                    slot: "ExpectationPeriod",
                    title: this.$i18n.t('columns.estimatedArrivalTime'),
                    width: 140
                }
            ],
            receiveColumns: [{
                    key: "ChinName",
                    title: this.$i18n.t('columns.bottleName'),
                    tooltip: true
                },
                {
                    key: "Number",
                    title: this.$i18n.t('columns.number'),
                },
                {
                    key: "Applicant",
                    title: this.$i18n.t('columns.applicant')
                },
                {
                    key: "ProjectName",
                    title: this.$i18n.t('columns.projectCode')
                },
                {
                    slot: "Specifications",
                    title: this.$i18n.t('columns.bottleType'),
                    width: 200
                },
                {
                    slot: "ExpiryDate",
                    title: this.$i18n.t('columns.expiryDate'),
                    width: 140
                },
                {
                    slot: "Producer",
                    title: this.$i18n.t('columns.producer'),
                },
                {
                    slot: "PONumber",
                    title: this.$i18n.t('columns.poNumber'),
                },
                {
                    slot: "LotNumber",
                    title: this.$i18n.t('columns.lotNumber'),
                },
                {
                    slot: "CatalogNumber",
                    title: this.$i18n.t('columns.catalogNumber'),
                },
                {
                    slot: "WarehouseId",
                    title: this.$i18n.t('page.warehouse'),
                    width: 100
                },
                {
                    slot: "Origin",
                    title: this.$i18n.t('columns.origin'),
                    width: 100
                }
            ],
            purchaseData: [],
            receiveData: [],
            data: [],
            total: 0,
            pageIndex: 1,
            condition1: "",
            condition2: "",
            selectCount: 0,
            loading: false,
            exportLoading: false,
            modal: false,
            modalLoading: true,
            modal1: false,
            warehouses: [],
            unit: [],
            packingUnit: [],
            bottleOrigin: []
        };
    },
    methods: {
        //加载包装单位
        async fetchDicItem(dic) {
            const resp = await api.cims.fetchDicItem(dic);
            this[dic] = resp.rows;
        },
        updataCell(event, key, index) {
            const modal = this.name === "3" ? "purchaseData" : "receiveData";
            let row = utils.deepCopy(this[modal][index]);
            row[key] = [
                    "Unit",
                    "PackingUnit",
                    "ExpectationPeriod",
                    "ExpiryDate",
                    "WarehouseId",
                    "Origin"
                ].includes(key) ?
                event :
                event.target.value;
            this[modal][index] = row;
        },
        //打开撤回模态框
        openModal(type) {
            if (type === 1) {
                this.purchaseData = this.$refs[`table${this.name}`].getSelection();
                this.modal = true;
            } else {
                this.receiveData = this.$refs[`table${this.name}`].getSelection();
                this.modal1 = true;
            }
        },
        //关闭loading
        resetLoading() {
            this.modalLoading = false;
            setTimeout(() => {
                this.modalLoading = true;
            }, 0);
        },
        //全选
        selectAll() {
            const isSelectAll = this.selectCount === this.data.length;
            if (isSelectAll) {
                this.$refs[`table${this.name}`].selectAll(false);
                this.selectCount = 0;
            } else {
                this.$refs[`table${this.name}`].selectAll(true);
                this.selectCount = this.data.length;
            }
        },
        getSelectCount() {
            this.selectCount = this.$refs[`table${this.name}`].getSelection().length;
        },
        //tab切换
        onTabsClick(tabName) {
            this.condition1 = "";
            this.condition2 = "";
            this.data = [];
            this.total = 0;
            this.loading = false;
            this.exportLoading = false;
            this.selectCount = 0;
            this.fetchData();
        },
        //加载仓库
        async fetchWarehousesData() {
            const resp = await api.cims.fetchWarehousesData();
            if (resp.code == process.env.VUE_APP_code) {
                this.warehouses = resp.rows;
            }
        },
        //批量导出
        async batchExport() {
            this.exportLoading = true;
            const resp = await api.cims.batchExportPurchase({
                chinName: this.condition1,
                applyBeginTime: this.condition2.length ? this.condition2[0] : "",
                applyEndTime: this.condition2.length ? this.condition2[1] : "",
                purchasesSerachState: this.name === "3" ?
                    "Processed" : this.name === "4" ?
                    "Placed" : this.name === "5" ?
                    "Arrived" : ""
            });
            if (resp.code == process.env.VUE_APP_code) {
                const file = document.getElementById("file");
                file.setAttribute("href", process.env.VUE_APP_file_url + resp.response);
                file.click();
            } else {
                this.$Message.error(resp.message);
            }
            this.exportLoading = false;
        },
        //批量接收
        async batchReceive() {
            this.loading = true;
            const selection = this.$refs[`table${this.name}`].getSelection();
            const resp = await api.cims.purchasesHandle({
                ids: selection.map(item => item.ID)
            });
            if (resp.code == process.env.VUE_APP_code) {
                this.$Message.success(resp.message);
                this.fetchData();
            } else {
                this.$Message.error(resp.message);
            }
            this.loading = false;
        },
        //批量采购
        async batchPurchase() {
            let valid = true;

            this.purchaseData.map((item, index) => {
                const rowIndex = index + 1;
                if (valid) {
                    if (item.InitialQuantity === "") {
                        if (item.Unit || item.PackingUnit) {
                            this.$Message.warning(
                                this.$i18n.t("message.index", [rowIndex, this.$i18n.t("message.incomplete", [this.$i18n.t("columns.bottleType")])])
                            );
                            valid = false;
                        }
                    } else if (!utils.isPositive(item.InitialQuantity)) {
                        this.$Message.warning(this.$i18n.t("message.index", [rowIndex, this.$i18n.t("message.overZero", [this.$i18n.t("columns.bottleType")])]));
                        valid = false;
                    } else if (item.InitialQuantity.length > 10) {
                        this.$Message.error(this.$i18n.t("message.index", [
                            index + 1,
                            this.$i18n.t("message.notOver", [
                                this.$i18n.t("columns.bottleType"),
                                10
                            ])
                        ]));
                        valid = false;
                    } else if (!item.Unit || !item.PackingUnit) {
                        this.$Message.warning(this.$i18n.t("message.index", [rowIndex, this.$i18n.t("message.incomplete", [this.$i18n.t("columns.bottleType")])]));
                        valid = false;
                    } else if (item.Purity && item.Purity.length > 100) {
                        this.$Message.error(this.$i18n.t("message.index", [
                            index + 1,
                            this.$i18n.t("message.notOver", [
                                this.$i18n.t("columns.bOrp"),
                                100
                            ])
                        ]));
                        valid = false;
                    } else if (!!!item.Number) {
                        this.$Message.warning(this.$i18n.t("message.index", [rowIndex, this.$i18n.t("message.notNull", [this.$i18n.t("columns.number")])]));
                        valid = false;
                    } else if (!utils.isInteger(item.Number)) {
                        this.$Message.warning(this.$i18n.t("message.index", [rowIndex, this.$i18n.t("message.isInteger", [this.$i18n.t("columns.number")])]));
                        valid = false;
                    } else if (item.Number > 50 || item.Number <= 0) {
                        this.$Message.warning(this.$i18n.t("message.index", [rowIndex, this.$i18n.t("message.notMore", [this.$i18n.t("columns.number"), 50])]));
                        valid = false;
                    } else if (!!!item.Price && valid) {
                        this.$Message.warning(this.$i18n.t("message.index", [rowIndex, this.$i18n.t("message.notNull", [this.$i18n.t("columns.price")])]));
                        valid = false;
                    } else if (!utils.isPositive(item.Price)) {
                        this.$Message.warning(this.$i18n.t("message.index", [rowIndex, this.$i18n.t("message.overZero", [this.$i18n.t("columns.price")])]));
                        valid = false;
                    } else if (item.Price.length > 10) {
                        this.$Message.error(this.$i18n.t("message.index", [
                            rowIndex,
                            this.$i18n.t("message.notOver", [
                                this.$i18n.t("page.Price"),
                                10
                            ])
                        ]));
                        valid = false;
                    } else if (item.Supplier && item.Supplier.length > 50) {
                        this.$Message.error(this.$i18n.t("message.index", [
                            rowIndex,
                            this.$i18n.t("message.notOver", [
                                this.$i18n.t("page.supplier"),
                                50
                            ])
                        ]));
                        valid = false;
                    } else if (item.Producer && item.Producer.length > 50) {
                        this.$Message.error(this.$i18n.t("message.index", [
                            rowIndex,
                            this.$i18n.t("message.notOver", [
                                this.$i18n.t("columns.producer"),
                                50
                            ])
                        ]));
                        valid = false;
                    } else if (item.PONumber && item.PONumber.length > 50) {
                        this.$Message.error(this.$i18n.t("message.index", [
                            rowIndex,
                            this.$i18n.t("message.notOver", [
                                this.$i18n.t("columns.poNumber"),
                                50
                            ])
                        ]));
                        valid = false;
                    } else if (item.LotNumber && item.LotNumber.length > 50) {
                        this.$Message.error(this.$i18n.t("message.index", [
                            rowIndex,
                            this.$i18n.t("message.notOver", [
                                this.$i18n.t("columns.lotNumber"),
                                50
                            ])
                        ]));
                        valid = false;
                    }
                }
            });

            if (valid) {
                let data = {
                    list: []
                };

                this.purchaseData.map((item, index) => {
                    item.Specifications =
                        item.InitialQuantity + item.Unit + "/" + item.PackingUnit;
                    data.list.push({
                        id: item.ID,
                        estimatedArrival: item.ExpectationPeriod,
                        purchasesUpdateState: 40,
                        updatePurchaseInfo: this.purchaseData[index]
                    });
                });

                const resp = await api.cims.purchasesUpdateHandle(data);
                if (resp.code == process.env.VUE_APP_code) {
                    this.$Message.success(resp.message);
                    this.modal = false;
                    this.fetchData();
                } else {
                    this.$Message.error(resp.message);
                    this.resetLoading();
                }
            } else {
                this.resetLoading();
            }
        },
        //批量收货
        async batchReceived() {
            let valid = true;

            this.receiveData.map((item, index) => {
                if (valid) {
                    const rowIndex = index + 1;
                    if (item.InitialQuantity === "") {
                        if (item.Unit || item.PackingUnit) {
                            this.$Message.warning(
                                this.$i18n.t("message.index", [rowIndex, this.$i18n.t("message.incomplete", [this.$i18n.t("columns.bottleType")])])
                            );
                            valid = false;
                        }
                    } else if (!utils.isPositive(item.InitialQuantity)) {
                        this.$Message.warning(
                            this.$i18n.t("message.index", [rowIndex, this.$i18n.t("message.overZero", [this.$i18n.t("columns.bottleType")])])
                        );
                        valid = false;
                    } else if (!item.Unit || !item.PackingUnit) {
                        this.$Message.warning(
                            this.$i18n.t("message.index", [rowIndex, this.$i18n.t("message.incomplete", [this.$i18n.t("columns.bottleType")])])
                        );
                        valid = false;
                    } else if (!!!item.ExpiryDate && valid) {
                        this.$Message.warning(
                            this.$i18n.t("message.index", [rowIndex, this.$i18n.t("message.notNull", [this.$i18n.t("columns.effectiveDate")])])
                        );
                        valid = false;
                    } else if (!!!item.WarehouseId) {
                        this.$Message.warning(
                            this.$i18n.t("message.index", [rowIndex, this.$i18n.t("message.notNull", [this.$i18n.t("page.warehouseName")])])
                        );
                        valid = false;
                    }
                }
            });

            if (valid) {
                let data = {
                    arrivePurchaseInfo: []
                };

                this.receiveData.map((item, index) => {
                    let WarehouseName = "";
                    this.warehouses.map(warehouse => {
                        if (warehouse.ID === item.WarehouseId) {
                            WarehouseName = warehouse.Name;
                        }
                    });

                    item.Specifications =
                        item.InitialQuantity + item.Unit + "/" + item.PackingUnit;
                    item.PurchaseId = item.ID;
                    item.MaterielId = item.ID;
                    item.WarehouseName = WarehouseName;

                    data.arrivePurchaseInfo.push(item);
                });

                const resp = await api.cims.purchasesReceivedHandle(data);
                if (resp.code == process.env.VUE_APP_code) {
                    this.$Message.success(resp.message);
                    this.modal1 = false;
                    this.fetchData();
                } else {
                    this.$Message.error(resp.message);
                    this.resetLoading();
                }
            } else {
                this.resetLoading();
            }
        },
        //结算
        async settleAccounts() {
            this.loading = true;
            const selection = this.$refs[`table${this.name}`].getSelection();
            const resp = await api.cims.settleAccountsHandle({
                purchaseIds: selection.map(item => item.ID)
            });
            if (resp.code == process.env.VUE_APP_code) {
                this.$Message.success(resp.message);
                this.fetchData();
            } else {
                this.$Message.error(resp.message);
                this.loading = false;
            }
        },
        //获取表格数据
        async fetchData(pageIndex = 1) {
            this.noDataText = this.$i18n.t("columns.noDataText");

            let resp = await api.cims[`fetchPurchaseTab${this.name === "2" ? 2 : 1}`]({
                pageIndex: pageIndex,
                chinName: this.condition1,
                applyBeginTime: this.condition2.length ? this.condition2[0] : "",
                applyEndTime: this.condition2.length ? this.condition2[1] : "",
                purchasesSerachState: this.name === "3" ?
                    "Processed" : this.name === "4" ?
                    "Placed" : this.name === "5" ?
                    "Arrived" : ""
            });
            if (resp.code == process.env.VUE_APP_code) {
                this.data = resp.rows;
                this.total = resp.total;
            } else {
                this.data = [];
                this.total = 0;
                this.noDataText = this.$i18n.t("columns.noDataText2");
            }
            this.pageIndex = pageIndex;
            this.selectCount = 0;
            this.loading = false;
            this.exportLoading = false;
        }
    },
    mounted() {
        this.fetchDicItem("unit");
        this.fetchDicItem("packingUnit");
        this.fetchDicItem("bottleOrigin");
        this.fetchData();
        this.fetchWarehousesData();
    }
};
</script>

<style lang="less" scoped>
.content {}
</style>
