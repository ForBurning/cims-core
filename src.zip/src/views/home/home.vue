<template>
<ilab-layout class="home-page">
    <Row slot="content" class="content">
        <Col span="16">
        <Tabs :animated="false" @on-click="fetchRequestData" v-if="roles.REQUEST">
            <div slot="extra">
                <i class="request-icon"></i>
                <span class="title">{{$t('nav.my')}}{{$t('nav.request')}}</span>
                <a :href="appPrefix + '/request'" class="more">{{$t('page.more')}}</a>
            </div>
            <TabPane :label="$t('tab.approving')" name="requestTab">
                <Table :columns="approvingColumns" :data="approvingData"></Table>
            </TabPane>
            <TabPane :label="$t('tab.receipting')" name="receiveTab">
                <Table :columns="receivingColumns" :data="receivingData"></Table>
            </TabPane>
        </Tabs>

        <Tabs :animated="false" class="sign-tab" v-if="roles.REQUEST">
            <TabPane>
                <v-chart :options="requestStatistic" style="width: 100%;" />
            </TabPane>
        </Tabs>

        <Tabs :animated="false" @on-click="fetchRequestApproveData" v-if="roles.ORDERAPPROVE || roles.APPLYAPPROVE">
            <div slot="extra">
                <i class="audit-icon"></i>
                <span class="title" id="approve">{{$t('nav.my')}}{{$t('nav.approve')}}</span>
                <a :href="approveHref" class="more">{{$t('page.more')}}</a>
            </div>
            <TabPane :label="$t('nav.requestApprove')" name="approveTab" v-if="roles.ORDERAPPROVE">
                <Table :columns="requestApproveColumns" :data="requestApproveData"></Table>
            </TabPane>
            <TabPane :label="$t('nav.applicantApprove')" name="applicantTab" v-if="roles.APPLYAPPROVE">
                <Table :columns="applicantApproveColumns" :data="applicantApproveData"></Table>
            </TabPane>
        </Tabs>

        <Tabs :animated="false" class="sign-tab" v-if="roles.APPLY">
            <div slot="extra">
                <i class="purchase-icon"></i>
                <span class="title">{{$t('nav.my')}}{{$t('nav.applicant')}}</span>
                <a href="/applicant" class="more">{{$t('page.more')}}</a>
            </div>
            <TabPane>
                <Table :columns="applicantColumns" :data="applicantData"></Table>
            </TabPane>
        </Tabs>

        <Tabs :animated="false" class="sign-tab" v-if="roles.ORDERAPPROVE">
            <TabPane>
                <v-chart :options="approveStatistic" style="width: 100%;" />
            </TabPane>
        </Tabs>

        </Col>
        <Col span="8">
        <Tabs :animated="false" class="sign-tab underline">
            <div slot="extra">
                <span class="title">{{$t('page.notice')}}</span>
                <a :href="appPrefix + '/notice'" class="more">{{$t('page.more')}}</a>
                <i class="line"></i>
            </div>
            <TabPane>
                <a v-for="item in noticeData" :key="item.ID" :value="item.ID" class="notice-list" :title="item.Title" :href="'/notice/detail?id=' + item.ID">
                    <span>[{{item.TypeNote}}]</span>{{item.Title}}
                </a>
            </TabPane>
        </Tabs>

        <Tabs :animated="false" class="underline">
            <div slot="extra">
                <span class="title" id="myBorrow">{{$t('nav.myBorrow')}}</span>
                <a :href="appPrefix + '/borrow'" class="more">{{$t('page.more')}}</a>
                <i class="line"></i>
            </div>
            <TabPane :label="$t('page.myBorrow')" name="myBorrowTab">
                <a v-for="item in borrowedData" :key="item.ID" :value="item.ID" class="borrow" :title="item.Title" :href="appPrefix + '/borrow?tab=1&id=' + item.ID">
                    <span class="circle">{{item.CreateUser.substring(0,1)}}</span>
                    <span class="title">{{item.BottleName}} </span>
                    <p>
                        {{item.CreateUser}} <span class="right">{{item.CreateTime}}</span>
                    </p>
                </a>
            </TabPane>
            <TabPane :label="$t('page.mylend')" name="myLendTab">
                <a v-for="item in lendData" :key="item.ID" :value="item.ID" class="borrow" :title="item.Title" :href="appPrefix + '/borrow?tab=2&id=' + item.ID">
                    <span class="circle">{{item.Lender.substring(0,1)}}</span>
                    <span class="title">{{item.BottleName}} </span>
                    <p>
                        {{item.Lender}} <span class="right">{{item.LendTime}}</span>
                    </p>
                </a>
            </TabPane>
        </Tabs>

        <Tabs :animated="false" class="sign-tab underline">
            <div slot="extra">
                <span class="title" id="otherBorrow">{{$t('page.taBorrow')}}</span>
                <a :href="appPrefix + '/lend'" class="more">{{$t('page.more')}}</a>
                <i class="line"></i>
            </div>
            <TabPane>
                <a v-for="item in postLendData" :key="item.ID" :value="item.ID" class="borrow" :title="item.Title" :href="'/lend/detail?id=' + item.ID">
                    <span class="circle">{{item.CreateUser.substring(0,1)}}</span>
                    <span class="title">{{item.BottleName}}</span>
                    <p>
                        {{item.CreateUser}} <span class="right">{{item.CreateTime}}</span>
                    </p>
                </a>
            </TabPane>
        </Tabs>
        </Col>
        <div id="overlay" v-show="isShowTour"></div>
        <v-tour name="myTour" :steps="steps" :options="myOptions" :callbacks="myCallbacks"></v-tour>
    </Row>
</ilab-layout>
</template>

<script>
import ECharts from 'vue-echarts'
import 'echarts/lib/chart/line'
import 'echarts/lib/component/tooltip'
import 'echarts/lib/component/toolbox'
import 'echarts/lib/component/polar'
import 'echarts/lib/component/legend'
import 'echarts/lib/component/title'
import 'echarts/lib/component/grid'
import ilabLayout from '@/components/layout.vue'
import api from '@/api'
import enums from '@/utils/enums'
import utils from '@/utils/utils'
import Vue from 'vue'
import VueTour from 'vue-tour'
require('vue-tour/dist/vue-tour.css')

Vue.use(VueTour)

export default {
    name: "home-page",
    components: {
        'v-chart': ECharts,
        ilabLayout,
    },
    data() {
        return {
            myOptions: {
                labels: {
                    buttonSkip: this.$i18n.t("tour.buttonSkip"),
                    buttonPrevious: this.$i18n.t("tour.buttonPrevious"),
                    buttonNext: this.$i18n.t("tour.buttonNext"),
                    buttonStop: this.$i18n.t("tour.buttonStop"),
                }
            },
            myCallbacks: {
                onStop: this.onStop
            },
            steps: [{
                target: "#searchSection",
                content: this.$i18n.t("tour.content1"),
                params: {
                    placement: "top"
                }
            }, {
                target: "#userCenter",
                content: this.$i18n.t("tour.content2"),
                params: {
                    placement: "top"
                }
            }, {
                target: "#myBorrow",
                content: this.$i18n.t("tour.content3"),
                params: {
                    placement: "top"
                }
            }, {
                target: "#otherBorrow",
                content: this.$i18n.t("tour.content4"),
                params: {
                    placement: "top"
                }
            }],
            appPrefix: process.env.VUE_APP_prefix,
            approveStatistic: {
                title: {
                    text: this.$i18n.t("nav.approveStatistic"),
                },
                color: ['#2f80e7', '#564aa3', '#2b957a', '#1797be', '#91c7ae', '#749f83', '#ca8622', '#bda29a', '#6e7074',
                    '#546570', '#c4ccd3'
                ],
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data: [],
                    selected: {
                        [this.$i18n.t("page.approveCount")]: true,
                        [this.$i18n.t("page.approveMoney")]: true
                    }
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                toolbox: {
                    feature: {
                        saveAsImage: {}
                    }
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: []
                },
                yAxis: {
                    type: 'value'
                },
                series: []
            },
            requestStatistic: {
                title: {
                    text: this.$i18n.t("nav.requestStatistic")
                },
                color: ['#2f80e7', '#564aa3', '#2b957a', '#1797be', '#91c7ae', '#749f83', '#ca8622', '#bda29a', '#6e7074',
                    '#546570', '#c4ccd3'
                ],
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data: []
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                toolbox: {
                    feature: {
                        saveAsImage: {}
                    }
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: []
                },
                yAxis: {
                    type: 'value'
                },
                series: []
            },
            approvingColumns: [{
                title: this.$i18n.t("columns.requestCode"),
                key: 'RequestCode',
                width: 130,
                render: (h, params) => {
                    return h('a', {
                        attrs: {
                            href: process.env.VUE_APP_prefix + '/request/detail?id=' + params.row.RequestCode
                        }
                    }, params.row.RequestCode)
                },
            }, {
                title: this.$i18n.t("columns.bottleName"),
                key: 'BottleName',
                tooltip: true
            }, {
                title: this.$i18n.t("columns.categoryName"),
                key: 'CategoryName',
            }, {
                title: this.$i18n.t("columns.CASNumber"),
                key: 'CASNumber',
                tooltip: true
            }, {
                title: this.$i18n.t("columns.purity"),
                key: 'Purity',
                width: 50
            }, {
                title: this.$i18n.t("columns.requestQuantity"),
                key: 'RequestQuantity',
                width: 50,
                render: (h, params) => {
                    return h('div', params.row.RequestQuantity + params.row.RequestUnit);
                }
            }, {
                title: this.$i18n.t("columns.projectCode"),
                key: 'ProjectCode',
                tooltip: true
            }, {
                title: this.$i18n.t("columns.requestDate"),
                key: 'RequestDate',
                width: 90
            }, {
                title: this.$i18n.t("columns.approveUsersNames"),
                key: 'ApproveUsersNames',
                tooltip: true
            }],
            receivingColumns: [{
                title: this.$i18n.t("columns.requestCode"),
                key: 'RequestCode',
                width: 130,
                render: (h, params) => {
                    return h('a', {
                        attrs: {
                            href: process.env.VUE_APP_prefix + '/request/detail?id=' + params.row.RequestCode
                        }
                    }, params.row.RequestCode)
                }
            }, {
                title: this.$i18n.t("columns.bottleName"),
                key: 'BottleName',
                tooltip: true
            }, {
                title: this.$i18n.t("columns.categoryName"),
                key: 'CategoryName',
            }, {
                title: this.$i18n.t("columns.CASNumber"),
                key: 'CASNumber',
            }, {
                title: this.$i18n.t("columns.purity"),
                width: 50,
                key: 'Purity',
            }, {
                title: this.$i18n.t("columns.requestQuantity"),
                width: 50,
                key: 'RequestQuantity',
                render: (h, params) => {
                    return h('div', params.row.RequestQuantity + params.row.RequestUnit);
                }
            }, {
                title: this.$i18n.t("columns.projectCode"),
                key: 'ProjectCode',
            }, {
                title: this.$i18n.t("columns.requestDate"),
                key: 'RequestDate',
                width: 90
            }, {
                title: this.$i18n.t("columns.requestState"),
                key: 'RequestState',
                tooltip: true
            }],
            requestApproveColumns: [{
                title: this.$i18n.t("columns.requestCode"),
                key: 'RequestCode',
                width: 130,
                render: (h, params) => {
                    return h('a', {
                        attrs: {
                            href: process.env.VUE_APP_prefix + '/requestApprove/detail?id=' + params.row.RequestCode
                        }
                    }, params.row.RequestCode)
                },

            }, {
                title: this.$i18n.t("columns.bottleName"),
                key: 'BottleName',
                tooltip: true
            }, {
                title: this.$i18n.t("columns.categoryName"),
                key: 'CategoryName',
            }, {
                title: this.$i18n.t("columns.CASNumber"),
                key: 'CASNumber',
            }, {
                title: this.$i18n.t("columns.purity"),
                key: 'Purity',
            }, {
                title: this.$i18n.t("columns.requestQuantity"),
                key: 'RequestQuantity',
                render: (h, params) => {
                    return h('div', params.row.RequestQuantity + params.row.RequestUnit);
                }
            }, {
                title: this.$i18n.t("columns.projectCode"),
                key: 'ProjectCode',
            }, {
                title: this.$i18n.t("columns.requestDate"),
                key: 'RequestDate',
                width: 90
            }, {
                title: this.$i18n.t("columns.requester"),
                key: 'Requester',
            }],
            applicantApproveColumns: [{
                title: this.$i18n.t("columns.purchaseCode"),
                key: 'PurchaseCode',
                width: 130,
                render: (h, params) => {
                    return h('a', {
                        attrs: {
                            href: process.env.VUE_APP_prefix + '/applicantApprove/detail?id=' + params.row.PurchaseCode
                        }
                    }, params.row.PurchaseCode)
                },
            }, {
                title: this.$i18n.t("columns.bottleName"),
                key: 'BottleName',
                tooltip: true
            }, {
                title: this.$i18n.t("columns.categoryName"),
                key: 'CategoryName',
            }, {
                title: this.$i18n.t("columns.CASNumber"),
                key: 'CASNumber',
                tooltip: true
            }, {
                title: this.$i18n.t("columns.purity"),
                width: 50,
                key: 'Purity',
            }, {
                title: this.$i18n.t("columns.price"),
                key: 'Price'
            }, {
                title: this.$i18n.t("columns.number"),
                key: 'Number',
            }, {
                title: this.$i18n.t("columns.totalPrice"),
                key: 'TotalPrice',
            }, {
                title: this.$i18n.t("columns.applicant"),
                key: 'Applicant',
            }, {
                title: this.$i18n.t("columns.applyTime"),
                key: 'ApplyTime',
                tooltip: true
            }],
            applicantColumns: [{
                title: this.$i18n.t("columns.purchaseCode"),
                key: 'PurchaseCode',
                width: 130,
                render: (h, params) => {
                    return h('a', {
                        attrs: {
                            href: process.env.VUE_APP_prefix + '/applicant/detail?id=' + params.row.ID
                        }
                    }, params.row.PurchaseCode)
                },
            }, {
                title: this.$i18n.t("columns.bottleName"),
                key: 'ChinName',
                width: 100,
                tooltip: true
            }, {
                title: this.$i18n.t("columns.categoryName"),
                key: 'CategoryName',
                width: 80
            }, {
                title: this.$i18n.t("columns.CASNumber"),
                key: 'CASNumber',
                width: 80
            }, {
                title: this.$i18n.t("columns.purity"),
                key: 'Purity',
            }, {
                title: this.$i18n.t("columns.price"),
                key: 'Price',
                width: 50
            }, {
                title: this.$i18n.t("columns.number"),
                key: 'Number',
                width: 50
            }, {
                title: this.$i18n.t("columns.totalPrice"),
                key: 'TotalPrice',
                width: 50
            }, {
                title: this.$i18n.t("columns.applyTime"),
                key: 'ApplyTime',
                width: 90,
                render: (h, params) => {
                    return h('div', params.row.ApplyTime.split(' ')[0]);
                }
            }, {
                title: this.$i18n.t("columns.procurementScheduleStatus"),
                width: 70,
                key: 'ProcurementScheduleStatusDescription'
            }],
            approvingData: [],
            receivingData: [],
            requestApproveData: [],
            applicantApproveData: [],
            applicantData: [],
            noticeData: [],
            borrowedData: [],
            lendData: [],
            postLendData: [],
            approveHref: '/requestApprove',
            roles: utils.getCimsInfo().RoleCodes,
            isShowTour: false
        };
    },
    methods: {
        /**
         * @param {string} tabName (领用单类型)
         * @description 获取我的领用列表数据
         */
        async fetchRequestData(tabName = 'requestTab') {
            let requestType = '',
                propData = '';

            if (tabName === 'requestTab') {
                requestType = enums.requestsInfoType.ApprovalPending;
                propData = 'approvingData';
            } else {
                requestType = enums.requestsInfoType.Receiving;
                propData = 'receivingData';
            }
            let resp = await api.cims.fetchRequestData(requestType);
            if (resp.code == process.env.VUE_APP_code) {
                if (propData === 'receivingData') {
                    resp.response.map(elt => {
                        elt.RequestState = enums.requestStateTxt(this.$i18n)[elt.RequestState];
                    })
                }
                this[propData] = resp.response;
            }
        },
        /**
         * @description 获取领用统计数据
         */
        async fetchRequestStatisticData() {
            let resp = await api.cims.fetchRequestStatisticData();
            if (resp.code == process.env.VUE_APP_code) {
                this.requestStatistic.legend.data = resp.response.Legend;
                this.requestStatistic.xAxis.data = resp.response.XAxisValues;
                resp.response.YAxisValues.map((item, index) => {
                    this.requestStatistic.series.push({
                        name: resp.response.Legend[index],
                        type: 'line',
                        data: item
                    })
                })
            }
        },
        /**
         * @description 获取审批统计数据
         */
        async fetchApproveStatisticData() {
            let resp = await api.cims.fetchApproveStatisticData();
            if (resp.code == process.env.VUE_APP_code) {
                this.approveStatistic.legend.data = resp.response.Legend;
                this.approveStatistic.xAxis.data = resp.response.XAxisValues;
                resp.response.YAxisValues.map((item, index) => {
                    this.approveStatistic.series.push({
                        name: resp.response.Legend[index],
                        type: 'line',
                        data: item
                    })
                })
            }
        },
        /**
         * @param {string} tabName (审批类型)
         * @description 获取我的审批列表数据
         */
        async fetchRequestApproveData(tabName = 'approveTab') {
            let resp = '';

            if (tabName === 'approveTab') {
                this.approveHref = '/requestApprove';
                resp = await api.cims.fetchRequestApproveData();
                if (resp.code == process.env.VUE_APP_code) {
                    this.requestApproveData = resp.response;
                }
            } else {
                this.approveHref = '/applicantApprove';
                resp = await api.cims.fetchApplicantApproveData();
                if (resp.code == process.env.VUE_APP_code) {
                    this.applicantApproveData = resp.rows;
                }

            }
        },
        /**
         * @description 获取我的申购数据
         */
        async fetchApplicantData() {
            const resp = await api.cims.fetchApplicantData();
            if (resp.code == process.env.VUE_APP_code) {
                this.applicantData = resp.rows;
            }
        },
        /**
         * @description 获取通知公告数据
         */
        async fetchNoticeData() {
            const resp = await api.cims.fetchNoticeData();
            if (resp.code == process.env.VUE_APP_code) {
                this.noticeData = resp.response;
            }
        },
        /**
         * @description 获取我的借用数据
         */
        async fetchBorrowedData() {
            const resp = await api.cims.fetchBorrowedData();
            if (resp.code == process.env.VUE_APP_code) {
                this.borrowedData = resp.response;
            }
        },
        /**
         * @description 获取我的借用数据
         */
        async fetchlendData() {
            const resp = await api.cims.fetchLendData();
            if (resp.code == process.env.VUE_APP_code) {
                this.lendData = resp.response;
            }
        },
        /**
         * @description 获取TA的借用数据
         */
        async fetchPostLendData() {
            const resp = await api.cims.fetchPostLendData();
            if (resp.code == process.env.VUE_APP_code) {
                this.postLendData = resp.rows;
            }
        },
        /**
         * @description 组合提示导航页
         */
        startTour() {
            if (this.roles.ORDERAPPROVE || this.roles.APPLYAPPROVE) {
                this.steps.push({
                    target: "#approve",
                    content: this.$i18n.t("tour.content5"),
                    params: {
                        placement: "top"
                    }
                })
            }
            this.$tours["myTour"].start();
            this.isShowTour = true;
        },
        onStop() {
            this.isShowTour = false;
        },
    },
    mounted() {
        this.fetchRequestData();
        this.fetchRequestStatisticData();
        this.fetchRequestApproveData();
        this.fetchApplicantData();
        this.fetchApproveStatisticData();
        this.fetchNoticeData();
        this.fetchBorrowedData();
        this.fetchlendData();
        this.fetchPostLendData();
    }
}
</script>

<style lang="less" scoped>
.home-page {
    /deep/ .ivu-layout {
        background-color: #f8f9fd !important;
    }
}

.content {
    padding-top: 32px;

    &.ivu-row {
        position: static;

        /deep/ .v-step {
            z-index: 1000;
            background: #1388ff;

            &[x-placement^=bottom] {
                /deep/ .v-step__arrow {
                    border-color: #1388ff;
                    border-left-color: transparent;
                    border-right-color: transparent;
                    border-top-color: transparent;
                }
            }

            &[x-placement^=top] {
                /deep/ .v-step__arrow {
                    border-color: #1388ff;
                    border-left-color: transparent;
                    border-right-color: transparent;
                    border-bottom-color: transparent;
                }
            }
        }

        #overlay {
            background: rgba(0, 0, 0, 0.4);
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 900;
        }

        #heightlightTag {
            padding: 20px;
            position: absolute;
            z-index: 901;
            box-shadow: 0 0 10px 10px rgba(255, 255, 255, 0.4);
            background: rgba(0, 0, 0, 0);
        }
    }

    >.ivu-col-span-16 {
        padding-right: 12px;
    }

    >.ivu-col-span-8 {
        padding-left: 12px;
    }

    .ivu-tabs {
        padding: 25px 20px 20px;
        border: 1px solid #e9e9e9;
        min-height: 300px;
        position: relative;
        margin: 0.5rem 0 1rem 0;
        margin-bottom: 30px;
        background-color: #fff;
        transition: box-shadow .25s;
        border-radius: 2px;
        overflow: hidden;
        box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 1px 5px 0 rgba(0, 0, 0, 0.12), 0 3px 1px -2px rgba(0, 0, 0, 0.2);

        /deep/ &.sign-tab {
            .ivu-tabs-nav-container {
                display: none;
            }

            &.underline {

                .ivu-tabs-bar {
                    padding-bottom: 8px;
                    margin-bottom: 6px;
                    border-bottom: 1px solid #ddd;

                    .line {
                        display: block;
                        position: absolute;
                        left: 21px;
                        top: 62px;
                        background-color: #6cc889;
                        width: 81px;
                        height: 2px;
                    }
                }

            }
        }

        .ivu-tabs-tabpane {
            >.borrow {
                min-height: 84px;
                padding: 10px 20px 10px 72px;
                position: relative;
                line-height: 1.5rem;
                border-bottom: 1px solid #e0e0e0;
                display: block;

                .title {
                    font-size: 12px;
                    color: #272727;
                    font-weight: bold;
                    margin-top: 2px;
                    display: inline-block;
                }

                p {
                    color: #787878;
                    font-size: 14px;
                    margin-top: 4px;

                    .right {
                        float: right;
                    }
                }

                .circle {
                    position: absolute;
                    width: 42px;
                    height: 42px;
                    overflow: hidden;
                    left: 15px;
                    display: inline-block;
                    vertical-align: middle;
                    background-color: #1388ff;
                    color: #fff;
                    text-align: center;
                    line-height: 42px;
                    font-weight: bold;
                    font-size: 22px;
                    border-radius: 50%;
                }
            }
        }

        /deep/ .ivu-tabs-bar {
            display: inline-block;
            border-bottom: none;
            width: 100%;

            .ivu-tabs-nav-container {
                height: 26px;
            }
        }

        /deep/ .ivu-tabs-nav-right {
            float: left;
            margin-left: 0;

            .request-icon {
                display: inline-block;
                width: 20px;
                height: 19px;
                background: url(../../assets/img/index_icon.png) -203px -7px no-repeat;
                position: relative;
                top: 2px;
                margin-right: 1px;
            }

            .audit-icon {
                display: inline-block;
                width: 18px;
                height: 20px;
                background: url(../../assets/img/index_icon.png) -71px -7px no-repeat;
                position: relative;
                top: 2px;
                margin-right: 3px;
            }

            .purchase-icon {
                display: inline-block;
                width: 20px;
                height: 20px;
                background: url(../../assets/img/index_icon.png) -103px -7px no-repeat;
                position: relative;
                top: 2px;
                margin-right: 3px;
            }

            .title {
                color: #282828;
                font-size: 20px;
                margin-left: 1px;
            }

            .more {
                width: 36px;
                height: 20px;
                font-size: 12px;
                padding: 2px 6px;
                line-height: 20px;
                text-align: center;
                border: 1px solid #ddd;
                border-radius: 3px;
                color: #848484;
                margin-left: 5px;
            }

            .ivu-icon-md-close {
                position: absolute;
                top: 6px;
                right: 6px;
                color: #848484;
                cursor: pointer;
                font-size: 17px;
                font-weight: bold;
            }
        }

        /deep/ .ivu-tabs-nav-container {
            float: right;

            .ivu-tabs-ink-bar {
                display: none;
            }

            .ivu-tabs-tab {
                font-size: 12px;
                color: #848484;
                font-weight: bold;
                border: 1px solid #ddd;
                height: 26px;
                line-height: 25px;
                padding: 0;
                margin-right: 0;
                width: 75px;

                &.ivu-tabs-tab-active {
                    color: #fff;
                    background-color: #1388ff;
                }
            }

            .ivu-tabs-tab:nth-child(2) {
                border-top-left-radius: 26px;
                border-bottom-left-radius: 26px;
                text-align: right;
                padding-right: 8px;
                border-right: none;
            }

            .ivu-tabs-tab:nth-child(3) {
                border-top-right-radius: 26px;
                border-bottom-right-radius: 26px;
                text-align: left;
                padding-left: 8px;
            }

        }

        /deep/ .ivu-table-wrapper {
            border: none;

            .ivu-table {

                &:after {
                    display: none;
                }

                .ivu-table-tbody {
                    td {
                        border-bottom: 1px dashed #ddd;
                    }
                }

                th {
                    background-color: #ffffff;

                    .ivu-table-cell {
                        padding: 0;

                        span {
                            font-size: 15px;
                            padding: 15px 5px;
                            display: table-cell;
                            text-align: left;
                            vertical-align: middle;
                            border-radius: 2px;
                        }
                    }
                }

                .ivu-table-cell {
                    white-space: nowrap;
                    padding: 0 5px;
                    color: rgba(0, 0, 0, .87);
                    font-size: 15px;

                    a {
                        color: rgba(0, 0, 0, .87);
                    }
                }
            }

        }

        .notice-list {
            width: 343px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            padding: 6px 0;
            display: block;
            color: rgba(0, 0, 0, .87);
            font-size: 15px;

            &:hover {
                text-decoration: underline;
            }

            >span {
                color: #000;
                font-weight: bold;
            }
        }
    }
}
</style>
