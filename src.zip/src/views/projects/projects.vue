<template>
<ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
        <div class="page-info">
            <Row type="flex">
                <Col class="flex-1">
                <div class="chinName">我的项目</div>
                <div class="chemName">My Projects</div>
                </Col>
                <Col>
                <Button size="large" type="primary" icon="md-add" @click="openModal" v-if="isProjectManager">{{$t('nav.projects')}}</Button>
                </Col>
            </Row>
        </div>

        <Table :columns="columns" :data="data" :noDataText="noDataText">
            <template slot-scope="{ row }" slot="ProjectState">
                <i-switch size="large" v-if="isProjectManager" @on-change="toggleProjectState($event, row.ID)" :value="row.ProjectState === 1">
                    <span slot="open">{{$t('btn.enable')}}</span>
                    <span slot="close">{{$t('btn.disable')}}</span>
                </i-switch>
                <div v-else>{{row.ProjectState === 1 ? $t('btn.enable') : $t('btn.disable')}}</div>
            </template>
            <template slot-scope="{ row }" slot="action">
                <Button icon="md-create" size="small" :title="$t('btn.edit')" @click="openModal(false, row.ID)"></Button>
                <Button icon="md-trash" size="small" :title="$t('btn.remove')" @click="removePro(row)"></Button>
            </template>
        </Table>
        <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />

        <Modal :title="$t('nav.projects')" v-model="modal" @on-ok="submit" :loading="loading">
            <Form ref="form" :model="form" :rules="rules" :label-width="130">
                <FormItem :label="$t('form.projectName')" prop="ProjectCode">
                    <Input v-model="form.ProjectCode" :placeholder="$t('form.projectName')"></Input>
                </FormItem>
                <FormItem :label="$t('form.projectLeader')" prop="ProjectLeaders">
                    <Select v-model="form.ProjectLeaders" multiple filterable @on-change="onChange" @on-query-change="onManagerQueryChange" @on-open-change="onOpenChange($event, 1)" :placeholder="$t('form.filter')">
                        <Option v-for="item in members1" :value="item.AccountId" :key="item.AccountId">{{ item.RealName }}</Option>
                    </Select>
                </FormItem>
                <FormItem :label="$t('form.projectMember')" prop="ProjectMembers">
                    <Select v-model="form.ProjectMembers" multiple filterable @on-change="onChange" @on-query-change="onMemberQueryChange" @on-open-change="onOpenChange($event, 2)" :placeholder="$t('form.filter')">
                        <Option v-for="item in members2" :value="item.AccountId" :key="item.AccountId">{{ item.RealName }}</Option>
                    </Select>
                </FormItem>
                <FormItem :label="$t('form.projectDesc')" prop="ProjectCommnets">
                    <Input type="textarea" v-model="form.ProjectCommnets" :autosize="{minRows: 3,maxRows: 5}"></Input>
                </FormItem>
            </Form>
        </Modal>

        <Modal :title="$t('btn.remove')" v-model="modal1" @on-ok="deleteProject" :loading="removeLoading">
            <p v-html="$t('form.projectDeleteTip', [removeProject.ProjectName])"></p>
        </Modal>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from "@/components/layout.vue";
import api from "@/api";
import columns from "@/utils/columns";
import utils from "@/utils/utils";

export default {
    name: "project-page",
    components: {
        ilabLayout
    },
    data() {
        return {
            appPrefix: process.env.VUE_APP_prefix,
            noDataText: this.$i18n.t("columns.noDataText"),
            roles: utils.getCimsInfo().RoleCodes,
            isProjectManager: false,
            isOnchange: false,
            data: [],
            pageIndex: 1,
            total: 0,
            modal: false,
            modal1: false,
            loading: true,
            loading1: false,
            loading2: false,
            removeLoading: false,
            removeProject: {},
            members1: [],
            members2: [],
            isNew: true,
            projectId: 0,
            columns: [{
                    key: "ProjectCode",
                    title: this.$i18n.t("columns.myProject"),
                    tooltip: true
                },
                {
                    slot: "ProjectState",
                    title: this.$i18n.t("columns.state")
                },
                {
                    key: "CreateTime",
                    title: this.$i18n.t("columns.createTime")
                },
                {
                    key: "ProjectCommnets",
                    title: this.$i18n.t("columns.desc"),
                    tooltip: true
                }
            ],
            breadcrumbs: [{
                txt: this.$i18n.t("columns.myProject")
            }],
            action: {
                slot: "action",
                title: this.$i18n.t("columns.operation"),
                align: "center"
            },
            form: {
                ProjectCode: "",
                ProjectLeaders: "",
                ProjectMembers: "",
                ProjectCommnets: ""
            },
            rules: {
                ProjectCode: [{
                    required: true,
                    message: this.$i18n.t("message.notNull", [
                        this.$i18n.t("form.projectName")
                    ])
                }, {
                    validator: (rule, value, callback) => {
                        if (value.length > 100) {
                            callback(new Error(
                                this.$i18n.t("message.notOver", [
                                    this.$i18n.t("form.projectName"),
                                    100
                                ])
                            ));
                        } else {
                            callback();
                        }
                    }
                }],
                ProjectLeaders: [{
                        required: true,
                        message: this.$i18n.t("message.notNull", [
                            this.$i18n.t("form.projectLeader")
                        ])
                    },
                    {
                        validator: this.validatorProjectLeaders
                    }
                ],
                ProjectMembers: [{
                    required: true,
                    message: this.$i18n.t("message.notNull", [
                        this.$i18n.t("form.projectMember")
                    ])
                }, {
                    validator: this.validatorProjectMembers
                }],
                ProjectCommnets: [{
                    validator: this.validatorProjectCommnets,
                    trigger: "blur"
                }]
            },
            departmentId: 0,
            isNeedValid: false
        };
    },
    created() {
        const deptId = utils.getDeptId();
        if (deptId) {
            this.departmentId = deptId;
        } else {
            this.$Message.warning(this.$i18n.t("form.noDept"));
        }

        this.isProjectManager = !!this.roles.PROJECTMANAGER;
        if (this.isProjectManager) {
            this.columns.push(this.action);
        }
    },
    methods: {
        //项目描述长度验证
        validatorProjectCommnets(rule, value, callback) {
            if (value && value.length > 100) {
                callback(
                    new Error(
                        this.$i18n.t("message.notOver", [
                            this.$i18n.t("form.projectDesc"),
                            100
                        ])
                    )
                );
            } else {
                callback();
            }
        },
        //负责人非空验证
        validatorProjectLeaders(rule, value, callback) {
            if (this.isNeedValid) {
                callback();
            } else {
                if (value && value.length > 0) {
                    callback();
                } else {
                    callback(
                        new Error(
                            this.$i18n.t("message.notOver", [
                                this.$i18n.t("form.projectLeader")
                            ])
                        )
                    );
                }
            }
        },
        //成员非空验证
        validatorProjectMembers(rule, value, callback) {
            if (this.isNeedValid) {
                this.isNeedValid = false;
                callback();
            } else {
                if (value && value.length > 0) {
                    callback();
                } else {
                    callback(
                        new Error(
                            this.$i18n.t("message.notOver", [
                                this.$i18n.t("form.projectMember")
                            ])
                        )
                    );
                }
            }
        },
        //下拉框展开或收起时触发
        onOpenChange(isOpen, type) {
            if (isOpen) {
                if (type === 1) {
                    this.filterManager();
                } else {
                    this.filterMember();
                }
            }
            this.isOnchange = false;
        },
        //选中时触发
        onChange() {
            this.isOnchange = true;
        },
        //打开项目模态框
        openModal(isNew = true, projectId) {
            this.isNew = isNew;
            this.isNeedValid = true;
            this.modal = true;
            this.$refs.form.resetFields();
            if (!isNew) {
                this.fetchProjectData(projectId);
                this.projectId = projectId;
            }
        },
        //关闭loading
        resetLoading() {
            this.loading = false;
            setTimeout(() => {
                this.loading = true;
            }, 0);
        },
        //获取项目数据
        async fetchData(pageIndex = 1) {
            this.noDataText = this.$i18n.t("columns.noDataText");

            let resp = {};
            if (this.isProjectManager) {
                resp = await api.cims.fetchProjectManagerData({
                    pageIndex,
                    sortFiled: "CreateTime",
                    sort: "DESC"
                });
            } else {
                resp = await api.cims.fetchProjectData({
                    pageIndex,
                    sortFiled: "CreateTime",
                    sort: "DESC"
                });
            }

            if (resp.code == process.env.VUE_APP_code) {
                this.data = resp.rows;
                this.total = resp.total;
            } else {
                this.data = [];
                this.total = 0;
                this.noDataText = this.$i18n.t("columns.noDataText2");
            }
            this.pageIndex = pageIndex;
        },
        //获取项目详情
        async fetchProjectData(projectId) {
            const resp = await api.cims.fetchProject(projectId);
            if (resp.code == process.env.VUE_APP_code) {
                this.members1 = resp.response.ProjectLeaders;
                this.members2 = resp.response.ProjectMembers;
                this.form.ProjectCode = resp.response.Project.ProjectCode;
                this.form.ProjectLeaders = resp.response.ProjectLeaders.map(
                    item => item.AccountId
                );
                this.form.ProjectMembers = resp.response.ProjectMembers.map(
                    item => item.AccountId
                );
                this.form.ProjectCommnets = resp.response.Project.ProjectCommnets;
            } else {
                this.$Message.error(resp.message);
            }
        },
        //搜索清空时加载第一页
        onManagerQueryChange(query) {
            if (!this.isOnchange) {
                this.filterManager(query);
            }
        },
        //搜索清空时加载第一页
        onMemberQueryChange(query) {
            if (!this.isOnchange) {
                this.filterMember(query);
            }
        },
        //搜索负责人
        filterManager(query = "") {
            this.filter(query, 1);
        },
        //搜索成员
        filterMember(query = "") {
            this.filter(query, 2);
        },
        //搜索负责人或者成员
        async filter(query, type) {
            this[`loading${type}`] = true;
            const resp = await api.cims.fetchProjectMemberData({
                pageIndex: 1,
                realName: query
            });
            this[`loading${type}`] = false;
            if (resp.code == process.env.VUE_APP_code) {
                this[`members${type}`] = resp.rows;
            } else {
                this[`members${type}`] = [];
            }
        },
        //提交项目
        async submit() {
            const valid = await this.$refs.form.validate();
            if (valid) {
                let resp = {};
                if (this.isNew) {
                    resp = await api.cims.newProject({
                        projectName: this.form.ProjectCode,
                        departmentId: this.departmentId,
                        ...this.form
                    });
                } else {
                    resp = await api.cims.editProject(this.projectId, {
                        projectName: this.form.ProjectCode,
                        ...this.form
                    });
                }

                if (resp.code == process.env.VUE_APP_code) {
                    this.$Message.success(resp.message);
                    this.modal = false;
                    this.fetchData();
                } else {
                    this.$Message.error(resp.message);
                    this.resetLoading();
                }
            } else {
                this.resetLoading();
            }
        },
        //点击删除项目
        removePro(item) {
            this.removeProject = item;
            this.modal1 = true;
        },
        //删除项目
        async deleteProject() {
            const resp = await api.cims.deleteProject(this.removeProject.ID);
            if (resp.code == process.env.VUE_APP_code) {
                this.$Message.success(resp.message);
                this.fetchData();
            } else {
                this.$Message.error(resp.message);
            }
        },
        //启用禁用项目
        async toggleProjectState(projectEnable, id) {
            const resp = await api.cims.toggleProjectState({
                projectEnable,
                id
            });
            if (resp.code == process.env.VUE_APP_code) {
                this.$Message.success(resp.message);
            } else {
                this.$Message.error(resp.message);
            }
        }
    },
    mounted() {
        this.fetchData();
    }
};
</script>
