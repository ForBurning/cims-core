<template>
	<ilab-layout :breadcrumbs="breadcrumbs">
		<div slot="content" class="content">
			<img src="../../assets/img/404.png" alt="404" class="pic-404">
		</div>
	</ilab-layout>
</template>
<script>
	import ilabLayout from '@/components/layout.vue'

	export default {
		name: "notfind-page",
		components: {
			ilabLayout,
		},
		data() {
			return {
				breadcrumbs: [{
					txt: '404'
				}],
			};
		},
	}
</script>

<style lang="less" scoped>
	.content {
		.pic-404{
			width: 500px;
			height: 500px;
			margin: 0 auto;
			display: block;
		}
	}
</style>
