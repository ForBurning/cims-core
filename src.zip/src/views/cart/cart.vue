<template>
<ilab-layout :breadcrumbs="breadcrumbs" ref="layout">
    <div slot="content" class="content">
        <div class="page-info">
            <div class="chinName">领用单</div>
            <div class="chemName">ShoppingCart</div>
        </div>
        <div class="shopping-list">
            <Select class="batch-choose-project" label-in-value :placeholder="$t('message.placeSelect', [$t('columns.projectCode')])" @on-change="projectOnChangeAll">
                <Option v-for="item in projects" :value="item.ID" :key="item.ID">{{item.ProjectCode}}</Option>
            </Select>
            <Tooltip :content="$t('page.cartToolTip')" class="expireDate-tip" placement="top" theme="light">
                <span class="tip">?</span>
            </Tooltip>
            <Table :columns="columns" :data="data" class="cart-table" @on-selection-change="onSelectionChange" ref="table" :no-data-text="noDataText">
                <template slot-scope="{ row }" slot="BottleName">
                    <span class="text-dot" :title="row.BottleName">{{row.BottleName}}</span>
                    <span class="exprite-date" v-html="isExpiry(row.ExpiryDate)"></span>
                </template>
                <template slot-scope="{ row, index }" slot="EstimatedAmount">
                    <InputNumber :min="0" :max="row.RequestQuantity" :value="row.EstimatedAmount" @on-change="estimatedAmountOnChange($event, index)"></InputNumber>{{row.RequestUnit}}
                </template>
                <template slot-scope="{ row, index }" slot="DeliveryFlag">
                    <i-switch @on-change="deliveryFlagOnChange($event, index)">
                        <span slot="open">{{$t('page.yes')}}</span>
                        <span slot="close">{{$t('page.no')}}</span>
                    </i-switch>
                </template>
                <template slot-scope="{ row, index }" slot="projects">
                    <Select v-model="projectsArray[index].ProjectId" label-in-value @on-change="projectOnChange($event, index)" class="choose-project" :class="{error: projectsArray[index].flag}" :placeholder="$t('message.placeSelect', [$t('columns.projectCode')])">
                        <Option v-for="item in projects" :value="item.ID" :key="item.ID">{{item.ProjectCode}}</Option>
                    </Select>
                </template>
            </Table>
            <Row class="batch-operation">
                <Col span="12">{{$t('page.cartSelectInfo', [selectedCount, total])}}：
                <a :href="appPrefix + '/search'">{{$t('page.continueRequest')}}</a>
                <span @click="deleteSelectedEvt" class="cart-action" v-show="selectedCount > 0">{{$t('page.deleteSelected')}}</span>
                <span @click="deleteAllEvt" class="cart-action" v-show="total > 0">{{$t('page.emptyAll')}}</span>
                </Col>
                <Col span="12">
                <Button size="large" type="primary" :disabled="selectedCount === 0" @click="submit" :loading="loading">
                    <span v-if="loading">{{$t('btn.submiting')}}...</span>
                    <span v-else>{{$t('btn.submitRequest')}}</span>
                </Button>
                </Col>
            </Row>
        </div>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from '@/components/layout.vue'
import utils from '@/utils/utils'
import api from '@/api'

export default {
    name: "cart-page",
    components: {
        ilabLayout,
    },
    data() {
        return {
            appPrefix: process.env.VUE_APP_prefix,
            expireTime: 1,
            breadcrumbs: [{
                txt: this.$i18n.t("nav.cart"),
            }],
            loading: false,
            iminentExpirationDay: '',
            data: [],
            projects: [],
            projectsArray: [],
            total: 0,
            selectedCount: 0,
            noDataText: this.$i18n.t("columns.noDataText"),
            columns: [{
                type: 'selection',
                width: 50,
                align: 'center'
            }, {
                slot: "BottleName",
                title: this.$i18n.t("columns.bottleName"),
            }, {
                key: "MaterielNumber",
                title: this.$i18n.t("page.materielNumber"),
                width: 100,
            }, {
                key: "CategoryName",
                title: this.$i18n.t("columns.categoryName"),
                width: 90,
            }, {
                key: "CASNumber",
                title: this.$i18n.t("columns.CASNumber"),
                width: 90,
            }, {
                key: "BottleType",
                title: this.$i18n.t("columns.bottleType"),
                width: 85,
            }, {
                key: "Purity",
                title: this.$i18n.t("columns.bOrp"),
                width: 120,
            }, {
                key: "RequestQuantity",
                title: this.$i18n.t("columns.requestQuantity"),
                width: 80,
                render: (h, params) => {
                    return h('div', params.row.RequestQuantity + params.row.RequestUnit);
                }
            }, {
                slot: "EstimatedAmount",
                title: this.$i18n.t("columns.estimatedAmount"),
                width: 130,
            }, {
                slot: "DeliveryFlag",
                title: this.$i18n.t("columns.delivery"),
                width: 80
            }, {
                slot: "projects",
                title: " ",
                width: 140
            }, {
                key: "RequestDate",
                title: this.$i18n.t("columns.remainTime"),
                width: 100,
                render: (h, params) => {
                    let requestDate = new Date(params.row.RequestDate).getTime(),
                        nowDate = (utils.getTimesamp() - 121) * 1000,
                        goTime = Math.floor((nowDate - requestDate) / (3600 * 1000)),
                        remainTime = this.expireTime - goTime,
                        expireDate = "";

                    if (remainTime > 0) {
                        if (parseInt(remainTime / 24) > 0) {
                            expireDate = parseInt(remainTime / 24) + this.$i18n.t("time.day");
                        }

                        if (parseInt(remainTime / 24) > 0 && remainTime % 24 > 0) {
                            expireDate += this.$i18n.t("time.zero");
                        }

                        if (remainTime % 24 > 0) {
                            expireDate += remainTime % 24 + this.$i18n.t("time.hour");
                        }
                    } else {
                        expireDate = this.$i18n.t("time.expireDate");
                    }

                    return h('div', {
                        attrs: {
                            'class': remainTime > 0 ? '' : 'red-text'
                        }
                    }, expireDate);
                }
            }]
        };
    },
    methods: {
        //获取物料近效期提醒时间
        async getIminentExpirationDay() {
            const resp = await api.cims.getOrganizationConfig('iminentExpirationDay');
            if (resp.code == process.env.VUE_APP_code) {
                this.iminentExpirationDay = resp.response;
            } else {
                this.$Message.error(resp.message)
            }
        },
        //判断近效期
        isExpiry(date) {
            const expireDateState = [this.$i18n.t("page.overExpiryTime"), this.$i18n.t("page.withExpiryTime"), this.$i18n.t("page.inExpiryTime")];
            return utils.isExpiry(this.iminentExpirationDay, date, expireDateState);
        },
        //部分删除
        async deleteSelectedEvt() {
            const ids = this.$refs.table.getSelection().map(x => x.ID);
            const resp = await api.cims.deleteShoppingCart(ids);
            if (resp.code == process.env.VUE_APP_code) {
                this.selectedCount = 0;
                ids.map(id => {
                    utils.removeItem(this.data, id);
                })
                this.$Message.success(resp.message)
                this.$refs.layout.setCartCount(-ids.length);
                this.noDataText = this.$i18n.t("columns.noDataText2");
            } else {
                this.$Message.error(resp.message)
            }
        },
        //全部删除
        async deleteAllEvt() {
            let ids = this.data.map(x => x.ID);
            let resp = await api.cims.deleteShoppingCart(ids);
            if (resp.code == process.env.VUE_APP_code) {
                this.selectedCount = 0;
                this.$Message.success(resp.message)
                this.data = [];
                this.$refs.layout.setCartCount(-ids.length);
                this.noDataText = this.$i18n.t("columns.noDataText2");
            } else {
                this.$Message.error(resp.message)
            }
        },
        onSelectionChange(selection) {
            this.selectedCount = selection.length;
        },
        async loadProject() {
            let resp = await api.cims.fetchProjects();
            if (resp.code == process.env.VUE_APP_code) {
                this.projects = resp.response;
            }

        },
        deliveryFlagOnChange(value, index) {
            let rows = utils.deepCopy(this.data);
            rows[index].DeliveryFlag = value;
            this.data[index] = rows[index];
        },
        estimatedAmountOnChange(value, index) {
            if (value >= 0) {
                let rows = utils.deepCopy(this.data);
                rows[index].EstimatedAmount = value;
                this.data[index] = rows[index];
            } else {
                this.$Message.warning(this.$i18n.t("message.overZero", [this.$i18n.t("columns.estimatedAmount")]));
            }
        },
        //项目切换
        projectOnChangeAll(project) {
            this.projectsArray.map((item, index) => {
                item.ProjectId = project.value;
                item.ProjectCode = project.label;
                this.projectsArray[index].flag = false;
                return item;
            })
        },
        //单个项目切换
        projectOnChange(project, index) {
            this.projectsArray.map(item => {
                if (item.ProjectId === project.value) {
                    item.ProjectCode = project.label;
                    this.projectsArray[index].flag = false;
                }
            })
        },
        //获取领用单
        async getShoppingCart() {
            let resp = await api.cims.getShoppingCart({
                pageIndex: 1,
                pageSize: 10000,
            })
            if (resp.code == process.env.VUE_APP_code) {
                resp.rows.map(item => {
                    item.ProjectId = 0;
                    this.$set(item, 'EstimatedAmount', item.RequestQuantity);
                    this.projectsArray.push({
                        ProjectId: 0,
                        ProjectCode: '',
                        flag: false
                    })
                })
                this.selectedCount = 0;
                this.data = resp.rows;
                this.total = resp.total;
            } else {
                this.noDataText = this.$i18n.t("columns.noDataText2");
            }
        },
        getIndex(id) {
            let i = 0;
            this.data.map((item, index) => {
                if (item.ID === id) {
                    i = index;
                }
            })
            return i;
        },
        //提交领用单
        async submit() {
            let valid = true;
            this.$refs.table.getSelection().map(item => {
                const index = this.getIndex(item.ID);
                const isEmpty = this.projectsArray[index].ProjectId;
                if (valid && !utils.isPositive(item.EstimatedAmount)) {
                    this.$Message.error(this.$i18n.t("message.index", [
                        index + 1,
                        this.$i18n.t("message.overZero", [
                            this.$i18n.t("columns.estimatedAmount")
                        ])
                    ]));
                    valid = false;
                } else if (valid && !!!isEmpty) {
                    this.projectsArray[index].flag = true;
                    valid = false;
                }
            })

            if (valid) {
                this.loading = true;
                const requestsCommitList = this.$refs.table.getSelection().map((item, index) => {
                    const i = this.getIndex(item.ID);
                    Object.assign(item, {
                        DeliveryFlag: item.DeliveryFlag ? 2 : 1,
                        RequestId: item.ID,
                        EstimatedAmount: item.EstimatedAmount,
                        ProjectId: this.projectsArray[i].ProjectId,
                        ProjectCode: this.projectsArray[i].ProjectCode,
                    })

                    return item
                })
                let resp = await api.cims.submitShoppingCart({
                    requestsCommitList: requestsCommitList
                })

                if (resp.code == process.env.VUE_APP_code) {
                    window.location.href = this.appPrefix + '/success'
                } else {
                    this.$Message.error(resp.message);
                    this.loading = false;
                }
            }
        }
    },
    async mounted() {
        await this.getIminentExpirationDay();
        await this.loadProject();
        const resp = await api.cims.getSystemConfig('requestValidity');
        this.expireTime = parseInt(resp.response);
        await this.getShoppingCart();
    },

}
</script>

<style lang="less" scoped>
.content {

    .shopping-list {
        position: relative;

        .ivu-table-wrapper {
            overflow: initial;
        }

        .batch-choose-project {
            position: absolute;
            width: 120px;
            top: 5px;
            right: 103px;
            z-index: 10;
        }

        .choose-project {
            width: 120px;

            &.error {
                /deep/ .ivu-select-selection {
                    border-color: #e51c22;
                }
            }
        }

        .text-dot {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            display: inline-block;
            max-width: 87px;
        }

        .exprite-date {
            position: absolute;
        }
    }

    .expireDate-tip {
        position: absolute;
        top: 10px;
        right: 11px;
        z-index: 10;

        .tip {
            display: inline-block;
            width: 20px;
            height: 20px;
            background-color: #ff6100;
            color: #ffffff;
            border-radius: 50%;
            line-height: 22px;
            text-align: center;
        }

        /deep/ .ivu-tooltip-inner {
            max-width: 350px;
        }
    }

    .cart-table {
        /deep/ .ivu-input-number {
            width: 70px;
            margin-right: 6px;
        }

        /deep/ .red-text {
            color: #F44336;
        }
    }

    .cart-action {
        display: inline-block;
        margin-left: 12px;
        cursor: pointer;

        &:first-of-type {
            color: #006BFF;
        }

        &:last-of-type {
            color: #fd6100;
        }

    }

}
</style>
