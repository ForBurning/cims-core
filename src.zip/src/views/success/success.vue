<template>
	<ilab-layout :breadcrumbs="breadcrumbs">
		<div slot="content" class="content">
			<div class="c">
				<div class="row1 relative">
					<div><img src="../../assets/img/y.png" class="yes">{{$t('page.success1')}}</div>
					<div>
						<span>{{$t('page.success2')}}：</span>
						<a :href="appPrefix + '/search'" class="jx waves-effect waves-light">{{$t('page.continueRequest')}}</a>
						<a :href="appPrefix + '/request'" class="viewHistory">{{$t('page.success3')}}</a>
					</div>
				</div>
				<div class="row2">
					<div>{{$t('page.success4')}}</div>
					<div>{{$t('page.success5')}}</div>
				</div>
			</div>
		</div>
	</ilab-layout>
</template>
<script>
	import ilabLayout from '@/components/layout.vue'


	export default {
		name: "success-page",
		components: {
			ilabLayout,
		},
		data() {
			return {
				appPrefix: process.env.VUE_APP_prefix,
				breadcrumbs: [{
					txt: this.$i18n.t("nav.requestSuccess")
				}],
			};
		},
	}
</script>

<style lang="less" scoped>
	.content {
		.c {
			border: 1px solid #e5e5e5;
			padding: 30px;
			margin-top: 50px;

			.relative {
				position: relative;
			}

			.row1 {
				border-bottom: 1px dashed #e5e5e5;
				padding-left: 60px;

				>div {
					line-height: 49px;
					font-size: 22px;
					font-weight: bold;

					.yes {
						position: absolute;
						left: 0;
						top: 0;
					}

					span {
						font-size: 14px;
						font-weight: normal;
					}

					.jx {
						display: inline-block;
						padding: 0 26px;
						height: 35px;
						font-size: 14px;
						line-height: 35px;
						background-color: #ff6100;
						color: #ffffff;
						text-align: center;
						margin-right: 20px;
					}

					.viewHistory {
						color: #5a8dbc;
						font-size: 14px;
						text-decoration: underline;
					}
				}
			}

			.row2 {
				padding: 40px 0 0 50px;
				line-height: 30px;
				font-size: 15px;

				>div:first-child {
					color: #9f9f9f;
				}
			}


		}

	}
</style>
