import Vue from 'vue'
import iView from 'iview'
import App from './message.vue'

import 'iview/dist/styles/iview.css'
import sitecss from '@/assets/css/site.less'
import utils from '@/utils/utils'

import VueI18n from 'vue-i18n'
Vue.use(VueI18n);

import langs from "@/lang";
import dateTimeFormats from "@/lang/dateTimeFormates.js";

import en from 'iview/dist/locale/en-US';
import zh from 'iview/dist/locale/zh-CN';

const messages = {
  zh: Object.assign(langs.zh, zh),
  en: Object.assign(langs.en, en)
};

const i18n = new VueI18n({
  locale: utils.getSystemLanguage(),
  messages,
  dateTimeFormats
})

Vue.use(iView, {
  i18n: (key, value)=>i18n.t(key, value)
})

Vue.config.productionTip = false

new Vue({
  i18n,
  render: h => h(App)
}).$mount('#app')



