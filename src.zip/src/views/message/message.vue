<template>
<ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
        <div class="page-info">
            <div class="chinName">通知消息</div>
            <div class="chemName">Notification</div>
        </div>

        <Tabs v-model="name" class="ilab-tabs" :animated="false" @on-click="onTabsClick">
            <div slot="extra">
                <Button type="primary" icon="md-checkbox-outline" :disabled="selectCount === 0" @click="batchReadMessage">{{$t('btn.batchRead')}}</Button>
                <Button type="error" icon="ios-trash" :disabled="selectCount === 0" @click="batchDeleteMessage">{{$t('btn.batchDelete')}}</Button>
            </div>
            <TabPane :label="$t('btn.allMsg')" name="0">
                <Table :noDataText="noDataText" :columns="columns" :data="data" ref="table0" @on-select="getSelectCount" @on-select-all="getSelectCount" @on-select-all-cancel="getSelectCount" @on-select-cancel="getSelectCount">
                    <template slot-scope="{ row }" slot="content">
                        <Row type="flex" class="msg-title" :class="{'read-message': row.MessageStatus === 1}">
                            <Col class="flex-1">{{row.MessageTitle}}</Col>
                            <Col>{{row.CreateTime}}</Col>
                        </Row>
                        <Row type="flex" class="msg-content" :class="{'read-message': row.MessageStatus === 1}">
                            <Col class="flex-1" v-if="row.MessageType === 2" v-html="deliveryFormatter(row)">
                            </Col>
                            <Col class="flex-1" v-else>
                            {{row.MessageDetail}}
                            <a :href="row | linkFormatter" @click="readMessage(row.ID)">{{$t('btn.viewMsgDetail')}}</a>
                            </Col>
                        </Row>
                    </template>
                </Table>
            </TabPane>
            <TabPane :label="$t('btn.approveMsg')" name="1">
                <Table :noDataText="noDataText" :columns="columns" :data="data" ref="table1" @on-select="getSelectCount" @on-select-all="getSelectCount" @on-select-all-cancel="getSelectCount" @on-select-cancel="getSelectCount">
                    <template slot-scope="{ row }" slot="content">
                        <Row type="flex" class="msg-title" :class="{'read-message': row.MessageStatus === 1}">
                            <Col class="flex-1">{{row.MessageTitle}}</Col>
                            <Col>{{row.CreateTime}}</Col>
                        </Row>
                        <Row type="flex" class="msg-content" :class="{'read-message': row.MessageStatus === 1}">
                            <Col class="flex-1">
                            {{row.MessageDetail}}
                            <a :href="row | linkFormatter" @click="readMessage(row.ID)">{{$t('btn.viewMsgDetail')}}</a>
                            </Col>
                        </Row>
                    </template>
                </Table>
            </TabPane>
            <TabPane :label="$t('btn.deliveryMsg')" name="2">
                <Table :noDataText="noDataText" :columns="columns" :data="data" ref="table2" @on-select="getSelectCount" @on-select-all="getSelectCount" @on-select-all-cancel="getSelectCount" @on-select-cancel="getSelectCount">
                    <template slot-scope="{ row }" slot="content">
                        <div @click="readMessage(row.ID)">
                            <Row type="flex" class="msg-title" :class="{'read-message': row.MessageStatus === 1}">
                                <Col class="flex-1">{{row.MessageTitle}}</Col>
                                <Col>{{row.CreateTime}}</Col>
                            </Row>
                            <Row type="flex" class="msg-content" :class="{'read-message': row.MessageStatus === 1}">
                                <Col class="flex-1" v-html="deliveryFormatter(row)">
                                </Col>
                            </Row>
                        </div>
                    </template>
                </Table>
            </TabPane>
            <TabPane :label="$t('btn.borrowMsg')" name="3">
                <Table :noDataText="noDataText" :columns="columns" :data="data" ref="table3" @on-select="getSelectCount" @on-select-all="getSelectCount" @on-select-all-cancel="getSelectCount" @on-select-cancel="getSelectCount">
                    <template slot-scope="{ row }" slot="content">
                        <Row type="flex" class="msg-title" :class="{'read-message': row.MessageStatus === 1}">
                            <Col class="flex-1">{{row.MessageTitle}}</Col>
                            <Col>{{row.CreateTime}}</Col>
                        </Row>
                        <Row type="flex" class="msg-content" :class="{'read-message': row.MessageStatus === 1}">
                            <Col class="flex-1">
                            {{row.MessageDetail}}
                            <a :href="row | linkFormatter" @click="readMessage(row.ID)">{{$t('btn.viewMsgDetail')}}</a>
                            </Col>
                        </Row>
                    </template>
                </Table>
            </TabPane>
            <TabPane :label="$t('btn.applicantMsg')" name="4">
                <Table :noDataText="noDataText" :columns="columns" :data="data" ref="table4" @on-select="getSelectCount" @on-select-all="getSelectCount" @on-select-all-cancel="getSelectCount" @on-select-cancel="getSelectCount">
                    <template slot-scope="{ row }" slot="content">
                        <Row type="flex" class="msg-title" :class="{'read-message': row.MessageStatus === 1}">
                            <Col class="flex-1">{{row.MessageTitle}}</Col>
                            <Col>{{row.CreateTime}}</Col>
                        </Row>
                        <Row type="flex" class="msg-content" :class="{'read-message': row.MessageStatus === 1}">
                            <Col class="flex-1">
                            {{row.MessageDetail}}
                            <a :href="row | linkFormatter" @click="readMessage(row.ID)">{{$t('btn.viewMsgDetail')}}</a>
                            </Col>
                        </Row>
                    </template>
                </Table>
            </TabPane>
        </Tabs>
        <Page :total="total" show-total :page-size="10" :current="pageIndex" @on-change="onChange" v-show="total > 0" />
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from "@/components/layout.vue";
import api from "@/api";

export default {
    name: "message-page",
    components: {
        ilabLayout
    },
    data() {
        return {
            appPrefix: process.env.VUE_APP_prefix,
            noDataText: this.$i18n.t("columns.noDataText"),
            name: "0",
            breadcrumbs: [{
                txt: this.$i18n.t("nav.notification")
            }],
            columns: [{
                    type: "selection",
                    width: 60,
                    align: "center"
                },
                {
                    slot: "content",
                    title: " "
                }
            ],
            data: [],
            pageIndex: 1,
            total: 0,
            selectCount: 0
        };
    },
    methods: {
        //格式化配送消息
        deliveryFormatter(row) {
            let links = row.MessageLink.split("|"),
                linksNames = row.MessageDetail.substring(
                    row.MessageDetail.indexOf("（") + 1,
                    row.MessageDetail.lastIndexOf("）")
                ).split("|");
            var codes = [];
            links.length &&
                links.forEach(function (elt, index) {
                    if (elt.includes("?id")) {
                        codes.push(elt.substr(elt.lastIndexOf("=") + 1));
                    } else {
                        codes.push(elt.substr(elt.lastIndexOf("/") + 1));
                    }
                });
            let content = this.$i18n.t("page.yourMateriel");
            codes.length &&
                codes.forEach(function (elt, index) {
                    content +=
                        "<a href='/request/detail?id=" +
                        elt +
                        "'>" +
                        linksNames[index] +
                        "</a>";
                });
            content +=
                this.$i18n.t("page.in") +
                row.CreateTime +
                this.$i18n.t("page.beginDelivery");

            return content;
        },
        //获取选择的数量
        getSelectCount() {
            this.selectCount = this.$refs[`table${this.name}`].getSelection().length;
        },
        //单个已读
        readMessage(id) {
            api.cims.batchReadMessage([id]);
        },
        //批量已读
        async batchReadMessage() {
            const resp = await api.cims.batchReadMessage(
                this.$refs[`table${this.name}`].getSelection().map(item => item.ID)
            );
            if (resp.code == process.env.VUE_APP_code) {
                this.$Message.success(resp.message);
                this.fetchMessageData(this.pageIndex);
            } else {
                this.$Message.error(resp.message);
            }
        },
        //批量删除
        async batchDeleteMessage() {
            const resp = await api.cims.batchDeleteMessage(
                this.$refs[`table${this.name}`].getSelection().map(item => item.ID)
            );
            if (resp.code == process.env.VUE_APP_code) {
                this.$Message.success(resp.message);
                this.fetchMessageData();
            } else {
                this.$Message.error(resp.message);
            }
        },
        onChange(pageIndex) {
            this.pageIndex = pageIndex;
            this.fetchMessageData(pageIndex);
        },
        onTabsClick() {
            this.data = [];
            this.fetchMessageData();
        },
        async fetchMessageData(pageIndex = 1) {
            let resp = await api.cims.fetchMessageData({
                pageIndex,
                messageType: parseInt(this.name)
            });
            if (resp.code != process.env.VUE_APP_code) {
                this.noDataText = this.$i18n.t("columns.noDataText2");
            }
            this.data = resp.rows;
            this.total = resp.total;
            this.pageIndex = pageIndex;
            this.selectCount = 0;
        }
    },
    mounted() {
        this.fetchMessageData();
    },
    filters: {
        linkFormatter: function (row) {
            let messageLink = process.env.VUE_APP_prefix,
                isNewMessage = row.MessageLink.includes('?id'),
                id = isNewMessage ? row.MessageLink.split("=").pop() : row.MessageLink.split("/").pop();

            switch (true) {
                case [1, 2, 3, 4, 5].includes(row.MessageCode):
                    messageLink += `/applicantApprove/detail?id=${id}`;
                    break;
                case [6, 7].includes(row.MessageCode):
                    messageLink += `/requestApprove/detail?id=${id}`;
                    break;
                case [8].includes(row.MessageCode):
                    messageLink += `/request/detail?id=${id}`;
                    break;
                case [9].includes(row.MessageCode):
                    messageLink += `/borrow?id=${id}`;
                    break;
                default:
                    messageLink += row.MessageLink;
                    break;
            }

            return messageLink;
        }
    }
};
</script>

<style lang="less" scoped>
.content {
    .ivu-table-wrapper {
        margin-top: 16px;
    }

    .ilab-tabs {
        .ivu-btn-primary {
            margin-right: 16px;
        }

        /deep/ .ivu-icon {
            font-size: 20px;
            line-height: 1;
        }
    }

    .msg-title {
        font-size: 14px;
        padding-top: 10px;

        &.read-message {
            color: #bcbbbb;
        }
    }

    .msg-content {
        font-size: 13px;
        margin-top: 2px;
        padding-bottom: 10px;

        &.read-message {
            color: #bcbbbb;
        }
    }

    /deep/ tr th .ivu-table-cell,
    /deep/ tr td.ivu-table-cell {
        padding: 0;
    }

    /deep/ tr td {
        vertical-align: top;

        &:first-child {
            .ivu-table-cell {
                position: relative;
                top: 12px;
            }
        }
    }

    a {
        &.read-message {
            color: #bcbbbb;
        }

        &:visited {
            color: #bcbbbb;
        }
    }
}
</style>
