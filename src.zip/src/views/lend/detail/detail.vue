<template>
  <ilab-layout :breadcrumbs="breadcrumbs" ref="layout">
    <div slot="content" class="content">
      <div class="page-info">
        <div class="chinName">物料借用</div>
        <div class="chemName">Reagent Borrowing</div>
      </div>
      <div class="reagent-borrow fblack">
        【{{$t('page.lend')}}】
        <span class="lRed">{{data.ChinName}} {{data.BorrowQuantity}}{{data.Unit}}</span>
        {{data.CreateUser}} [{{data.CreateTime}}]
      </div>
      <Table :columns="columns" :data="tableData" ref="table">
        <template
          slot-scope="{ row }"
          slot="RequestQuantity"
        >{{row.RequestQuantity + row.RequestUnit}}</template>
        <template slot-scope="{ row }" slot="Action">
          <Button type="primary" @click="lend(row.ID)">{{$t('btn.lendNow')}}</Button>
        </template>
      </Table>
      <Page :total="total" @on-change="loadTable" :page-size="pageSize" v-show="total > 0"></Page>
    </div>
  </ilab-layout>
</template>
<script>
import ilabLayout from "@/components/layout.vue";
import utils from "@/utils/utils";
import api from "@/api";

export default {
  name: "cart",
  components: {
    ilabLayout
  },
  data() {
    return {
      appPrefix: process.env.VUE_APP_prefix,
      breadcrumbs: [
        {
          txt: this.$i18n.t("nav.materialBorrow")
        }
      ],
      pageSize: process.env.VUE_APP_page_size * 1,
      total: 0,
      data: {},
      tableData: [],
      columns: [
        {
          key: "RequestCode",
          title: this.$i18n.t("columns.requestCode")
        },
        {
          key: "ChinName",
          title: this.$i18n.t("form.chinName")
        },
        {
          key: "BottleType",
          title: this.$i18n.t("columns.bottleType")
        },
        {
          key: "CASNumber",
          title: this.$i18n.t("columns.CASNumber")
        },
        {
          key: "MDLNumber",
          title: this.$i18n.t("columns.mdl")
        },
        {
          slot: "RequestQuantity",
          title: this.$i18n.t("columns.requestQuantity")
        },
        {
          key: "Purity",
          title: this.$i18n.t("columns.purity")
        },
        {
          slot: "Action",
          title: this.$i18n.t("columns.operation")
        }
      ]
    };
  },
  methods: {
    async loadData() {
      try {
        const id = utils.getParams("id")*1;
        if (id) {
          const resp = await api.cims.fetchBottleBorrowData(id);
          if (resp.code == process.env.VUE_APP_code) {
            this.data = resp.response;
          } else {
            this.$Message.error(resp.message);
          }
        }
      } catch (e) {
        console.log(e);
      }
    },
    async loadTable(pageIndex = 1) {
      try {
        const id = utils.getParams("id")*1;
        if (id) {
          const resp = await api.cims.fetchBottleBorroRequestsData({
            pageIndex: pageIndex,
            borrowId: id
          });
          if (resp.code == process.env.VUE_APP_code) {
            this.tableData = resp.rows;
            this.total = resp.total;
          }
        }
      } catch (e) {
        console.log(e);
      }
    },
    async lend(requestId) {
      try {
        const id = utils.getParams("id")*1;
        if (id) {
          const resp = await api.cims.LendTA({
            requestId: requestId,
            borrowId: id
          });
          if (resp.code == process.env.VUE_APP_code) {
            this.$Message.success(resp.message);
            window.location.href = appPrefix + "/borrow?tab=2&id=" + id;
          } else {
            this.$Message.error(resp.message);
          }
        }
      } catch (e) {
        console.log(e);
      }
    }
  },
  mounted() {
    this.loadTable();
    this.loadData();
  }
};
</script>

<style lang="less" scoped>
.content {
  .reagent-borrow {
    line-height: 63px;
    background-color: #f8f8f8;
    padding: 0 16px;
    border-bottom: 1px solid #dddddd;
    color: #010101;
    font-size: 15px;
    margin-bottom: 20px;

    span {
      margin: 0 12px;
      color: #ff5f00;
    }
  }
}
</style>
