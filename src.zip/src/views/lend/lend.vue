<template>
	<ilab-layout :breadcrumbs="breadcrumbs" ref="layout">
		<div slot="content" class="content">
			<div class="page-info">
				<div class="chinName">TA的借用</div>
				<div class="chemName">Lend List</div>
			</div>

			<Table :columns="columns" :data="data" ref="table">
				<template slot-scope="{ row }" slot="BorrowQuantity">
					{{row.BorrowQuantity + row.Unit}}
				</template>
				<template slot-scope="{ row }" slot="Action">
					<Button type="primary" :to="appPrefix + '/lend/detail?id=' + row.ID">{{$t('columns.lendTo')}}</Button>
				</template>
			</Table>
			<Page :total="total" @on-change="fetchData" :page-size="pageSize"></Page>
		</div>
	</ilab-layout>
</template>
<script>
	import ilabLayout from '@/components/layout.vue'
	import utils from '@/utils/utils'
	import api from '@/api'

	export default {
		name: "lend-page",
		components: {
			ilabLayout,
		},
		data() {
			return {
				appPrefix: process.env.VUE_APP_prefix,
				expireTime: 1,
				breadcrumbs: [{
					txt: this.$i18n.t("page.notice")
				}],
				data: [],
				total: 0,
				pageSize: process.env.VUE_APP_page_size*1,
				columns: [{
					key: "CreateTime",
					title: this.$i18n.t("columns.postTime"),
					width : 200,
				}, {
					key: "ChinName",
					title: this.$i18n.t("columns.lnedMateriel"),
				}, {
					slot: "BorrowQuantity",
					title: this.$i18n.t("columns.demand"),
				}, {
					key: "Comments",
					title: this.$i18n.t("form.note"),
					width : 200,
				}, {
					key: "CreateUser",
					title: this.$i18n.t("columns.publisher"),
				}, {
					slot: "Action",
					title: this.$i18n.t("columns.operation"),
				}]
			}
		},
		methods: {
			async fetchData(pageIndex = 1) {
				const resp = await api.cims.fetchLendPageData({
					pageIndex: pageIndex,
					pageSize: this.pageSize
				})
				this.data = resp.rows;
				this.total = resp.total;
			}
		},
		async mounted() {
			this.fetchData();
		},

	}
</script>

<style lang="less" scoped>
	.content {
		.cart-table {
			/deep/ .ivu-input-number {
				width: 100px;
				margin-right: 6px;
			}

			/deep/ .red-text {
				color: #F44336;
			}
		}

		.cart-action {
			display: inline-block;
			margin-left: 12px;
			cursor: pointer;

			&:first-of-type {
				color: #006BFF;
			}

			&:last-of-type {
				color: #fd6100;
			}

		}

	}
</style>
