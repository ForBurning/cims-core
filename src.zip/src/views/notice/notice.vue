<template>
  <ilab-layout :breadcrumbs="breadcrumbs" ref="layout">
    <div slot="content" class="content">
      <div class="page-info">
        <div class="chinName">通知公告</div>
        <div class="chemName">Notices list</div>
      </div>

      <Table :columns="columns" :data="data" ref="table">
        <template slot-scope="{ row }" slot="Title">
          <a :href="'/notice/detail?id=' + row.ID">{{row.Title}}</a>
        </template>
        <template
          slot-scope="{ row }"
          slot="Type"
        >{{row.Type === 1 ? $t('page.notice1') : $t('page.notice2')}}</template>
      </Table>
      <Page :total="total" @on-change="fetchNoticePageData" :page-size="pageSize"></Page>
    </div>
  </ilab-layout>
</template>
<script>
import ilabLayout from "@/components/layout.vue";
import utils from "@/utils/utils";
import api from "@/api";

export default {
  name: "notice-page",
  components: {
    ilabLayout
  },
  data() {
    return {
      appPrefix: process.env.VUE_APP_prefix,
      expireTime: 1,
      breadcrumbs: [
        {
          txt: this.$i18n.t("page.notice")
        }
      ],
      data: [],
      total: 0,
      pageSize: process.env.VUE_APP_page_size * 1,
      columns: [
        {
          slot: "Title",
          title: this.$i18n.t("columns.title")
        },
        {
          slot: "Type",
          title: this.$i18n.t("columns.type"),
          width: 200
        },
        {
          key: "CreateTime",
          title: this.$i18n.t("columns.postTime"),
          width: 200
        }
      ]
    };
  },
  methods: {
    async fetchNoticePageData(pageIndex = 1) {
      const resp = await api.cims.fetchNoticePageData({
        pageIndex: pageIndex,
        pageSize: this.pageSize
      });
      this.data = resp.rows;
      this.total = resp.total;
    }
  },
  async mounted() {
    this.fetchNoticePageData();
  }
};
</script>

<style lang="less" scoped>
.content {
  .cart-table {
    /deep/ .ivu-input-number {
      width: 100px;
      margin-right: 6px;
    }

    /deep/ .red-text {
      color: #f44336;
    }
  }

  .cart-action {
    display: inline-block;
    margin-left: 12px;
    cursor: pointer;

    &:first-of-type {
      color: #006bff;
    }

    &:last-of-type {
      color: #fd6100;
    }
  }
}
</style>
