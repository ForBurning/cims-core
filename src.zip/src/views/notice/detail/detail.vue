<template>
  <ilab-layout :breadcrumbs="breadcrumbs" ref="layout">
    <div slot="content" class="content">
      <div class="page-info">
        <div class="chinName">公告详情</div>
        <div class="chemName">Notices Detail</div>
      </div>
      <div class="notice-detail">
        <div class="title">{{notice.Title}}</div>
        <Row class="sub-title">
          <Col
            span="12"
            style="text-align: left;padding-left: 24px;"
          >{{$t('time.time')}}：{{notice.CreateTime}}</Col>
          <Col
            span="12"
            style="text-align: right;padding-right: 24px;"
          >{{$t('page.author')}}：{{notice.CreateUser}}</Col>
        </Row>
        <div class="notice-content" v-html="notice.Content"></div>
      </div>
    </div>
  </ilab-layout>
</template>
<script>
import ilabLayout from "@/components/layout.vue";
import utils from "@/utils/utils";
import api from "@/api";

export default {
  name: "notice-detail",
  components: {
    ilabLayout
  },
  data() {
    return {
      appPrefix: process.env.VUE_APP_prefix,
      expireTime: 1,
      breadcrumbs: [
        {
          txt: "通知公告",
          href: "/notice"
        },
        {
          txt: "公告详情"
        }
      ],
      notice: {}
    };
  },
  async mounted() {
    try {
      const id = utils.getParams("id")*1;
      if (id) {
        const resp = await api.cims.fetchNoticeDetailData(id);
        if (resp.code == process.env.VUE_APP_code) {
          this.notice = resp.response;
        } else {
          this.$Message.error(resp.message);
        }
      } else {
        this.$Message.error(this.$i18n.t("message.paramsError"));
      }
    } catch (e) {
      console.log(e);
    }
  }
};
</script>

<style lang="less" scoped>
.content {
  .notice-detail {
    margin-top: 40px;
    text-align: center;
    border: none;

    .title {
      color: #2a2a2a;
      font-size: 22px;
      margin-bottom: 30px;
      font-weight: bold;
    }

    .sub-title {
      color: #979797;
      height: 44px;
      font-size: 14px;
      line-height: 44px;
      border-top: 1px solid #e9e9e9;
      border-bottom: 1px solid #e9e9e9;
      margin-bottom: 20px;
    }

    .notice-content {
      color: #292929;
      font-size: 14px;
      text-indent: 32px;
      line-height: 30px;
      text-align: left;
    }
  }
}
</style>
