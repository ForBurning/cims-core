<template>
<ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
        <div class="form">
            <p class="tableHeader">{{$t('page.requisition')}}</p>
            <div class="applicant-table">
                <div class="title">
                    <span class="line"></span>
                    {{$t('page.baseInfo')}}
                </div>
                <Form :label-width="150">
                    <Row class="flex">
                        <Col span="12">
                        <FormItem :label="$t('columns.categoryName')">
                            <div class="label">{{form.CategoryName}}</div>
                        </FormItem>
                        </Col>
                    </Row>
                    <Row class="flex">
                        <Col span="12">
                        <FormItem :label="$t('page.materielNumber')">
                            <div class="label">{{form.MaterielNumber}}</div>
                        </FormItem>
                        </Col>
                        <Col span="12">
                        <FormItem label="CAS号" v-show="form.CategoryCode === CR">
                            <div class="label">{{form.CASNumber}}</div>
                        </FormItem>
                        </Col>
                    </Row>
                    <Row class="flex">
                        <Col span="12">
                        <FormItem :label="$t('columns.bottleName')">
                            <div class="label">{{form.ChinName}}</div>
                        </FormItem>
                        </Col>
                        <Col span="12">
                        <FormItem :label="$t('form.chemName')">
                            <div class="label">{{form.ChemName}}</div>
                        </FormItem>
                        </Col>
                    </Row>

                    <div class="title">
                        <span class="line"></span>
                        {{$t('page.applicantInfo')}}
                    </div>
                    <Row class="flex">
                        <Col span="12">
                        <FormItem :label="form.CategoryCode === CR ?  $t('columns.purity') : $t('columns.purity1')">
                            <div class="label">{{form.Purity}}</div>
                        </FormItem>
                        </Col>
                        <Col span="12">
                        <FormItem :label="$t('columns.number')">
                            <div class="label">{{form.Number}}</div>
                        </FormItem>
                        </Col>
                    </Row>
                    <Row class="flex">
                        <Col span="12">
                        <FormItem :label="$t('columns.price')">
                            <div class="label">{{form.Price}}</div>
                        </FormItem>
                        </Col>
                        <Col span="12">
                        <FormItem :label="$t('columns.totalPrice') + '(￥)'">
                            <div class="label">{{form.TotalPrice}}</div>
                        </FormItem>
                        </Col>
                    </Row>
                    <Row class="flex">
                        <Col span="12">
                        <FormItem :label="$t('columns.projectCode')">
                            <div class="label">{{form.ProjectCode}}</div>
                        </FormItem>
                        </Col>
                        <Col span="12">
                        <FormItem :label="$t('columns.bottleType')">
                            <div class="label">{{form.Specifications}}</div>
                        </FormItem>
                        </Col>
                    </Row>
                    <Row class="flex">
                        <Col span="12">
                        <FormItem :label="$t('page.supplier')">
                            <div class="label">{{form.Supplier}}</div>
                        </FormItem>
                        </Col>
                        <Col span="12">
                        <FormItem :label="$t('columns.expectationPeriod')">
                            <div class="label">{{form.ExpectationPeriod}}</div>
                        </FormItem>
                        </Col>
                    </Row>
                </Form>
            </div>
        </div>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from "@/components/layout.vue";
import api from "@/api";
import utils from "@/utils/utils";

export default {
    name: "applicant-detail",
    components: {
        ilabLayout
    },
    data() {
        return {
            appPrefix: process.env.VUE_APP_prefix,
            CR: process.env.VUE_APP_CR,
            breadcrumbs: [{
                    txt: this.$i18n.t("nav.myApply"),
                    href: "/applicant"
                },
                {
                    txt: this.$i18n.t("page.requisition")
                }
            ],
            form: {}
        };
    },
    methods: {},
    async mounted() {
        let id = utils.getParams("id") * 1;

        if (id) {
            let resp = await api.cims.getApplicant(id);
            if (resp.code == process.env.VUE_APP_code) {
                this.form = resp.response;
            }

        }
    }
};
</script>

<style lang="less" scoped>
.content {
    .form {
        .tableHeader {
            font-size: 22px;
            color: #292929;
            text-align: center;
            margin: 24px 0;
        }

        .applicant-table {
            border: 1px dashed #dcdcdc;
            padding: 30px 60px 0;

            .title {
                font-size: 18px;
                color: #282828;
                border-bottom: 1px dashed #dbdbdb;
                padding-bottom: 6px;
                margin: 16px 0 4px;

                span {
                    display: inline-block;
                    width: 4px;
                    height: 17px;
                    background-color: #1388ff;
                    position: relative;
                    top: 2px;
                    margin-right: 4px;
                }
            }

            .ivu-form-item {
                margin: 12px 0;

                .label {
                    text-align: right;
                    vertical-align: middle;
                    float: left;
                    color: #515a6e;
                    line-height: 1;
                    padding: 10px 12px 10px 0;
                    box-sizing: border-box;
                    font-size: 14px;
                }

                &.ivu-form-item-required.hideRequired {
                    /deep/ .ivu-form-item-label:before {
                        display: none;
                    }
                }

                /deep/ .ivu-form-item-label {
                    font-size: 15px;
                }
            }

            .table-action {
                margin: 20px -60px 0;
                padding: 20px 0;
                background-color: #f6f6f6;

                button {
                    width: 200px;
                    margin: 0 auto;
                    display: block;
                }
            }
        }
    }
}
</style>
