<template>
<ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
        <div class="page-info">
            <Row type="flex">
                <Col class="flex-1">
                <div class="chinName">我的申购</div>
                <div class="chemName">My Apply</div>
                </Col>
                <Col>
                <Button size="large" type="primary" icon="md-add" style="margin-right: 15px;" @click="openSelectModal">{{$t('page.requisition')}}</Button>
                </Col>
            </Row>
        </div>

        <Tabs v-model="name" class="ilab-tabs" :animated="false" @on-click="onTabsClick">
            <TabPane :label="$t('page.all')" name="1">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.bottleName')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.applicantDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="columns1" :data="data" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="ChinName">
                        <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
                    </template>
                    <template slot-scope="{ row }" slot="Action1">
                        <Button :to="`/applicant/add?id=${row.ID}&type=5`" v-if="row.ProcurementScheduleStatus === enums.procurementScheduleStatus.Uncommitted" icon="md-create">{{$t('btn.edit')}}</Button>
                        <Button :to="`/applicant/add?id=${row.ID}&type=4`" v-else icon="md-add">{{$t('btn.applicant')}}</Button>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
            </TabPane>
            <TabPane :label="$t('tab.pending')" name="2">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.bottleName')}}:
                    <Input v-model="condition1"></Input>
                    {{$t('columns.applicantTime')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :key="item.CategoryCode" :value="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="columns2" :data="data" :noDataText="noDataText" ref="table2" @on-select="getSelectCount" @on-select-all="getSelectCount" @on-select-all-cancel="getSelectCount" @on-select-cancel="getSelectCount">
                    <template slot-scope="{ row }" slot="ChinName">
                        <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
                    </template>
                    <template slot-scope="{ row }" slot="Action1">
                        <Button :to="`/applicant/add?id=${row.ID}&type=5`" v-if="row.ProcurementScheduleStatus === enums.procurementScheduleStatus.Uncommitted" icon="md-create">{{$t('btn.edit')}}</Button>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />

                <Row class="batch-operation" v-if="total > 0">
                    <Col span="12">
                    <Button class="select-all-btn" @click="selectAll">{{selectCount === data.length ? $t('btn.cancelAll') : $t('btn.selectAll')}}</Button>
                    </Col>
                    <Col span="12">
                    <Button size="large" type="primary" :disabled="selectCount === 0" @click="batchSubmit">{{$t('btn.batchSubmit')}}</Button>
                    <Button size="large" type="error" :disabled="selectCount === 0" @click="batchDelete">{{$t('btn.batchDelete')}}</Button>
                    </Col>
                </Row>
            </TabPane>
            <TabPane :label="$t('tab.approving')" name="3">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.bottleName')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.applicantDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="columns3" :data="data" :noDataText="noDataText" ref="table3" @on-select="getSelectCount" @on-select-all="getSelectCount" @on-select-all-cancel="getSelectCount" @on-select-cancel="getSelectCount">
                    <template slot-scope="{ row }" slot="ChinName">
                        <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
                    </template>
                    <template slot-scope="{ row }" slot="Action1">
                        <Button :to="`/applicantApprove/detail?id=${row.PurchaseCode}`">{{$t('btn.approveDetail')}}</Button>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
                <Row class="batch-operation" v-if="total > 0">
                    <Col span="12">
                    <Button class="select-all-btn" @click="selectAll">{{selectCount === data.length ? $t('btn.cancelAll') : $t('btn.selectAll')}}</Button>
                    </Col>
                    <Col span="12">
                    <Button size="large" type="primary" :disabled="selectCount === 0" @click="openModal">{{$t('btn.batchWithdrawal')}}</Button>
                    </Col>
                </Row>
            </TabPane>
            <TabPane :label="$t('tab.processing')" name="4">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.bottleName')}}:
                    <Input v-model="condition1"></Input>
                    {{$t('columns.applicantDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="columns4" :data="data" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="ChinName">
                        <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
            </TabPane>
            <TabPane :label="$t('tab.processed')" name="5">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.bottleName')}}:
                    <Input v-model="condition1"></Input>
                    {{$t('columns.applicantDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="columns5" :data="data" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="ChinName">
                        <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
            </TabPane>
            <TabPane :label="$t('tab.placed')" name="6">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.bottleName')}}:
                    <Input v-model="condition1"></Input>
                    {{$t('columns.applicantDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="columns6" :data="data" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="ChinName">
                        <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
            </TabPane>
            <TabPane :label="$t('tab.arrived')" name="7">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.bottleName')}}:
                    <Input v-model="condition1"></Input>
                    {{$t('columns.applicantDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="columns7" :data="data" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="ChinName">
                        <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
            </TabPane>
            <TabPane :label="$t('tab.rejected')" name="8">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.bottleName')}}:
                    <Input v-model="condition1"></Input>
                    {{$t('columns.applicantDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="columns8" :data="data" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="ChinName">
                        <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
                    </template>
                    <template slot-scope="{ row }" slot="Action1">
                        <Button :to="`/applicantApprove/detail?id=${row.PurchaseCode}`">{{$t('btn.approveDetail')}}</Button>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
            </TabPane>
        </Tabs>

        <Modal :title="$t('form.withdraw')" v-model="modal" @on-ok="batchRecall" :loading="loading">
            <Form ref="form" :model="form" :rules="rules" :label-width="80">
                <FormItem :label="$t('form.withdrawReason')" prop="reason">
                    <Input type="textarea" :placeholder="$t('message.placeSelect', [$t('form.withdrawReason')])" v-model="form.reason" :autosize="{minRows: 3,maxRows: 5}"></Input>
                </FormItem>
            </Form>
        </Modal>

        <Modal :title="$t('btn.add')" v-model="modal1">
            <Row class="applicant-modal" type="flex">
                <Col class="flex-1">
                <a class="panel" :href="`${appPrefix}/applicant/add`">
                    <img src="@/assets/img/newMateriel.png" alt />
                    <span>{{$t('btn.completelyNew')}}</span>
                </a>
                </Col>
                <Col class="flex-1">
                <div class="panel" @click="openSelectModal">
                    <img src="@/assets/img/selectMateriel.png" alt />
                    <span>{{$t('btn.addFrom')}}</span>
                </div>
                </Col>
            </Row>
        </Modal>

        <Modal :title="$t('btn.add')" v-model="modal2" :width="800" class="select-materiel-modal" :loading="loading">
            <Row type="flex">
                <Col class="flex-1">
                <Input type="text" :placeholder="$t('page.materielNumber')" v-model="selectModal.materielNumber" @on-enter="fetchMaterielsPageData(1)"></Input>
                </Col>
                <Col class="flex-1">
                <Input type="text" :placeholder="$t('columns.bottleName')" v-model="selectModal.chinName" @on-enter="fetchMaterielsPageData(1)"></Input>
                </Col>
                <Col class="flex-1">
                <Input type="text" :placeholder="$t('columns.CASNumber')" v-model="selectModal.casNumber" @on-enter="fetchMaterielsPageData(1)"></Input>
                </Col>
                <Col class="flex-1">
                <Select v-model="selectModal.categoryCode" style="width:160px" :placeholder="$t('columns.categoryName')" transfer clearable @on-change="fetchMaterielsPageData(1)">
                    <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                </Select>
                </Col>
                <Col style="width: 80px;text-align: right;padding-right: 0;">
                <Button type="primary" icon="ios-search" @click="fetchMaterielsPageData(1)">{{$t('btn.search')}}</Button>
                </Col>
                <Table :columns="mcolumns" :data="mdata" size="small" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="ChinName">
                        {{row.ChinName}}
                    </template>
                    <template slot-scope="{ row }" slot="Radio">
                        <Radio v-model="row.ischecked" @on-change="radioOnChange($event, row)"></Radio>
                    </template>
                </Table>
                <Page :total="mtotal" show-total :page-size="5" @on-change="fetchMaterielsPageData" v-show="mtotal > 0" :current="mPageIndex" />
            </Row>
            <p slot="footer">
                <Row type="flex">
                    <Col>
                    {{$t('form.try')}}
                    <a :href="`${appPrefix}/applicant/add`" class="add-applicant-button">{{$t('btn.completelyApplicant')}}>></a>
                    </Col>
                    <Col class="flex-1">
                    <Button @click="modal2=false">{{$t('btn.cancel')}}</Button>
                    <Button type="primary" @click="addApplicant">{{$t('btn.submit')}}</Button>
                    </Col>
                </Row>
            </p>
        </Modal>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from "@/components/layout.vue";
import api from "@/api";
import columns from "@/utils/columns";
import utils from "@/utils/utils";
import enums from "@/utils/enums";

export default {
    name: "applicant-page",
    components: {
        ilabLayout
    },
    created() {
        this.name = utils.getParams("name") || "1";
    },
    data() {
        return {
            noDataText: this.$i18n.t("columns.noDataText"),
            roles: utils.getCimsInfo().RoleCodes,
            appPrefix: process.env.VUE_APP_prefix,
            name: "1",
            breadcrumbs: [{
                txt: this.$i18n.t("nav.myApply")
            }],
            columns1: [
                columns.ChinName(this.$i18n.t("columns.bottleName")),
                columns.MaterielNumber(this.$i18n.t("page.materielNumber")),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.CASNumber(this.$i18n.t("columns.CASNumber")),
                columns.Purity(this.$i18n.t("columns.bOrp")),
                columns.number(this.$i18n.t("columns.number")),
                columns.Price(this.$i18n.t("columns.price")),
                columns.TotalPrice(this.$i18n.t("columns.totalPrice")),
                columns.ShowState(this.$i18n.t("columns.state")),
                columns.ApplyTime(this.$i18n.t("columns.applyTime")),
                columns.Action1(this.$i18n.t("columns.operation"))
            ],
            columns2: [
                columns.Select,
                columns.ChinName(this.$i18n.t("columns.bottleName")),
                columns.MaterielNumber(this.$i18n.t("page.materielNumber")),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.CASNumber(this.$i18n.t("columns.CASNumber")),
                columns.Purity(this.$i18n.t("columns.bOrp")),
                columns.number(this.$i18n.t("columns.number")),
                columns.Price(this.$i18n.t("columns.price")),
                columns.TotalPrice(this.$i18n.t("columns.totalPrice")),
                columns.ApplyTime(this.$i18n.t("columns.applyTime")),
                columns.Action1(this.$i18n.t("columns.operation"))
            ],
            columns3: [
                columns.Select,
                columns.ChinName(this.$i18n.t("columns.bottleName")),
                columns.MaterielNumber(this.$i18n.t("page.materielNumber")),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.CASNumber(this.$i18n.t("columns.CASNumber")),
                columns.Purity(this.$i18n.t("columns.bOrp")),
                columns.number(this.$i18n.t("columns.number")),
                columns.Price(this.$i18n.t("columns.price")),
                columns.TotalPrice(this.$i18n.t("columns.totalPrice")),
                columns.ApplyTime(this.$i18n.t("columns.applyTime")),
                columns.Action1(this.$i18n.t("columns.operation"))
            ],
            columns4: [
                columns.ChinName(this.$i18n.t("columns.bottleName")),
                columns.MaterielNumber(this.$i18n.t("page.materielNumber")),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.CASNumber(this.$i18n.t("columns.CASNumber")),
                columns.Purity(this.$i18n.t("columns.bOrp")),
                columns.number(this.$i18n.t("columns.number")),
                columns.Price(this.$i18n.t("columns.price")),
                columns.TotalPrice(this.$i18n.t("columns.totalPrice")),
                columns.ApplyTime(this.$i18n.t("columns.applyTime"))
            ],
            columns5: [
                columns.ChinName(this.$i18n.t("columns.bottleName")),
                columns.MaterielNumber(this.$i18n.t("page.materielNumber")),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.CASNumber(this.$i18n.t("columns.CASNumber")),
                columns.Purity(this.$i18n.t("columns.bOrp")),
                columns.number(this.$i18n.t("columns.number")),
                columns.Price(this.$i18n.t("columns.price")),
                columns.TotalPrice(this.$i18n.t("columns.totalPrice")),
                columns.ApplyTime(this.$i18n.t("columns.applyTime"))
            ],
            columns6: [
                columns.ChinName(this.$i18n.t("columns.bottleName")),
                columns.MaterielNumber(this.$i18n.t("page.materielNumber")),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.CASNumber(this.$i18n.t("columns.CASNumber")),
                columns.Purity(this.$i18n.t("columns.bOrp")),
                columns.number(this.$i18n.t("columns.number")),
                columns.Price(this.$i18n.t("columns.price")),
                columns.TotalPrice(this.$i18n.t("columns.totalPrice")),
                columns.EstimatedArrival(this.$i18n.t("columns.estimatedArrival")),
                columns.ApplyTime(this.$i18n.t("columns.applyTime"))
            ],
            columns7: [
                columns.ChinName(this.$i18n.t("columns.bottleName")),
                columns.MaterielNumber(this.$i18n.t("page.materielNumber")),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.CASNumber(this.$i18n.t("columns.CASNumber")),
                columns.Purity(this.$i18n.t("columns.bOrp")),
                columns.number(this.$i18n.t("columns.number")),
                columns.Price(this.$i18n.t("columns.price")),
                columns.TotalPrice(this.$i18n.t("columns.totalPrice")),
                columns.EstimatedArrival(this.$i18n.t("columns.estimatedArrival")),
                columns.ApplyTime(this.$i18n.t("columns.applyTime"))
            ],
            columns8: [
                columns.ChinName(this.$i18n.t("columns.bottleName")),
                columns.MaterielNumber(this.$i18n.t("page.materielNumber")),
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.CASNumber(this.$i18n.t("columns.CASNumber")),
                columns.Purity(this.$i18n.t("columns.bOrp")),
                columns.number(this.$i18n.t("columns.number")),
                columns.Price(this.$i18n.t("columns.price")),
                columns.TotalPrice(this.$i18n.t("columns.totalPrice")),
                columns.ApproveReason(this.$i18n.t("columns.approveReason")),
                columns.ApplyTime(this.$i18n.t("columns.applyTime")),
                columns.Action1(this.$i18n.t("columns.operation"))
            ],
            mcolumns: [
                columns.Radio,
                columns.CategoryName(this.$i18n.t("columns.categoryName")),
                columns.MaterielNumber(this.$i18n.t("page.materielNumber")),
                columns.ChinName(this.$i18n.t("columns.bottleName")),
                columns.CASNumber(this.$i18n.t("columns.CASNumber"))
            ],
            mdata: [],
            mtotal: 0,
            mPageIndex: 1,
            data: [],
            total: 0,
            condition1: "",
            condition2: "",
            condition3: "",
            curRows: "",
            pageIndex: 1,
            selectCount: 0,
            materielType: [],
            applicantState: [
                "",
                "Uncommitted",
                "ApprovalPending",
                "Pending",
                "Processed",
                "Placed",
                "Arrived",
                "Refused"
            ],
            selectCount: 0,
            enums: enums,
            loading: true,
            modal: false,
            modal1: false,
            modal2: false,
            form: {
                reason: ""
            },
            rules: {
                reason: [{
                    required: true,
                    message: this.$i18n.t("message.notNull", [
                        this.$i18n.t("form.returnReason")
                    ]),
                    trigger: "change"
                }]
            },

            selectModal: {
                materielNumber: "",
                chinName: "",
                casNumber: "",
                categoryCode: ""
            },
            materiel: ""
        };
    },
    methods: {
        //打开撤回模态框
        openModal() {
            this.$refs.form.resetFields();
            this.modal = true;
        },
        //打开选择物料模态框
        openSelectModal() {
            this.modal2 = true;
            this.mdata = [];
            this.mtotal = 0;
            this.selectModal = {
                materielNumber: "",
                chinName: "",
                casNumber: "",
                categoryCode: ""
            };
            this.fetchMaterielsPageData();
        },
        //关闭loading
        resetLoading() {
            this.loading = false;
            setTimeout(() => {
                this.loading = true;
            }, 0);
        },
        //加载物料类型
        async fetchMaterielType() {
            const resp = await api.cims.fetchMaterielType();

            if (resp.code == process.env.VUE_APP_code) {
                this.materielType = resp.response;
            }
        },
        //加载物料
        async fetchMaterielsPageData(pageIndex = 1) {
            const resp = await api.cims.fetchMaterielsPageData({
                pageIndex,
                pageSize: 5,
                ...this.selectModal
            });

            if (resp.code == process.env.VUE_APP_code) {
                resp.rows.map(item => {
                    item.ischecked = false;
                });

                if (resp.code == process.env.VUE_APP_code) {
                    this.mdata = resp.rows;
                    this.mtotal = resp.total;
                } else {
                    this.mdata = resp.rows;
                    this.mtotal = resp.total;
                    this.noDataText = '<div class="no-data"></div> <p class="no-data-text">' + this.$i18n.t("form.notFind") + `<a href="${this.appPrefix}/applicant/add">` + this.$i18n.t("btn.completelyNew") + '</a></p>';
                }
                this.mPageIndex = pageIndex;
            }
        },
        //选择物料切换
        radioOnChange(ischecked, materiel) {
            this.mdata.map(item => {
                if (item.ID === materiel.ID) {
                    item.ischecked = true;
                } else {
                    item.ischecked = false;
                }
            });
            this.materiel = materiel;
        },
        //通过已选物料跳转
        addApplicant() {
            if (this.materiel) {
                window.location.href =
                    this.appPrefix +
                    `/applicant/add?id=${this.materiel.MaterielNumber}&type=1`;
            } else {
                this.resetLoading();
                this.$Message.warning("请选择一个物料");
            }
        },
        //tab切换
        onTabsClick(tabName) {
            this.condition1 = "";
            this.condition2 = "";
            this.condition3 = "";
            this.data = [];
            this.total = 0;
            this.selectCount = 0;
            this.fetchData();
        },
        //获取表格数据
        async fetchData(pageIndex = 1) {
            this.noDataText = this.$i18n.t("columns.noDataText");

            let resp = {};
            if (this.name === "8") {
                resp = await api.cims.fetchMyApplicantRefuseData({
                    pageIndex: pageIndex,
                    chinName: this.condition1,
                    applyBeginTime: this.condition2.length ? this.condition2[0] : "",
                    applyEndTime: this.condition2.length ? this.condition2[1] : "",
                    categoryCode: this.condition3
                });
            } else {
                resp = await api.cims.fetchMyApplicantData({
                    pageIndex: pageIndex,
                    chinName: this.condition1,
                    applyBeginTime: this.condition2.length ? this.condition2[0] : "",
                    applyEndTime: this.condition2.length ? this.condition2[1] : "",
                    categoryCode: this.condition3,
                    purchasesSerachState: this.applicantState[this.name - 1]
                });
            }

            if (resp.code == process.env.VUE_APP_code) {
                this.data = resp.rows;
                this.total = resp.total;
            } else {
                this.data = [];
                this.total = 0;
                this.noDataText = this.$i18n.t("columns.noDataText2");
            }
            this.pageIndex = pageIndex;
            this.selectCount = 0;
        },
        //全选
        selectAll() {
            const isSelectAll = this.selectCount === this.data.length;
            if (isSelectAll) {
                this.$refs[`table${this.name}`].selectAll(false);
                this.selectCount = 0;
            } else {
                this.$refs[`table${this.name}`].selectAll(true);
                this.selectCount = this.data.length;
            }
        },
        getSelectCount() {
            this.selectCount = this.$refs[`table${this.name}`].getSelection().length;
        },
        //批量提交
        async batchSubmit() {
            const selection = this.$refs[`table${this.name}`].getSelection();
            const resp = await api.cims.batchSubmitApplicant(
                selection.map(item => {
                    return {
                        purchaseId: item.ID,
                        number: item.Number
                    };
                })
            );
            if (resp.code == process.env.VUE_APP_code) {
                this.$Message.success(resp.message);
                this.fetchData();
            } else {
                this.$Message.error(resp.message);
            }
        },
        //批量删除
        async batchDelete() {
            const selection = this.$refs[`table${this.name}`].getSelection();
            const resp = await api.cims.batchDeleteApplicant(
                selection.map(item => item.ID)
            );
            if (resp.code == process.env.VUE_APP_code) {
                this.$Message.success(resp.message);
                this.fetchData();
            } else {
                this.$Message.error(resp.message);
            }
        },
        //批量撤回
        async batchRecall() {
            const valid = await this.$refs.form.validate();
            if (valid) {
                const selection = this.$refs[`table${this.name}`].getSelection();
                const resp = await api.cims.batchRecallApplicant({
                    purchaseIds: selection.map(item => item.ID),
                    reason: this.form.reason
                });
                if (resp.code == process.env.VUE_APP_code) {
                    this.$Message.success(resp.message);
                    this.modal = false;
                    this.fetchData();
                } else {
                    this.$Message.error(resp.message);
                    this.resetLoading();
                }
            } else {
                this.resetLoading();
            }
        }
    },
    mounted() {
        this.fetchData();
        this.fetchMaterielType();
    }
};
</script>

<style lang="less" scoped>
.applicant-modal {
    text-align: center;

    .ivu-col {
        border: 1px solid #e8eaec;
        margin: 20px 40px 30px 0;
        cursor: pointer;

        .panel {
            display: block;
        }

        &:hover {
            border-color: #077ed3;
            color: #077ed3;
        }

        &:first-child {
            margin: 20px 40px 30px 40px;
        }
    }

    img {
        margin-top: 20px;
        width: 80px;
    }

    span {
        display: block;
        padding: 12px 0;
        font-size: 14px;
    }
}

.select-materiel-modal {
    .ivu-col {
        padding-right: 10px;

        &:nth-of-type(4) {
            padding-right: 0;
        }
    }

    .add-applicant-button {
        display: inline-block;
        font-size: 13px;
        color: #3f8ce1;
        margin: 6px 0 0 4px;
    }

    .ivu-table-wrapper {
        margin-top: 16px;
    }

    /deep/ .ivu-table {
        &:before {
            display: none;
        }
    }

    /deep/ .no-data {
        width: 200px;
        height: 200px;
        background: url(../../assets/img/no-data.png) no-repeat center;
        background-size: contain;
        margin: 0 auto;
    }

    /deep/ .no-data-text {
        padding-bottom: 20px;
    }

    .ivu-page {
        display: block;
        width: 100%;
    }
}
</style>
