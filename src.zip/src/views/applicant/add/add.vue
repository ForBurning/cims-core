<template>
<ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
        <div class="form">
            <p class="tableHeader">{{$t('page.addRequisition')}}</p>
            <div class="applicant-table">
                <div class="title">
                    <span class="line"></span>
                    {{$t('page.baseInfo')}}
                </div>
                <Form ref="form" :model="form" :rules="rules" :label-width="150">
                    <!-- 完全新建 -->
                    <div v-if="type === 0">
                        <Row class="flex">
                            <Col span="12">
                            <FormItem :label="$t('columns.categoryName')" prop="CategoryCode">
                                <Select v-model="form.CategoryCode" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer @on-change="onCategoryCodeChange">
                                    <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                                </Select>
                            </FormItem>
                            </Col>
                            <Col span="12">
                            <FormItem :label="$t('columns.CASNumber')" prop="CASNumber" v-show="form.CategoryCode === CR">
                                <Input v-model="form.CASNumber"></Input>
                            </FormItem>
                            </Col>
                        </Row>
                        <Row class="flex">
                            <Col span="12">
                            <FormItem :label="$t('columns.bottleName')" prop="ChinName">
                                <div v-if="type !== 0" class="label">{{form.ChinName}}</div>
                                <Input v-model="form.ChinName"></Input>
                            </FormItem>
                            </Col>
                            <Col span="12">
                            <FormItem :label="$t('form.chemName')" prop="ChemName">
                                <div v-if="type !== 0" class="label">{{form.ChemName}}</div>
                                <Input v-model="form.ChemName"></Input>
                            </FormItem>
                            </Col>
                        </Row>
                    </div>
                    <!-- 已有申购 -->
                    <div v-else>
                        <Row class="flex">
                            <Col span="12">
                            <FormItem :label="$t('columns.categoryName')" class="rela-top-2">{{form.CategoryName}}</FormItem>
                            </Col>
                        </Row>
                        <Row class="flex">
                            <Col span="12">
                            <FormItem :label="$t('page.materielNumber')" class="hideRequired rela-top-2">{{form.MaterielNumber}}</FormItem>
                            </Col>
                            <Col span="12">
                            <FormItem :label="$t('columns.CASNumber')" v-show="form.CategoryCode === CR" class="hideRequired rela-top-2">{{form.CASNumber}}</FormItem>
                            </Col>
                        </Row>
                        <Row class="flex">
                            <Col span="12">
                            <FormItem :label="$t('columns.bottleName')" class="hideRequired rela-top-2">{{form.ChinName}}</FormItem>
                            </Col>
                            <Col span="12">
                            <FormItem :label="$t('form.chemName')" class="hideRequired rela-top-2">{{form.ChemName}}</FormItem>
                            </Col>
                        </Row>
                    </div>

                    <div class="title">
                        <span class="line"></span>
                        {{$t('page.applicantInfo')}}
                    </div>
                    <Row class="flex">
                        <Col span="12">
                        <FormItem :label="form.CategoryCode === CR ? $t('columns.purity') : $t('columns.purity1')" prop="Purity">
                            <Input v-model="form.Purity"></Input>
                        </FormItem>
                        </Col>
                        <Col span="12">
                        <FormItem :label="$t('columns.number')" prop="Number">
                            <InputNumber :min="1" v-model="form.Number" style="width:389px;"></InputNumber>
                        </FormItem>
                        </Col>
                    </Row>
                    <Row class="flex">
                        <Col span="12">
                        <FormItem :label="$t('columns.price')" prop="Price">
                            <Input v-model="form.Price"></Input>
                        </FormItem>
                        </Col>
                        <Col span="12">
                        <FormItem :label="$t('columns.totalPrice') + '(￥)'">
                            <Input v-model="totalPrice" disabled></Input>
                        </FormItem>
                        </Col>
                    </Row>
                    <Row class="flex">
                        <Col span="12">
                        <FormItem :label="$t('columns.projectCode')" prop="ProjectsId">
                            <Select v-model="form.ProjectsId">
                                <Option v-for="item in projectList" :value="item.ID" :key="item.ID">{{item.ProjectCode}}</Option>
                            </Select>
                        </FormItem>
                        </Col>
                        <Col span="12">
                        <FormItem :label="$t('columns.bottleType')" prop="InitialQuantity">
                            <Input v-model="form.InitialQuantity">
                            <Select slot="append" style="width: 70px" v-model="form.Unit" clearable>
                                <Option :value="item.Code" :key="item.Code" v-for="item in unit">{{item.Name}}</Option>
                            </Select>
                            <Select slot="append" style="width: 70px" v-model="form.PackingUnit" clearable>
                                <Option :value="item.Code" :key="item.Code" v-for="item in packingUnit">{{item.Name}}</Option>
                            </Select>
                            </Input>
                        </FormItem>
                        </Col>
                    </Row>
                    <Row class="flex">
                        <Col span="12">
                        <FormItem :label="$t('page.supplier')" prop="Supplier">
                            <Input v-model="form.Supplier"></Input>
                        </FormItem>
                        </Col>
                        <Col span="12">
                        <FormItem :label="$t('columns.expectationPeriod')" prop="ExpectationPeriod">
                            <Input v-model="form.ExpectationPeriod"></Input>
                        </FormItem>
                        </Col>
                    </Row>
                    <div class="table-action" v-if="type == 5">
                        <Button type="primary" size="large" :loading="loading" @click="saveOfEdit">
                            <span v-if="loading">{{$t('btn.saving')}}...</span>
                            <span v-else>{{$t('btn.saveDraft')}}</span>
                        </Button>

                        <Button type="primary" size="large" :loading="loading1" @click="saveAndsubmit">
                            <span v-if="loading1">{{$t('btn.submiting')}}...</span>
                            <span v-else>{{$t('btn.saveAndSubmit')}}</span>
                        </Button>
                    </div>

                    <div class="table-action" v-else>
                        <Button type="primary" size="large" :loading="loading" @click="save(false)">
                            <span v-if="loading">{{$t('btn.submiting')}}...</span>
                            <span v-else>{{$t('btn.saved')}}</span>
                        </Button>

                        <Button type="primary" size="large" :loading="loading1" @click="save(true)">
                            <span v-if="loading1">{{$t('btn.submiting')}}...</span>
                            <span v-else>{{$t('btn.submit')}}</span>
                        </Button>
                    </div>
                </Form>
            </div>
        </div>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from "@/components/layout.vue";
import api from "@/api";
import utils from "@/utils/utils";

export default {
    name: "applicant-add",
    components: {
        ilabLayout
    },
    data() {
        const validatorInitialQuantity = (rule, value, callback) => {
            if (this.form.InitialQuantity === '') {
                if (this.form.Unit || this.form.PackingUnit) {
                    callback(new Error(this.$i18n.t("message.bottleTypeNoComplete")));
                } else {
                    callback();
                }
            } else {
                if (!utils.isPositive(this.form.InitialQuantity)) {
                    callback(new Error(this.$i18n.t("message.overZero", [
                        this.$i18n.t("columns.bottleType")
                    ])));
                } else {
                    if (!this.form.Unit || !this.form.PackingUnit) {
                        callback(new Error(this.$i18n.t("message.bottleTypeNoComplete")))
                    } else {
                        this.form.Specifications = this.form.InitialQuantity + this.form.Unit + '/' + this.form.PackingUnit;
                        callback();
                    }
                }
            }
        };

        return {
            appPrefix: process.env.VUE_APP_prefix,
            breadcrumbs: [{
                    txt: this.$i18n.t("nav.myApply"),
                    href: "/applicant"
                },
                {
                    txt: this.$i18n.t("page.requisition")
                }
            ],
            id: "",
            type: 0,
            projectList: [],
            loading: false,
            loading1: false,
            materielType: [],
            CR: process.env.VUE_APP_CR,
            isSubmiting: false, //是否正在提交中
            unit: [],
            packingUnit: [],
            form: {
                CategoryCode: process.env.VUE_APP_CR,
                MaterielNumber: "",
                ChinName: "",
                ChemName: "",
                CASNumber: "",
                Purity: "",
                Specifications: "",
                Number: 1,
                Price: "",
                TotalPrice: "",
                ProjectsId: "",
                InitialQuantity: "",
                Unit: "",
                PackingUnit: "",
                Supplier: "",
                ExpectationPeriod: "",
                PurchaseType: 1,
                IsInquiry: 0,
                Applicant: utils.getCimsInfo().UserInfo.RealName,
                DepartmentId: 0
            },
            rules: {
                CASNumber: [{
                    validator: this.validCas,
                    trigger: "blur"
                }],
                ChinName: [{
                    required: true,
                    message: this.$i18n.t("message.notNull", [
                        this.$i18n.t("columns.bottleName")
                    ])
                }],
                Number: [{
                    required: true,
                    message: this.$i18n.t("message.notNull", [
                        this.$i18n.t("columns.number")
                    ])
                },{
                    validator: (rule, value, callback) => {
                        if (value > 0 && value <= 50 ) {
                            callback();
                        } else {
                            callback(
                                new Error(
                                    this.$i18n.t("message.notMore", [
                                        this.$i18n.t("columns.number"),
                                        50
                                    ])
                                )
                            );
                        }
                    }
                }],
                Price: [{
                    required: true,
                    message: this.$i18n.t("message.notNull", [
                        this.$i18n.t("columns.price")
                    ])
                }, {
                    validator: (rule, value, callback) => {
                        if (utils.isPositive(value)) {
                            callback();
                        } else {
                            callback(
                                new Error(
                                    this.$i18n.t("message.overZero", [
                                        this.$i18n.t("columns.price")
                                    ])
                                )
                            );
                        }
                    }
                }],
                ProjectsId: [{
                    required: true,
                    message: this.$i18n.t("message.notNull", [
                        this.$i18n.t("columns.projectCode")
                    ])
                }],
                InitialQuantity: [{
                    validator: validatorInitialQuantity,
                    trigger: "change"
                }]
            }
        };
    },
    methods: {
        //加载物料类型
        async fetchMaterielType() {
            const resp = await api.cims.fetchMaterielType();
                        
            if (resp.code == process.env.VUE_APP_code) {
                this.materielType = resp.response;
            }
        },
        //加载包装单位
        async fetchDicItem(dic) {
            const resp = await api.cims.fetchDicItem(dic);
            if (resp.code == process.env.VUE_APP_code) {
                this[dic] = resp.rows;        
            }
        },
        //加载项目
        async loadProject() {
            let resp = await api.cims.fetchProjects();
            if (resp.code == process.env.VUE_APP_code) {
                this.projectList = resp.response;
            }
        },
        //校验cas号
        async validCas(rule, value, callback) {
            if (this.form.CategoryCode === this.CR) {
                if (this.form.CASNumber) {
                    var reg = /^[0-9]{2,7}-[0-9]{2}-[0-9]{1}$/;
                    if (!this.isSubmiting) {
                        if (reg.test(this.form.CASNumber)) {
                            const resp = await api.cims.isCasExist(this.form.CASNumber);
                            if (resp.code == process.env.VUE_APP_eln_code) {
                                const resp1 = await api.cims.findCompoundSourceByCas(
                                    this.form.CASNumber
                                );
                                if (resp1.code == process.env.VUE_APP_code) {
                                    Object.assign(this.form, resp1.response);
                                } else {
                                    this.$Message.warning(this.$i18n.t("message.noMateriel"));
                                    this.form.ChinName = "";
                                    this.form.ChemName = "";
                                }
                            } else {
                                this.$Message.success(this.$i18n.t("message.materielIsExisted"));
                                Object.assign(this.form, resp.response);
                            }
                        } else {
                            this.form.CASNumber = '';
                            this.$Message.warning(this.$i18n.t("message.casIsError"));
                        }
                    } else {
                        new callback();
                    }
                } else {
                    new callback();
                }
            } else {
                new callback();
            }
        },
        //物料类型切换
        onCategoryCodeChange() {
            this.form.CASNumber = '';
        },
        //获取申购单详情
        async getApplicant() {
            const resp = await api.cims.getApplicant(this.id);
            if (resp.code == process.env.VUE_APP_code) {
                resp.response.InitialQuantity = resp.response.InitialQuantity || '';
                Object.assign(this.form, resp.response);
            } else {
                this.$Message.error(resp.message);
            }
        },
        //获取试剂详情
        async getReagent() {
            const resp = await api.cims.getReagent(this.id);
            if (resp.code == process.env.VUE_APP_code) {
                resp.response.BottleInfo.Number = 1;
                resp.response.BottleInfo.Price =
                    resp.response.BottleInfo.UnitPrice || 0;
                resp.response.BottleInfo.ChemName = resp.response.MaterielInfo.ChemName;
                resp.response.BottleInfo.InitialQuantity = resp.response.BottleInfo.InitialQuantity || '';
                Object.assign(this.form, resp.response.BottleInfo);
            } else {
                this.$Message.error(resp.message);
            }
        },
        //获取物料详情
        async getMateriel() {
            const resp = await api.cims.getMateriel(this.id);
            if (resp.code == process.env.VUE_APP_code) {
                resp.response.MaterielEntity.InitialQuantity = resp.response.MaterielEntity.InitialQuantity || '';
                Object.assign(this.form, resp.response.MaterielEntity);
            } else {
                this.$Message.error(resp.message);
            }
        },
        //保存草稿或直接提交--新建
        async save(IsCommit = false) {
            this.isSubmiting = true;
            let valid = await this.$refs.form.validate();

            if (valid) {
                if (IsCommit) {
                    this.loading1 = true;
                } else {
                    this.loading = true;
                }
                this.form.IsCommit = IsCommit;
                const resp = await api.cims.submitApplicant(this.form);
                if (resp.code == process.env.VUE_APP_code) {
                    this.$Message.success(resp.message);
                    await utils.sleep(1500);
                    window.location.href = `${this.appPrefix}/applicant?name=${IsCommit ? 3 : 2}`;
                } else {
                    this.$Message.error(resp.message);
                    if (IsCommit) {
                        this.loading1 = false;
                    } else {
                        this.loading = false;
                    }
                }
            } else {
                this.isSubmiting = false;
            }
        },
        //保存草稿--编辑
        async saveOfEdit() {
            this.isSubmiting = true;
            let valid = await this.$refs.form.validate();
            if (valid) {
                this.loading = true;
                const resp = await api.cims.editApplicant(this.id, this.form);
                if (resp.code == process.env.VUE_APP_code) {
                    this.$Message.success(this.$i18n.t("message.applicantSuccess"));
                    await utils.sleep(1500);
                    window.location.href = this.appPrefix + "/applicant?name=2";
                } else {
                    this.$Message.error(resp.message);
                    this.loading = false;
                }
            } else {
                this.isSubmiting = false;
            }
        },
        //保存并提交--编辑
        async saveAndsubmit() {
            this.isSubmiting = true;
            let valid = await this.$refs.form.validate();
            if (valid) {
                this.loading1 = true;
                const resp = await api.cims.editApplicant(this.id, this.form);

                if (resp.code == process.env.VUE_APP_code) {
                    const resp1 = await api.cims.batchSubmitApplicant([{
                        purchaseId: this.form.ID,
                        number: this.form.Number
                    }]);
                    if (resp1.code == process.env.VUE_APP_code) {
                        this.$Message.success(resp1.message);
                        await utils.sleep(1500);
                        window.location.href = this.appPrefix + "/applicant?name=3";
                    } else {
                        this.$Message.error(resp1.message);
                        this.loading1 = false;
                    }
                }
            } else {
                this.isSubmiting = false;
            }
        }
    },
    created() {
        const deptId = utils.getDeptId();
        if (deptId) {
            this.form.DepartmentId = deptId;
        } else {
            this.$Message.warning(this.$i18n.t("form.noDept"));
        }
    },
    mounted() {
        this.id = utils.getParams("id");
        this.type = utils.getParams("type") || 0;
        this.fetchMaterielType();
        this.loadProject();
        this.fetchDicItem("unit");
        this.fetchDicItem("packingUnit");
        //type: 0-完全新建； 1-物料； 2-领用单； 3-库存；4-申购单加入； 5-申购单编辑
        if (this.id) {
            switch (this.type) {
                case "1":
                    this.getMateriel();
                    break;
                case "2":
                    this.getReagent();
                    break;
                case "3":
                    this.getReagent();
                    break;
                case "4":
                    this.id = this.id * 1;
                    this.getApplicant();
                    break;
                case "5":
                    this.id = this.id * 1;
                    this.getApplicant();
                    break;
                default:
                    break;
            }
        }
    },
    computed: {
        totalPrice(newValue, oldValue) {
            this.form.TotalPrice = this.form.Number * this.form.Price;
            return this.form.Number * this.form.Price || "";
        }
    }
};
</script>

<style lang="less" scoped>
.content {
    .form {
        .tableHeader {
            font-size: 22px;
            color: #292929;
            text-align: center;
            margin: 24px 0;
        }

        .applicant-table {
            border: 1px dashed #dcdcdc;
            padding: 30px 60px 0;

            .title {
                font-size: 18px;
                color: #282828;
                border-bottom: 1px dashed #dbdbdb;
                padding-bottom: 6px;
                margin: 16px 0 4px;

                span {
                    display: inline-block;
                    width: 4px;
                    height: 17px;
                    background-color: #1388ff;
                    position: relative;
                    top: 2px;
                    margin-right: 4px;
                }
            }

            .ivu-form-item {
                margin: 12px 0;

                &.rela-top-2 {
                    /deep/ .ivu-form-item-content {
                        position: relative;
                        top: 1px;
                    }
                }

                .label {
                    text-align: right;
                    vertical-align: middle;
                    float: left;
                    color: #515a6e;
                    line-height: 1;
                    padding: 10px 12px 10px 0;
                    box-sizing: border-box;
                    font-size: 14px;
                }

                /deep/ .ivu-form-item-content {
                    font-size: 14px;
                    color: #515a6e;
                }

                &.ivu-form-item-required.hideRequired {
                    /deep/ .ivu-form-item-label:before {
                        display: none;
                    }
                }

                /deep/ .ivu-form-item-label {
                    font-size: 15px;
                }
            }

            .table-action {
                margin: 20px -60px 0;
                padding: 20px 0;
                background-color: #f6f6f6;
                text-align: center;

                button {
                    width: 200px;

                    &:first-child {
                        margin-right: 30px;
                    }
                }
            }
        }
    }
}
</style>
