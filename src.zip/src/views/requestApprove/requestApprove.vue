<template>
<ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
        <div class="page-info">
            <div class="chinName">领用审批</div>
            <div class="chemName">Request Approval</div>
        </div>

        <Tabs v-model="name" class="ilab-tabs" :animated="false" @on-click="onTabsClick">
            <TabPane :label="$t('tab.approving')" name="1">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.requestCode')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.requestDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="approveColumns" :data="data" :total="total" :noDataText="noDataText" ref="table1" @on-select="getSelectCount" @on-select-all="getSelectCount" @on-select-all-cancel="getSelectCount" @on-select-cancel="getSelectCount">
                    <template slot-scope="{ row }" slot="RequestCode">
                        <a :href="appPrefix + '/request/detail?id=' + row.RequestCode">{{row.RequestCode}}</a>
                        <span v-html="isExpiry(row.ExpiryDate)"></span>
                    </template>
                    <template slot-scope="{ row }" slot="Action1">
                        <div style="white-space: nowrap;">
                            <Button size="small" :to="appPrefix + '/requestApprove/detail?id=' + row.RequestCode">{{$t('btn.approveDetail')}}</Button>
                        </div>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
                <Row class="batch-operation" v-if="total > 0">
                    <Col span="12">
                    <Button class="select-all-btn" @click="selectAll">{{selectCount === data.length ? $t('btn.cancelAll') : $t('btn.selectAll')}}</Button>
                    </Col>
                    <Col span="12">
                    <Button size="large" type="primary" :disabled="selectCount === 0" @click="yes" :loading="loading1">
                        <span v-if="loading1">{{$t('btn.doing')}}...</span>
                        <span v-else>{{$t('btn.batchYes')}}</span>
                    </Button>
                    <Button size="large" type="error" :disabled="selectCount === 0" @click="openModal">{{$t('btn.batchNo')}}</Button>
                    </Col>
                </Row>
            </TabPane>
            <TabPane :label="$t('tab.approved')" name="2">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.requestCode')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.requestDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="approveColumns1" :data="data" :total="total" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="RequestCode">
                        <a :href="appPrefix + '/request/detail?id=' + row.RequestCode">{{row.RequestCode}}</a>
                    </template>
                    <template slot-scope="{ row }" slot="Action1">
                        <div style="white-space: nowrap;">
                            <Button size="small" :to="appPrefix + '/requestApprove/detail?id=' + row.RequestCode">{{$t('btn.approveDetail')}}</Button>
                        </div>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
            </TabPane>
            <TabPane :label="$t('tab.rejected')" name="3">
                <Row class="search-conditions" type="flex">
                    <Col class="flex-1">
                    {{$t('columns.requestCode')}}：
                    <Input v-model="condition1"></Input>
                    {{$t('columns.requestDate')}}：
                    <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
                    {{$t('columns.categoryName')}}：
                    <Select v-model="condition3" style="width:200px" :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])" transfer clearable>
                        <Option v-for="item in materielType" :value="item.CategoryCode" :key="item.CategoryCode">{{item.CategoryName}}</Option>
                    </Select>
                    </Col>
                    <Col>
                    <Button size="large" type="primary" icon="ios-search" @click="fetchData(1)">{{$t('btn.search')}}</Button>
                    </Col>
                </Row>
                <Table :columns="approveColumns1" :data="data" :total="total" :noDataText="noDataText">
                    <template slot-scope="{ row }" slot="RequestCode">
                        <a :href="appPrefix + '/request/detail?id=' + row.RequestCode">{{row.RequestCode}}</a>
                    </template>
                    <template slot-scope="{ row }" slot="Action1">
                        <div style="white-space: nowrap;">
                            <Button size="small" :to="appPrefix + '/requestApprove/detail?id=' + row.RequestCode">{{$t('btn.approveDetail')}}</Button>
                        </div>
                    </template>
                </Table>
                <Page :total="total" show-total :page-size="10" @on-change="fetchData" v-show="total > 0" :current="pageIndex" />
            </TabPane>
        </Tabs>

        <Modal :title="$t('btn.batchNo')" v-model="modal" @on-ok="ok" :loading="loading">
            <Form ref="form" :model="form" :rules="rules" :label-width="80">
                <FormItem :label="$t('columns.approveReason')" prop="remarks">
                    <Input type="textarea" :placeholder="$t('message.placeholder', [$t('columns.approveReason')])" v-model="form.remarks" :autosize="{minRows: 3,maxRows: 5}"></Input>
                </FormItem>
            </Form>
        </Modal>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from "@/components/layout.vue";
import api from "@/api";
import columns from "@/utils/columns";
import utils from "@/utils/utils";

export default {
    name: "requestApprove",
    components: {
        ilabLayout
    },
    data() {
        return {
            iminentExpirationDay: "",
            noDataText: this.$i18n.t("columns.noDataText"),
            userId: utils.getUserInfo(),
            total: 0,
            materielType: [],
            stockList: [],
            scrapList: [],
            modal: false,
            form: {
                remarks: ""
            },
            rules: {
                remarks: [{
                        required: true,
                        message: this.$i18n.t("message.notNull", [
                            this.$i18n.t("columns.approveReason")
                        ]),
                        trigger: "change"
                    },
                    {
                        validator: (rule, value, callback) => {
                            if (value.length <= 100) {
                                callback();
                            } else {
                                callback(new Error(this.$i18n.t("message.notOver", [this.$i18n.t("columns.approveReason"), 100])));
                            }
                        },
                        trigger: "blur"
                    }
                ]
            },
            appPrefix: process.env.VUE_APP_prefix,
            name: "1",
            breadcrumbs: [{
                txt: this.$i18n.t("nav.requestApprove")
            }],
            approveColumns: [
                columns.Select,
                Object.assign(columns.RequestCode(this.$i18n.t('columns.requestCode')), {
                    width: 170
                }),
                columns.MaterielNumber(this.$i18n.t('page.materielNumber')),
                columns.CategoryName(this.$i18n.t('columns.categoryName')),
                columns.BottleName(this.$i18n.t('columns.bottleName')),
                columns.CASNumber(this.$i18n.t('columns.CASNumber')),
                columns.Purity(this.$i18n.t('columns.purity')),
                columns.RequestQuantity(this.$i18n.t('columns.requestQuantity')),
                columns.EstimatedAmount(this.$i18n.t('columns.estimatedAmount')),
                columns.Requester(this.$i18n.t('columns.requester')),
                columns.RequestDate(this.$i18n.t('columns.requestDate')),
                columns.ProjectCode(this.$i18n.t('columns.projectCode')),
                columns.Action1(this.$i18n.t('columns.operation'))
            ],
            approveColumns1: [
                columns.RequestCode(this.$i18n.t('columns.requestCode')),
                columns.MaterielNumber(this.$i18n.t('page.materielNumber')),
                columns.CategoryName(this.$i18n.t('columns.categoryName')),
                columns.BottleName(this.$i18n.t('columns.bottleName')),
                columns.CASNumber(this.$i18n.t('columns.CASNumber')),
                columns.Purity(this.$i18n.t('columns.purity')),
                columns.RequestQuantity(this.$i18n.t('columns.requestQuantity')),
                columns.EstimatedAmount(this.$i18n.t('columns.estimatedAmount')),
                columns.Requester(this.$i18n.t('columns.requester')),
                columns.RequestDate(this.$i18n.t('columns.requestDate')),
                columns.ProjectCode(this.$i18n.t('columns.projectCode')),
                columns.Action1(this.$i18n.t('columns.operation'))
            ],
            data: [],
            condition1: "",
            condition2: "",
            condition3: "",
            curRows: "",
            pageIndex: 1,
            selectCount: 0,
            loading: true,
            loading1: false
        };
    },
    created() {
        this.name = utils.getParams("name") || "1";
    },
    methods: {
        //获取物料近效期提醒时间
        async getIminentExpirationDay() {
            const resp = await api.cims.getOrganizationConfig("iminentExpirationDay");
            if (resp.code == process.env.VUE_APP_code) {
                this.iminentExpirationDay = resp.response;
            } else {
                this.$Message.error(resp.message);
            }
        },
        //判断近效期
        isExpiry(date) {
            const expireDateState = [this.$i18n.t("page.overExpiryTime"), this.$i18n.t("page.withExpiryTime"), this.$i18n.t("page.inExpiryTime")];
            return utils.isExpiry(this.iminentExpirationDay, date, expireDateState);
        },
        //打开模态框
        openModal() {
            this.$refs.form.resetFields();
            this.modal = true;
        },
        //关闭loading
        resetLoading() {
            this.loading = false;
            setTimeout(() => {
                this.loading = true;
            }, 0);
        },
        //tab切换
        onTabsClick(tabName) {
            this.condition1 = "";
            this.condition2 = "";
            this.condition3 = "";
            this.data = [];
            this.total = 0;
            this.selectCount = 0;
            this.fetchData();
        },
        //加载物料类型
        async fetchMaterielType() {
            const resp = await api.cims.fetchMaterielType();
            if (resp.code == process.env.VUE_APP_code) {
                this.materielType = resp.response;
            }
        },
        //批量拒绝
        async ok() {
            const valid = await this.$refs.form.validate();
            if (valid) {
                const selection = this.$refs.table1.getSelection();
                const resp = await api.cims.requestApproveNo(
                    selection.map(item => {
                        return {
                            approveResult: 0,
                            approveUser: this.userId,
                            approveUsers: item.ApproveUsers,
                            flowNodeId: item.FlowNodeId,
                            orderApproveStatus: item.ApproveState,
                            orderId: item.ID,
                            orderNumber: item.RequestCode,
                            remarks: this.form.remarks
                        };
                    })
                );
                if (resp.code == process.env.VUE_APP_code) {
                    this.$Message.success(resp.message);
                    this.modal = false;
                    this.fetchData();
                } else {
                    this.$Message.error(resp.message);
                }
            } else {
                this.resetLoading();
            }
        },
        //批量同意
        async yes() {
            this.loading1 = true;
            const selection = this.$refs.table1.getSelection();
            const resp = await api.cims.requestApproveYes(
                selection.map(item => {
                    return {
                        approveResult: 0,
                        approveUser: this.userId,
                        approveUsers: item.ApproveUsers,
                        flowNodeId: item.FlowNodeId,
                        orderApproveStatus: item.ApproveState,
                        orderId: item.ID,
                        orderNumber: item.RequestCode,
                        remarks: ""
                    };
                })
            );
            if (resp.code == process.env.VUE_APP_code) {
                this.$Message.success(resp.message);
                this.fetchData();
            } else {
                this.$Message.error(resp.message);
            }
            this.loading1 = false;
        },
        //获取表格数据
        async fetchData(pageIndex = 1) {
            this.noDataText = this.$i18n.t("columns.noDataText");

            let resp = await api.cims[`fetchRequestApproveTab${this.name}`]({
                pageIndex: pageIndex,
                requestCode: this.condition1,
                requestStartDate: this.condition2.length ? this.condition2[0] : "",
                requestEndDate: this.condition2.length ? this.condition2[1] : "",
                categoryCode: this.condition3
            });
            if (resp.code != process.env.VUE_APP_code) {
                this.noDataText = this.$i18n.t("columns.noDataText2");
            }

            this.data = resp.rows;
            this.total = resp.total;
            this.pageIndex = pageIndex;
            this.selectCount = 0;
        },
        //全选
        selectAll() {
            const isSelectAll = this.selectCount === this.data.length;
            if (isSelectAll) {
                this.$refs.table1.selectAll(false);
                this.selectCount = 0;
            } else {
                this.$refs.table1.selectAll(true);
                this.selectCount = this.data.length;
            }
        },
        getSelectCount() {
            this.selectCount = this.$refs.table1.getSelection().length;
        }
    },
    async mounted() {
        await this.getIminentExpirationDay();
        await this.fetchData();
        await this.fetchMaterielType();
    }
};
</script>
