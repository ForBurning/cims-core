<template>
<ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
        <div class="page-info">
            <div class="chinName">审批详情</div>
            <div class="chemName">Approval Details</div>
        </div>
        <div class="panel-title"> <span style="margin-left: 30px;">{{$t('columns.requestCode')}}：{{approvalDetail.RequestCode}} </span>
            <span class="toggle" @click="toggleUpDown(item)">
                <Icon :type="isExpend ? 'ios-arrow-down' : 'ios-arrow-up'" />
            </span>
            <div class="right-align" v-if="hasApprovePermission">
                <Button @click="approvalEvt(0)" type="primary" :loading="loading1">
                    <span v-if="loading1">{{$t('btn.doing')}}...</span>
                    <span v-else>{{$t('btn.yes')}}</span>
                </Button>
                <Button @click="openRefuseEvt">{{$t('btn.no')}}</button></div>
            <div class="b-panel" v-show="isExpend">
                <Row class="request-detail" type="flex">
                    <Col span="4" class="tr">{{$t('columns.bottleName')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.BottleName}}</Col>
                    <Col span="4" class="tr">{{$t('columns.categoryName')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.CategoryName}}</Col>
                    <Col span="4" class="tr">{{$t('page.materielNumber')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.MaterielNumber}}</Col>
                </Row>
                <Row class="request-detail" type="flex">
                    <Col span="4" class="tr">{{$t('form.chemName')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.ChemName}}</Col>
                    <Col span="4" class="tr">{{$t('columns.CASNumber')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.CASNumber}}</Col>
                    <Col span="4" class="tr">{{$t('columns.bottleType')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.BottleType}}</Col>
                </Row>
                <Row class="request-detail" type="flex">
                    <Col span="4" class="tr">{{$t('columns.bOrp')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.Purity}}</Col>
                    <Col span="4" class="tr">{{$t('columns.estimatedAmount')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.EstimatedAmount}}{{approvalDetail.RequestUnit}}</Col>
                    <Col span="4" class="tr">{{$t('columns.catalogNumber')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.CatalogNumber}}</Col>
                </Row>
                <Row class="request-detail" type="flex">
                    <Col span="4" class="tr">{{$t('columns.requester')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.Requester}}</Col>
                    <Col span="4" class="tr">{{$t('columns.requestQuantity')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.RequestQuantity}}</Col>
                    <Col span="4" class="tr">{{$t('columns.requestDate')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.RequestDate}}</Col>
                </Row>
                <Row class="request-detail" type="flex">
                    <Col span="4" class="tr">{{$t('columns.lab')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.Lab}}</Col>
                    <Col span="4" class="tr">{{$t('columns.projectCode')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.ProjectCode}}</Col>
                    <Col span="4" class="tr">{{$t('page.supplier')}}：</Col>
                    <Col span="4" class="tl">{{approvalDetail.Supplier}}</Col>
                </Row>
            </div>
        </div>

        <div class="middle relative">
            <div class="line"></div>
            <img src="@/assets/img/done.png" class="done" /><span class="done_txt active">{{$t('btn.submitRequest')}}</span>
            <img src="@/assets/img/dsp.png" class="approval" v-if="approvalDetail.ApproveStateType === 0" /><span class="approval_txt active" v-if="approvalDetail.ApproveStateType === 0">{{$t('tab.approving')}}</span>
            <img src="@/assets/img/approval.png" class="approval" v-if="approvalDetail.ApproveStateType !== 0" /><span class="approval_txt active" v-if="approvalDetail.ApproveStateType !==0">{{$t('tab.approvTo')}}</span>
            <img src="@/assets/img/finish.png" class="finish" v-if="approvalDetail.ApproveStateType !== -1 && approvalDetail.ApproveStateType !== 19" v-cloak />
            <img src="@/assets/img/reject.png" class="finish" v-if="approvalDetail.ApproveStateType === -1" v-cloak />
            <img src="@/assets/img/approvalSuccess.png" class="finish" v-if="approvalDetail.ApproveStateType === 19" v-cloak />
            <span class="finish_txt active" v-if="approvalDetail.ApproveStateType === 19" v-cloak>{{$t('page.approveYes')}}</span>
            <span class="finish_txt active fail" v-if="approvalDetail.ApproveStateType === -1" v-cloak>{{$t('page.approveNo')}}</span>
        </div>

        <Table :columns="columns" :data="data">
            <template slot-scope="{ row }" slot="icon">
                <Icon type="md-checkmark" v-if="row.ApproveTime && row.ApproveState !== -1" />
                <Icon type="md-close" v-if="row.ApproveTime && row.ApproveState === -1" />
            </template>
        </Table>

        <Modal :title="$t('columns.approveReason')" v-model="remarksModal" @on-ok="approvalEvt(1)" :loading="loading">
            <Input type="textarea" :placeholder="$t('message.placeholder', [$t('columns.approveReason')])" v-model="remarks" :autosize="{minRows: 3,maxRows: 5}"></Input>
        </Modal>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from '@/components/layout.vue'
import api from '@/api'
import utils from '@/utils/utils'
import columns from "@/utils/columns";

export default {
    name: "requestApprove-detail",
    components: {
        ilabLayout,
    },
    data() {
        return {
            appPrefix: process.env.VUE_APP_prefix,
            userId: utils.getUserInfo(),
            breadcrumbs: [{
                    txt: this.$i18n.t("nav.requestApprove"),
                    href: '/requestApprove'
                },
                {
                    txt: this.$i18n.t("btn.approveDetail"),
                }
            ],
            bottlesInventory: [],
            approvalDetail: {},
            hasApprovePermission: false,
            columnsInfo: false,
            reagentsInfo: false,
            reagentsStock: false,
            history: {},
            active: true,
            columns: [{
                    slot: 'icon',
                    title: ' '
                },
                columns.ApproveUser(this.$i18n.t("columns.approveUser")),
                columns.ApproveStateName(this.$i18n.t("columns.approveState")),
                columns.ApproveTime(this.$i18n.t("columns.approveTime"), 'auto'),
                {
                    title: this.$i18n.t("form.approvalIdea"),
                    key: "ApproveReason",
                    render: (h, params) => {
                        return h('div', params.row.ApproveState ? (params.row.ApproveState === -1 ? params.row.ApproveReason : this.$i18n.t("btn.yes")) : '')
                    }
                }
            ],
            data: [],
            remarks: '',
            remarksModal: false,
            loading: true,
            loading1: false,
            isExpend: false,
        };
    },
    methods: {
        //收起展开
        toggleUpDown(item) {
            this.isExpend = !this.isExpend;
        },
        async approvalEvt(approveResult) {
            let approveList = [{
                approveResult: approveResult,
                approveUser: this.userId,
                approveUsers: this.approvalDetail.ApproveUsers,
                flowNodeId: this.approvalDetail.FlowNodeId,
                orderApproveStatus: this.approvalDetail.ApproveState,
                orderId: this.approvalDetail.RequestId,
                orderNumber: this.approvalDetail.RequestCode,
                remarks: approveResult === 0 ? '' : this.remarks,
            }]

            let resp = {};

            if (approveResult === 0) {
                this.loading1 = true;
                resp = await api.cims.requestApproveYes(approveList)
                this.loading1 = false;
            } else {
                if (this.remarks) {
                    const maxLength = 50;
                    if (this.remarks.length <= maxLength) {
                        resp = await api.cims.requestApproveNo(approveList);
                    } else {
                        this.$Message.warning(this.$i18n.t("message.notOver", [
                            this.$i18n.t("columns.approveReason"),
                            maxLength
                        ]));
                        this.loading = false;
                        setTimeout(() => {
                            this.loading = true
                        }, 0)
                        return false;
                    }
                } else {
                    this.$Message.warning(this.$i18n.t("message.placeholder", [this.$i18n.t("columns.approveReason")]));
                    this.loading = false;
                    setTimeout(() => {
                        this.loading = true
                    }, 0)
                    return false;
                }
            }

            if (resp.code == process.env.VUE_APP_code) {
                this.$Message.success(resp.message);
                window.location.href = process.env.VUE_APP_prefix + '/requestApprove?name=' + (approveResult === 0 ? 2 : 3);
            } else {
                this.$Message.error(resp.message)
            }
        },
        openRefuseEvt() {
            this.loading = true;
            this.remarks = '';
            this.remarksModal = true;
        }
    },
    async mounted() {
        const id = utils.getParams('id');
        if (id) {
            let resp = await api.cims.getRequestApproveDetail(id);

            if (resp.code == process.env.VUE_APP_code) {
                if (resp.response.ApproveUsers) {
                    const approveUsers = resp.response.ApproveUsers.split(",");
                    const roles = utils.getCimsInfo().RoleCodes;
                    //当前用户有申领审批角色且是审批人之一（有可能审批过程中， 用户审批角色被移除角色）
                    this.hasApprovePermission = approveUsers.includes(this.userId.toString()) && roles.ORDERAPPROVE;
                }
                this.approvalDetail = resp.response;
                this.data = resp.response.ApprovalHistory;
            } else {
                window.location.href = this.appPrefix + "/404";
            }
        }
    }
}
</script>

<style lang="less" scoped>
.content {
    .panel-title {
        background-color: #f8f8f8;
        color: #000;
        font-size: 15px;
        border: 1px #ddd solid;
        padding: 20px 0;
    }

    .right-align {
        float: right;
        margin-top: -3px;

        button {
            margin-right: 14px;
        }
    }

    .toggle {
        display: inline-block;
        width: 24px;
        height: 24px;
        line-height: 21px;
        border-radius: 100%;
        border: 1px solid #e0e0e0;
        text-align: center;
        background-color: #ffffff;
        cursor: pointer;
    }

    .ivu-icon-md-checkmark {
        font-size: 22px;
        color: #3395ec;
        font-weight: bold;
    }

    .ivu-icon-md-close {
        font-size: 22px;
        color: #ff6100;
        font-weight: bold;
    }

    .tl {
        text-align: left;
    }

    .tr {
        text-align: right;
    }

    .b-panel {
        padding: 15px 0;
        margin-top: 15px;
        background-color: #ffffff;
        margin-bottom: -20px;

        .ivu-row-flex {
            margin: 8px 0;
            text-align: center;
            font-size: 14px;
            word-break: break-all;
        }
    }

    .middle {
        height: 170px;
        color: #000;
        font-weight: bold;

        .line {
            position: absolute;
            background-color: #ddd;
            left: 44px;
            right: 29px;
            top: 72px;
            height: 1px;
        }

        .done {
            position: absolute;
            left: 225px;
            top: 54px;
        }

        .approval {
            position: absolute;
            left: 572px;
            top: 41px;
        }

        .finish {
            position: absolute;
            left: 940px;
            top: 53px;
        }

        .done_txt {
            position: absolute;
            left: 212px;
            top: 110px;
        }

        .approval_txt {
            position: absolute;
            left: 581px;
            top: 110px;
        }

        .finish_txt {
            position: absolute;
            left: 932px;
            top: 110px;
        }

        span {
            font-size: 15px;

            &.active {
                color: #3395ec;

                &.fail {
                    color: #FF6000;
                }
            }
        }

        &:after {
            display: block;
            content: "";
            width: 12px;
            height: 12px;
            border-radius: 100%;
            border: 1px solid #ddd;
            position: absolute;
            left: 1170px;
            top: 66px;
        }

        &:before {
            display: block;
            content: "";
            width: 12px;
            height: 12px;
            border-radius: 100%;
            border: 1px solid #ddd;
            position: absolute;
            left: 33px;
            top: 66px;
        }
    }

    .relative {
        position: relative;
    }
}
</style>
