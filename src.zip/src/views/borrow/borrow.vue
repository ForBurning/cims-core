<template>
  <ilab-layout :breadcrumbs="breadcrumbs" ref="layout">
    <div slot="content" class="content">
      <div class="page-info">
        <div class="chinName">借用信息</div>
        <div class="chemName">Borrow Information</div>
      </div>

      <Tabs v-model="name" class="ilab-tabs" :animated="false">
        <TabPane :label="$t('tab.myBorrow')" name="1">
          <Row class="title">
            <Col span="4">{{$t('columns.user')}}</Col>
            <Col span="6">{{$t('columns.bottleName')}}</Col>
            <Col span="2">{{$t('columns.demand')}}</Col>
            <Col span="2">{{$t('columns.purity')}}</Col>
            <Col span="4">{{$t('columns.postTime')}}</Col>
            <Col span="2">{{$t('columns.state')}}</Col>
            <Col span="2">{{$t('columns.detail')}}</Col>
            <Col span="2">{{$t('columns.operation')}}</Col>
          </Row>
          <div v-for="item in borrowList" :key="item.ID">
            <Row class="info">
              <Col span="4">
                <span class="txt-user">{{item.CreateUser.substring(0,1)}}</span>
                <span class="bold">{{item.CreateUser}}</span>
              </Col>
              <Col span="6">
                <span class="bold">{{item.ChinName}}</span>
              </Col>
              <Col span="2">{{item.BorrowQuantity}} {{item.Unit}}</Col>
              <Col span="2">{{item.Purity}}</Col>
              <Col span="4">{{item.CreateTime}}</Col>
              <Col span="2">
                <i
                  class="borrow-state"
                  :class="{'state1': item.ResultStatus === 1, 'state3': item.ResultStatus !== 1}"
                ></i>
              </Col>
              <Col span="2">
                <i
                  class="ivu-icon fs26"
                  @click="view(item)"
                  :class="{'ivu-icon-ios-arrow-dropdown': !item.active, 'ivu-icon-ios-arrow-dropup': item.active}"
                ></i>
              </Col>
              <Col span="2">
                <Button
                  type="primary"
                  v-if="item.ResultStatus !== 1"
                  :class="{'disabled': !item.Lender}"
                  @click="confirmEvt(item.ID)"
                >{{$t('btn.confirm')}}</Button>
              </Col>
            </Row>
            <Row class="borrow-detail transition" v-bind:class="{'active': item.active}">
              <Col span="12">
                <div
                  class="borrow-1"
                >[{{item.CreateTime}}] {{item.CreateUser}} 【{{$t('page.lend')}}】{{item.BottleName}} ({{item.BorrowQuantity}}{{item.Unit}} {{item.Comments}})</div>
                <div
                  class="borrow-3"
                  v-if="item.ResultStatus === 1"
                >[{{item.ResultTime}}] {{item.CreateUser}} {{$t('btn.confirmReceive')}} {{item.BottleName}} ({{item.BorrowQuantity}}{{item.Unit}})</div>
              </Col>
              <Col span="12">
                <div class="borrow-2" v-if="item.Lender">[{{item.LendTime}}] {{item.Lender}} {{$t('btn.confirmLend')}}</div>
              </Col>
            </Row>
          </div>
          <Page
            :total="total1"
            @on-change="fetchMyBorrowData"
            :page-size="pageSize"
            v-show="total1 > 0"
          ></Page>
        </TabPane>
        <TabPane :label="$t('tab.myLend')" name="2">
          <Row class="title">
            <Col span="6">{{$t('columns.lendTo')}}</Col>
            <Col span="6">{{$t('columns.lendMateriel')}}</Col>
            <Col span="4">{{$t('columns.LendCount')}}</Col>
            <Col span="4">{{$t('columns.purity')}}</Col>
            <Col span="4">{{$t('columns.lentTime')}}</Col>
          </Row>
          <Row class="info" v-for="item in lendList" :key="item.ID">
            <Col span="6">
              <span class="txt-user">{{item.firstName}}</span>
              <span class="bold">{{item.CreateUser}}</span>
            </Col>
            <Col span="6">
              <span class="bold">{{item.ChinName}}</span>
            </Col>
            <Col span="4">{{item.LendQuantity}} {{item.Unit}}</Col>
            <Col span="4">{{item.Purity}}</Col>
            <Col span="4">{{item.LendTime}}</Col>
          </Row>
          <Page
            :total="total2"
            @on-change="fetchMyLendData"
            :page-size="pageSize"
            v-show="total2 > 0"
          ></Page>
        </TabPane>
      </Tabs>
    </div>
  </ilab-layout>
</template>
<script>
import ilabLayout from "@/components/layout.vue";
import utils from "@/utils/utils";
import api from "@/api";

export default {
  name: "borrow-page",
  components: {
    ilabLayout
  },
  data() {
    return {
      appPrefix: process.env.VUE_APP_prefix,
      breadcrumbs: [
        {
          txt: this.$i18n.t("nav.borrow")
        }
      ],
      id: "",
      name: "1",
      lendList: [],
      borrowList: [],
      total1: 0,
      total2: 0,
      pageSize: process.env.VUE_APP_page_size * 1
    };
  },
  created() {
    this.id = utils.getParams("id")*1;
    this.name = utils.getParams("tab") || "1";
  },
  methods: {
    view(item) {
      item.active = !item.active;
    },
    async fetchMyBorrowData(pageIndex = 1) {
      const resp = await api.cims.fetchMyBorrowData({
        pageIndex: pageIndex,
        borrowId: this.id
      });
      if (resp.code == process.env.VUE_APP_code) {
        resp.rows.map(item => {
          item.active = this.name == 1 && this.id ? true : false;
          item.userPic = utils.getUcInfo().AccountInfo.Photo;
        });
        this.borrowList = resp.rows;
        this.total1 = resp.total;
      }
    },
    async fetchMyLendData(pageIndex = 1) {
      const resp = await api.cims.fetchMyLendData({
        pageIndex: pageIndex
      });
      if (resp.code == process.env.VUE_APP_code) {
        resp.rows.map(item => {
          item.firstName = item.CreateUser.substr(0, 1);
        });
        this.lendList = resp.rows;
        this.total2 = resp.total;
      }
    },
    async confirmEvt(id) {
      const resp = await api.cims.confirmBottleReceive(id);
      if (resp.code == process.env.VUE_APP_code) {
        this.$Message.success(resp.message);
        this.fetchMyBorrowData();
      } else {
        this.$Message.error(resp.message);
      }
    }
  },
  async mounted() {
    this.fetchMyBorrowData();
    this.fetchMyLendData();
  }
};
</script>

<style lang="less" scoped>
.content {
  .title {
    margin: 20px 0;
    font-size: 15px;
    color: rgba(0, 0, 0, 0.87);
    padding-left: 40px;
  }

  .info {
    height: 70px;
    line-height: 70px;
    background-color: #f8f8f8;
    position: relative;
    margin-bottom: 6px;
    font-size: 15px;
    padding-left: 40px;

    .fs26 {
      font-size: 26px;
    }

    &:before {
      content: "";
      width: 7px;
      height: 70px;
      line-height: 70px;
      background-color: #f1f1f1;
      position: absolute;
      left: 0;
      top: 0;
    }

    .txt-user {
      display: inline-block;
      width: 42px;
      height: 42px;
      border-radius: 100%;
      background-color: #65b4f7;
      color: #ffffff;
      font-size: 20px;
      text-align: center;
      line-height: 42px;
      font-weight: bold;
      margin-right: 12px;
    }

    span.bold {
      color: #000000;
      font-weight: bold;
    }
  }

  .borrow-state {
    position: relative;
    top: 8px;
    display: inline-block;
    width: 30px;
    height: 30px;
    border-radius: 100%;
    line-height: 30px;
  }

  .borrow-state.state3 {
    background-color: #ffe699;
    &:before {
      content: "";
      top: 8px;
      left: 12px;
      width: 10px;
      height: 10px;
      border-left: 2px solid #ffffff;
      border-bottom: 2px solid #ffffff;
      position: absolute;
      transition: border 0.25s, background-color 0.25s, width 0.2s 0.1s,
        height 0.2s 0.1s, top 0.2s 0.1s, left 0.2s 0.1s;
      z-index: 1;
      color: #ffffff;
    }
  }

  .borrow-state.state1 {
    background-color: #98d6ad;
    &:before {
      top: 7px;
      left: 6px;
      width: 8px;
      height: 13px;
      border-top: 2px solid transparent;
      border-left: 2px solid transparent;
      border-right: 2px solid #fff;
      border-bottom: 2px solid #fff;
      transform: rotateZ(37deg);
      transform-origin: 100% 100%;
      content: "";
      position: absolute;
      transition: border 0.25s, background-color 0.25s, width 0.2s 0.1s,
        height 0.2s 0.1s, top 0.2s 0.1s, left 0.2s 0.1s;
      z-index: 1;
    }
  }

  .borrow-detail.active {
    height: 240px;
  }

  .borrow-detail {
    height: 0;
    overflow: hidden;
    transition: 0.4s;
    -webkit-transition: 0.4s;
    margin-bottom: 6px;

    > div {
      padding-left: 30px;
      font-size: 15px;

      .borrow-1 {
        margin: 12px 0 115px;
        width: 520px;
        line-height: 36px;
        color: #010101;
        background-color: #f8f8f8;
        padding: 0 20px;
        border-radius: 8px;
        text-align: right;
      }

      .borrow-2 {
        margin-top: 88px;
        width: 520px;
        line-height: 36px;
        color: #010101;
        background-color: #f8f8f8;
        padding: 0 20px;
        border-radius: 8px;
        text-align: left;
      }

      .borrow-3 {
        width: 520px;
        line-height: 36px;
        color: #010101;
        background-color: #f8f8f8;
        padding: 0 20px;
        border-radius: 8px;
      }
    }
  }
}
</style>
