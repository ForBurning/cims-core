<template>
  <ilab-layout :breadcrumbs="breadcrumbs" ref="layout">
    <div slot="content" class="content">
      <div class="page-info">
        <div class="chinName">发布借用</div>
        <div class="chemName">Borrow Information</div>
      </div>
      <Row type="flex">
        <Col class="form">
          <Form ref="form" :model="form" :rules="rules">
            <FormItem prop="ChinName">
              <Input
                v-model="form.ChinName"
                search
                :enter-button="$t('btn.choose')"
                :placeholder="$t('form.chooseMateriel')"
                readonly
                @on-search="chooseCompound"
              />
            </FormItem>
            <FormItem prop="Purity">
              <Input v-model="form.Purity" :placeholder="$t('columns.purity')"></Input>
            </FormItem>
            <FormItem prop="BorrowQuantity">
              <Input v-model="form.BorrowQuantity" :placeholder="$t('columns.number')">
                <Select v-model="form.Unit" slot="append" style="width: 70px">
                  <Option value="g">g</Option>
                  <Option value="ml">ml</Option>
                </Select>
              </Input>
            </FormItem>
            <FormItem prop="name">
              <Select v-model="form.Deadline" :placeholder="$t('form.deadline')">
                <Option :value="3">3{{$t('time.day')}}</Option>
                <Option :value="5">5{{$t('time.day')}}</Option>
                <Option :value="7">7{{$t('time.day')}}</Option>
              </Select>
            </FormItem>
            <FormItem prop="Comments">
              <Input
                type="textarea"
                v-model="form.Comments"
                :placeholder="$t('form.note')"
                :autosize="{minRows: 2, maxRows: 6}"
              ></Input>
            </FormItem>
            <FormItem>
              <Button type="primary" long size="large" @click="post" :loading="loading">
                <span v-if="loading">{{$t('btn.posting')}}...</span>
                <span v-else>{{$t('btn.post')}}</span>
              </Button>
            </FormItem>
          </Form>
        </Col>
        <Col class="flex-1">
          <img src="../../../assets/img/borrow.png" class="steps" />
        </Col>
      </Row>

      <ilab-modal :title="$t('form.chooseMateriel')" :width="700" ref="modal" @click="choose">
        <Input
          v-model="key"
          :placeholder="$t('form.chinName')"
          @on-change="onChange(1)"
          class="compound-search-input"
        />
        <div class="ib">
          <Table
            :columns="columns"
            :data="data"
            size="small"
            ref="compounds"
            @on-selection-change="onSelectionChange"
          >
            <template slot-scope="{ row }" slot="Record">
              <div
                class="compound-view-record"
                :title="$t('btn.viewHistory')"
                @click="viewRecord(row)"
              ></div>
            </template>
          </Table>
          <Page :total="total" @on-change="onChange" :page-size="5" :current="pageIndex"></Page>
        </div>
      </ilab-modal>

      <Modal
        :title="$t('columns.requestHistory')"
        :width="900"
        v-model="record"
        :footer-hide="true"
      >
        <div class="ib">
          <Table :columns="columns1" :data="data1" size="small" height="300" width="870">
            <template
              slot-scope="{ row }"
              slot="RequestQuantity"
            >{{row.RequestQuantity + row.RequestUnit}}</template>
            <template
              slot-scope="{ row }"
              slot="EstimatedAmount"
            >{{row.EstimatedAmount + row.RequestUnit}}</template>
          </Table>
        </div>
      </Modal>
    </div>
  </ilab-layout>
</template>
<script>
import ilabLayout from "@/components/layout.vue";
import ilabModal from "@/components/modal.vue";
import utils from "@/utils/utils";
import api from "@/api";

export default {
  name: "post-page",
  components: {
    ilabLayout,
    ilabModal
  },
  data() {
    return {
      appPrefix: process.env.VUE_APP_prefix,
      breadcrumbs: [
        {
          txt: this.$i18n.t("nav.post")
        }
      ],
      form: {
        CompoundId: "",
        ChinName: "",
        Purity: "",
        BorrowQuantity: "",
        Unit: "g",
        Deadline: 3,
        Comments: ""
      },
      rules: {
        ChinName: [
          {
            required: true,
            message: this.$i18n.t("message.placeSelect", [
              this.$i18n.t("page.compound")
            ])
          }
        ],
        Purity: [
          {
            required: true,
            message: this.$i18n.t("message.placeSelect", [
              this.$i18n.t("columns.purity")
            ])
          }
        ],
        BorrowQuantity: [
          {
            required: true,
            message: this.$i18n.t("message.placeSelect", [
              this.$i18n.t("columns.number")
            ])
          }
        ],
        Comments: [
          {
            validator: (rule, value, callback) => {
              if (value) {
                if (value.length > 0 && value.length <= 50) {
                  callback();
                } else {
                  callback(
                    new Error(
                      this.$i18n.t("message.notOver", [
                        this.$i18n.t("form.note"),
                        50
                      ])
                    )
                  );
                }
              } else {
                callback();
              }
            }
          }
        ]
      },
      columns: [
        {
          type: "selection",
          width: 60
        },
        {
          key: "ChinName",
          title: this.$i18n.t("form.chinName"),
          tooltip: true
        },
        {
          key: "CASNumber",
          title: "CAS"
        },
        {
          key: "MDLNumber",
          title: this.$i18n.t("columns.mdl")
        },
        {
          slot: "Record",
          title: this.$i18n.t("columns.requestHistory"),
          align: "center"
        }
      ],
      columns1: [
        {
          key: "ChinName",
          title: this.$i18n.t("columns.bottleName")
        },
        {
          key: "CASNumber",
          title: this.$i18n.t("columns.CASNumber")
        },
        {
          slot: "RequestQuantity",
          title: this.$i18n.t("columns.requestQuantity")
        },
        {
          slot: "EstimatedAmount",
          title: this.$i18n.t("columns.estimatedAmount")
        },
        {
          key: "Requester",
          title: this.$i18n.t("columns.requester")
        },
        {
          key: "Phone",
          title: this.$i18n.t("columns.phone"),
          width: 120
        },
        {
          key: "Lab",
          title: this.$i18n.t("columns.lab")
        },
        {
          key: "RequestDate",
          title: this.$i18n.t("columns.requestDate")
        }
      ],
      data: [],
      data1: [],
      total: 0,
      key: "",
      pageIndex: 1,
      record: false,
      selection: [],
      loading: false
    };
  },
  methods: {
    //选择化合物
    chooseCompound() {
      this.data = [];
      this.key = "";
      this.$refs.modal.show();
    },
    //查看领用记录
    async viewRecord({ ID }) {
      this.record = true;
      const resp = await api.cims.fetchDeliveredRequestsData({
        compoundId: ID
      });
      if (resp.code == process.env.VUE_APP_code) {
        this.data1 = resp.response;
      } else {
        this.data1 = [];
      }
    },
    async onChange(pageIndex = 1) {
      const resp = await api.cims.fetchBorrowCanViewRequestHistoryData({
        chinName: this.key,
        pageIndex: typeof pageIndex === "number" ? pageIndex : 1,
        pageSize: 5
      });
      if (resp.code == process.env.VUE_APP_code) {
        this.data = resp.rows;
        this.total = resp.total;
      }
      this.pageIndex = pageIndex;
    },
    onSelectionChange(selection) {
      this.selection = selection;
    },
    choose() {
      if (this.selection.length === 1) {
        Object.assign(this.form, this.selection[0]);
        this.form.Comments = ''; //清空外部数据
        this.$refs.modal.hide();
      } else {
        this.$Message.warning(this.$i18n.t("message.onlyOne"));
      }
    },
    async post() {
      const valid = await this.$refs.form.validate();
      if (valid) {
        this.loading = true;
        const resp = await api.cims.postBorrowInfo({
          CompoundId: this.form.ID,
          ChinName: this.form.ChinName,
          bottleName: this.form.ChinName,
          Purity: this.form.Purity,
          BorrowQuantity: this.form.BorrowQuantity,
          Unit: this.form.Unit,
          Deadline: utils.addDate(this.form.Deadline),
          Comments: this.form.Comments
        });
        if (resp.code == process.env.VUE_APP_code) {
          this.$Message.success({
            content: resp.message,
            onClose: () => {
              window.location.href = this.appPrefix + "/borrow";
            }
          });
        } else {
          this.$Message.error(resp.message);
          this.loading = false;
        }
      }
    }
  }
};
</script>

<style lang="less" scoped>
.content {
  .form {
    width: 400px;
    margin-top: 20px;
  }

  .steps {
    position: relative;
    margin-left: 230px;
    top: -70px;
  }
}

.compound-search-input {
  width: 150px;
  margin-bottom: 16px;
  float: right;
}

.compound-view-record {
  display: inline-block;
  width: 23px;
  height: 15px;
  background: url(../../../assets/img/icons.png) -137px -465px;
  cursor: pointer;

  &:hover {
    background-position-x: -171px;
  }
}
</style>
