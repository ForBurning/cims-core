<template>
<ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
        <div class="page-info">
            <div class="chinName">审批详情</div>
            <div class="chemName">Approval Details</div>
        </div>
        <div class="panel-title" style="margin-top: 0;">
            <span style="margin-left: 30px;">{{$t('columns.purchaseCode')}}：{{approvalDetail.PurchaseCode}}</span>
            <span class="toggle" @click="toggleUpDown(item)">
                <Icon :type="isExpend ? 'ios-arrow-down' : 'ios-arrow-up'" />
            </span>
            <span style="margin-left: 30px;">{{$t('columns.applyTime')}}：{{approvalDetail.ApplyTime}}</span>
            <div class="right-align" v-if="hasApprovePermission">
                <Button @click="approvalEvt(0)" type="primary" :loading="loading1">
                    <span v-if="loading1">{{$t('btn.doing')}}...</span>
                    <span v-else>{{$t('btn.yes')}}</span>
                </Button>
                <Button @click="openRefuseEvt">{{$t('btn.no')}}</Button>
            </div>
        </div>
        <div class="b-panel" v-show="isExpend">
            <Row class="request-detail" type="flex">
                <Col span="8" :title="$t(approvalDetail.ChinName)">{{$t('columns.bottleName')}}：{{approvalDetail.ChinName}}</Col>
                <Col span="8" :title="$t(approvalDetail.chemName)">{{$t('form.chemName')}}：{{approvalDetail.ChemName}}</Col>
                <Col span="8">{{$t('columns.CASNumber')}}：{{approvalDetail.CASNumber}}</Col>
            </Row>
            <Row class="request-detail" type="flex">
                <Col span="8">{{$t('columns.bottleType')}}：{{approvalDetail.Specifications}}</Col>
                <Col span="8">{{approvalDetail.CategoryCode === CR ? $t('columns.purity') : $t('columns.purity1')}}：{{approvalDetail.Purity}}</Col>
                <Col span="8">{{$t('columns.projectCode')}}：{{approvalDetail.ProjectCode}}</Col>
            </Row>
            <Row class="request-detail" type="flex">
                <Col span="8">{{$t('page.supplier')}}：{{approvalDetail.Supplier}}</Col>
                <Col span="8">{{$t('columns.expectationPeriod')}}：{{approvalDetail.ExpectationPeriod}}</Col>
            </Row>
            <Row class="request-detail" type="flex">
                <Col span="8">
                <span class="title">{{$t('columns.price')}}：</span>
                {{approvalDetail.Price}}
                </Col>
                <Col span="8">
                <span class="title">{{$t('columns.number')}}：</span>
                {{approvalDetail.Number}}
                </Col>
                <Col span="8">
                <span class="title">{{$t('columns.totalPrice')}}：</span>
                {{approvalDetail.TotalPrice}}
                </Col>
            </Row>
        </div>

        <div class="panel-title">{{$t('page.inventoryInfo')}}</div>
        <div class="b-panel">
            <div class="store-info">
                <div class="stores" v-if="bottlesInventory.SummaryList.length > 0">
                    <div class="store" v-for="item in bottlesInventory.SummaryList" :key="item.WarehouseName" :class="{low: !item.Power}">
                        <div class="s">
                            <p class="h">{{item.WarehouseName}}</p>
                            <div class="t">
                                <div class="d">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                                <div class="c">
                                    <p v-for="i in item.InventoryInfo" :key="i">{{i}}</p>
                                </div>
                                <div class="b"></div>
                            </div>
                        </div>
                        <div class="p">{{$t('columns.purity')}}：{{item.Purity}}</div>
                    </div>
                    <img src="@/assets/img/power.png" class="power" />
                </div>
                <div style="margin-top: 20px;font-size: 13px;" v-else-if="bottlesInventory.SummaryList.length === 0">{{$t('page.noInventoryInfo')}}</div>
            </div>
        </div>

        <div class="panel-title">{{$t('page.purchasing')}}</div>
        <Table :columns="columns1" :data="data1"></Table>

        <Table :columns="columns" :data="data" style="margin-top: 30px;"></Table>

        <Modal :title="$t('columns.approveReason')" v-model="remarksModal" @on-ok="approvalEvt(1)" :loading="loading">
            <Input type="textarea" :placeholder="$t('message.placeholder', [$t('columns.approveReason')])" v-model="remarks" :autosize="{minRows: 3,maxRows: 5}"></Input>
        </Modal>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from "@/components/layout.vue";
import api from "@/api";
import utils from "@/utils/utils";
import columns from "@/utils/columns";

export default {
    name: "aplicantApprove-detail",
    components: {
        ilabLayout
    },
    data() {
        return {
            appPrefix: process.env.VUE_APP_prefix,
            CR: process.env.VUE_APP_CR,
            breadcrumbs: [{
                    txt: this.$i18n.t("nav.applicantApprove"),
                    href: "/applicantApprove"
                },
                {
                    txt: this.$i18n.t("btn.approveDetail")
                }
            ],
            bottlesInventory: {
                SummaryList: []
            },
            approvalDetail: {},
            hasApprovePermission: false,
            columnsInfo: false,
            reagentsInfo: false,
            isExpend: true,
            history: {},
            active: true,
            columns: [
                columns.ApproveUser(this.$i18n.t("columns.approveUsersNames")),
                columns.ApproveStateName(this.$i18n.t("columns.approveState")),
                columns.ApproveTime(this.$i18n.t("columns.approveTime"), 'auto'),
                {
                    title: this.$i18n.t("form.approvalIdea"),
                    key: "ApproveReason",
                    render: (h, params) => {
                        return h(
                            "div",
                            params.row.ApproveState === 0 ?
                            "" :
                            params.row.ApproveReason || this.$i18n.t("btn.yes")
                        );
                    }
                }
            ],
            data: [],
            columns1: [
                columns.chinName(this.$i18n.t("form.chinName")),
                columns.CASNumber(this.$i18n.t("columns.CASNumber")),
                columns.Specifications(this.$i18n.t("columns.bottleType")),
                columns.Purity(this.$i18n.t("columns.purity")),
                columns.number(this.$i18n.t("columns.number")),
                columns.Price(this.$i18n.t("columns.price")),
                columns.TotalPrice(this.$i18n.t("columns.totalPrice")),
                columns.ProjectCode(this.$i18n.t("columns.projectCode")),
                columns.Applicant(this.$i18n.t("columns.applicant")),
                columns.ApplyTime(this.$i18n.t("columns.applyTime"))
            ],
            data1: [],
            remarks: "",
            remarksModal: false,
            loading: true,
            userId: utils.getUserInfo("id"),
            loading1: false
        };
    },
    methods: {
        //收起展开
        toggleUpDown(item) {
            this.isExpend = !this.isExpend;
        },
        async approvalEvt(approveResult) {
            let approveList = [{
                orderNumber: this.approvalDetail.PurchaseCode,
                orderId: this.approvalDetail.ID,
                flowNodeId: this.approvalDetail.FlowNodeId,
                approveUser: utils.getUserInfo("id"),
                approveUsers: this.approvalDetail.ApproveUsers,
                approveResult: approveResult,
                remarks: approveResult === 0 ? "" : this.remarks,
                orderApproveStatus: this.approvalDetail.ApproveState
            }];

            let resp = {};

            if (approveResult === 0) {
                this.loading1 = true;
                resp = await api.cims.applicantApproveYes(approveList);
                this.loading1 = false;
            } else {
                if (this.remarks) {
                    if (this.remarks.length < 50) {
                        resp = await api.cims.applicantApproveNo(approveList);
                    } else {
                        this.$Message.warning(
                            this.$i18n.t("message.notOver", [this.$i18n.t("columns.approveReason"), 50])
                        );
                        this.loading = false;
                        setTimeout(() => {
                            this.loading = true;
                        }, 0);
                        return false;
                    }
                } else {
                    this.$Message.warning(
                        this.$i18n.t("message.placeholder", [this.$i18n.t("columns.approveReason")])
                    );
                    this.loading = false;
                    setTimeout(() => {
                        this.loading = true;
                    }, 0);
                    return false;
                }
            }

            if (resp.code == process.env.VUE_APP_code) {
                this.$Message.success(resp.message);
                const tabName = approveResult === 0 ? 2 : 3;
                window.location.href =
                    process.env.VUE_APP_prefix + "/applicantApprove?name=" + tabName;
            } else {
                this.$Message.error(resp.message);
            }
        },
        openRefuseEvt() {
            this.loading = true;
            this.remarks = "";
            this.remarksModal = true;
        }
    },
    async mounted() {
        const id = utils.getParams("id");
        if (id) {
            let resp = await api.cims.getPurchase(id);

            if (resp.code == process.env.VUE_APP_code) {
                this.approvalDetail = [];
                if (resp.response.PurchaseDetail.ApproveUsers) {
                    const approveUsers = resp.response.PurchaseDetail.ApproveUsers.split(",");
                    const roles = utils.getCimsInfo().RoleCodes;
                    //当前用户有申领审批角色且是审批人之一（有可能审批过程中， 用户审批角色被移除角色）
                    this.hasApprovePermission = approveUsers.includes(this.userId.toString()) && roles.APPLYAPPROVE;
                }
                this.approvalDetail = resp.response.PurchaseDetail;
                this.data = resp.response.ApprovalHistory;

                const resp1 = await api.cims.getBttlesInventory({
                    purchaserId: resp.response.PurchaseDetail.ApplicantId,
                    materielNumber: resp.response.PurchaseDetail.MaterielNumber
                });

                if (resp1.code == process.env.VUE_APP_code) {
                    this.bottlesInventory = resp1.response || {};
                }
                
                const resp2 = await api.cims.fetchPurchasesCompoundArriveData({
                    materielNumber: resp.response.PurchaseDetail.MaterielNumber
                });
                if (resp2.code == process.env.VUE_APP_code) {
                    this.data1 = resp2.rows;
                }
            } else {
                window.location.href = this.appPrefix + "/404";
            }
        }
    }
};
</script>

<style lang="less" scoped>
.content {
    .panel-title {
        line-height: 58px;
        background-color: #f8f8f8;
        color: #000;
        padding: 0 30px;
        font-size: 15px;
        margin-top: 30px;
    }

    .right-align {
        float: right;

        button {
            margin-right: 14px;
        }
    }

    .toggle {
        display: inline-block;
        width: 24px;
        height: 24px;
        line-height: 21px;
        border-radius: 100%;
        border: 1px solid #e0e0e0;
        text-align: center;
        background-color: #ffffff;
        cursor: pointer;
        margin-left: 4px;
    }

    .b-panel {
        .ivu-row-flex {
            text-align: center;
            font-size: 14px;

            .ivu-col{
                overflow: hidden;
                height: 50px;
                padding: 0 16px 0 60px;
                text-overflow: ellipsis;
                white-space: nowrap;
                text-align: left;
            }
        }
    }

    .store-info .a-title {
        margin-top: 16px;
        font-size: 18px;
        text-align: center;
    }

    .store-info {
        text-align: center;
    }

    .power {
        margin: 16px auto;
        display: block;
    }

    .store-info .a-subtitle {
        width: 450px;
        height: 30px;
        line-height: 30px;
        text-align: center;
        margin: 12px auto;
        font-size: 14px;
        background-color: #f1f1f1;
        background-image: linear-gradient(to right, #fdfdfd, #f0f0f0, #fdfdfd);
    }

    .stores {
        display: inline-block;
        width: 100%;
        margin-top: 20px;
        text-align: center;
    }

    .stores .store {
        width: 33.3%;
        display: inline-block;
    }

    .stores .store .s {
        width: 217px;
        margin: 0 auto;
    }

    .stores .store .h {
        height: 30px;
        line-height: 30px;
        text-align: center;
        color: #fff;
        border-top-left-radius: 6px;
        border-top-right-radius: 6px;
        background-color: #3496ed;
        margin: 0;
        padding: 0;
    }

    .stores .store.low .h {
        color: #3f596a;
        background-color: #ced6e1;
    }

    .stores .store .t {
        width: 200px;
        margin: 0 auto;
        background-color: #f2f2f2;
    }

    .stores .store .p {
        font-size: 20px;
        text-align: center;
        line-height: 24px;
        margin-top: 12px;
    }

    .stores .store .t .d {
        border-top: 6px solid #e2e2e2;
    }

    .stores .store .t .d span {
        border-top: 6px solid #e2e2e2;
        display: inline-block;
        width: 22px;
        height: 22px;
        margin: 10px 12px;
        background-color: #ced6e1;
        border: 1px solid #e3e6eb;
    }

    .stores .store p {
        margin: 0;
        padding: 0;
    }

    .stores .store .b {
        height: 20px;
        border-bottom-left-radius: 6px;
        border-bottom-right-radius: 6px;
        background-color: #405a6b;
    }

    .stores .store.low .b {
        background-color: #e2e2e2;
    }

    .stores .store .t .c {
        min-height: 120px;
        margin: 0 25px;
        padding: 16px 12px 12px;
        background-color: #fff;
        color: #fff;
        border: 1px solid #8d9ba6;
        border-bottom: none;
    }

    .stores .store .t p {
        height: 22px;
        line-height: 22px;
        text-align: center;
        color: #fff;
        margin-bottom: 12px;
        border-radius: 4px;
    }

    .stores .store .t p:nth-child(1) {
        background-color: #f46d57;
    }

    .stores .store .t p:nth-child(2) {
        background-color: #ffad2b;
    }

    .stores .store .t p:nth-child(3) {
        background-color: #90deaa;
    }

    .stores .store .t p:nth-child(4) {
        background-color: #596ccb;
    }

    .stores .store .t p:last-child {
        margin-bottom: 0;
    }

    .request-detail {
        border-bottom: 1px dashed #ddd;
        height: 50px;
        line-height: 50px;
        text-align: left;

        .title {
            font-weight: bold;
        }
    }
}
</style>
