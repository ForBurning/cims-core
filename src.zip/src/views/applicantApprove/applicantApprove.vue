<template>
  <ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
      <div class="page-info">
        <div class="chinName">申购审批</div>
        <div class="chemName">Apply Approve</div>
      </div>

      <Tabs v-model="name" class="ilab-tabs" :animated="false" @on-click="onTabsClick">
        <TabPane :label="$t('tab.approving')" name="1">
          <Row class="search-conditions" type="flex">
            <Col class="flex-1">
              {{$t('columns.bottleName')}}：
              <Input v-model="condition1"></Input>
              {{$t('columns.CASNumber')}}：
              <Input v-model="condition3"></Input>
              {{$t('columns.applicantDate')}}：
              <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
            </Col>
            <Col>
              <Button
                size="large"
                type="primary"
                icon="ios-search"
                @click="fetchData(1)"
              >{{$t('btn.search')}}</Button>
            </Col>
          </Row>
          <Table
            :columns="columns1"
            :data="data"
            :noDataText="noDataText"
            ref="table1"
            @on-select="getSelectCount"
            @on-select-all="getSelectCount"
            @on-select-all-cancel="getSelectCount"
            @on-select-cancel="getSelectCount"
          >
            <template slot-scope="{ row }" slot="ChinName">
              <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
            </template>
            <template slot-scope="{ row }" slot="storeInfo">
              <div @click="viewInventory(row)">
                <Icon type="md-eye" />
              </div>
            </template>
            <template slot-scope="{ row }" slot="Action1">
              <Button
                :to="`/applicantApprove/detail?id=${row.PurchaseCode}`"
              >{{$t('btn.approveDetail')}}</Button>
            </template>
          </Table>
          <Page
            :total="total"
            show-total
            :page-size="10"
            @on-change="fetchData"
            v-show="total > 0"
            :current="pageIndex"
          />
          <Row class="batch-operation" v-if="total > 0">
            <Col span="12">
              <Button
                class="select-all-btn"
                @click="selectAll"
              >{{selectCount === data.length ? $t('btn.cancelAll') : $t('btn.selectAll')}}</Button>
            </Col>
            <Col span="12">
              <Button
                size="large"
                type="primary"
                :disabled="selectCount === 0"
                @click="batchSubmit"
              >{{$t('btn.batchYes')}}</Button>
              <Button
                size="large"
                type="error"
                :disabled="selectCount === 0"
                @click="openModal"
              >{{$t('btn.batchNo')}}</Button>
            </Col>
          </Row>
        </TabPane>
        <TabPane :label="$t('tab.approved')" name="2">
          <Row class="search-conditions" type="flex">
            <Col class="flex-1">
              {{$t('columns.bottleName')}}:
              <Input v-model="condition1"></Input>
              {{$t('columns.CASNumber')}}：
              <Input v-model="condition3"></Input>
              {{$t('columns.applicantDate')}}：
              <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
            </Col>
            <Col>
              <Button
                size="large"
                type="primary"
                icon="ios-search"
                @click="fetchData(1)"
              >{{$t('btn.search')}}</Button>
            </Col>
          </Row>
          <Table :columns="columns2" :data="data" :noDataText="noDataText">
            <template slot-scope="{ row }" slot="ChinName">
              <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
            </template>
            <template slot-scope="{ row }" slot="storeInfo">
              <Icon type="md-eye" />
            </template>
            <template slot-scope="{ row }" slot="Action1">
              <Button
                :to="`/applicantApprove/detail?id=${row.PurchaseCode}`"
              >{{$t('btn.approveDetail')}}</Button>
            </template>
          </Table>
          <Page
            :total="total"
            show-total
            :page-size="10"
            @on-change="fetchData"
            v-show="total > 0"
            :current="pageIndex"
          />
        </TabPane>
        <TabPane :label="$t('tab.rejected')" name="3">
          <Row class="search-conditions" type="flex">
            <Col class="flex-1">
              {{$t('columns.bottleName')}}:
              <Input v-model="condition1"></Input>
              {{$t('columns.CASNumber')}}：
              <Input v-model="condition3"></Input>
              {{$t('columns.applicantDate')}}：
              <DatePicker @on-change="condition2=$event" type="daterange" split-panels transfer></DatePicker>
            </Col>
            <Col>
              <Button
                size="large"
                type="primary"
                icon="ios-search"
                @click="fetchData(1)"
              >{{$t('btn.search')}}</Button>
            </Col>
          </Row>
          <Table :columns="columns2" :data="data" :noDataText="noDataText">
            <template slot-scope="{ row }" slot="ChinName">
              <a :href="appPrefix + '/applicant/detail?id=' + row.ID">{{row.ChinName}}</a>
            </template>
            <template slot-scope="{ row }" slot="storeInfo">
              <Icon type="md-eye" />
            </template>
            <template slot-scope="{ row }" slot="Action1">
              <Button
                :to="`/applicantApprove/detail?id=${row.PurchaseCode}`"
              >{{$t('btn.approveDetail')}}</Button>
            </template>
          </Table>
          <Page
            :total="total"
            show-total
            :page-size="10"
            @on-change="fetchData"
            v-show="total > 0"
            :current="pageIndex"
          />
        </TabPane>
      </Tabs>

      <Modal
        :title="$t('columns.approveReason')"
        v-model="modal"
        @on-ok="batchDelete"
        :loading="loading"
      >
        <Form ref="form" :model="form" :rules="rules" :label-width="80">
          <FormItem :label="$t('columns.approveReason')" prop="remarks">
            <Input
              type="textarea"
              :placeholder="$t('message.placeholder', [$t('form.approvalIdea')])"
              v-model="form.remarks"
              :autosize="{minRows: 3,maxRows: 5}"
            ></Input>
          </FormItem>
        </Form>
      </Modal>

      <Modal
        :title="$t('page.inventoryInfo')"
        v-model="historyModal"
        footer-hide
        class="historyModal"
        :width="800"
      >
        <div class="b-panel">
          <div class="store-info">
            <div class="a-title">{{$t('page.inventoryInfo')}}</div>
            <div
              class="a-subtitle"
            >{{$t('columns.bottleName')}}: {{bottlesInventory.ChinName}}{{bottlesInventory.ChemName ? '/' : ''}}{{bottlesInventory.ChemName}}</div>
            <div class="stores">
              <div
                class="store"
                v-for="item in bottlesInventory.SummaryList"
                :key="item.WarehouseName"
                :class="{low: !item.Power}"
              >
                <div class="s">
                  <p class="h">{{item.WarehouseName}}</p>
                  <div class="t">
                    <div class="d">
                      <span></span>
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                    <div class="c">
                      <p v-for="i in item.InventoryInfo" :key="i">{{i}}</p>
                    </div>
                    <div class="b"></div>
                  </div>
                </div>
                <div class="p">{{$t('columns.purity')}}：{{item.Purity}}</div>
              </div>
            </div>

            <div v-show="!bottlesInventory.SummaryList">{{$t('page.noInventoryInfo')}}</div>
          </div>
          <img src="@/assets/img/power.png" class="power" />
        </div>
      </Modal>
    </div>
  </ilab-layout>
</template>
<script>
import ilabLayout from "@/components/layout.vue";
import api from "@/api";
import utils from "@/utils/utils";
import columns from "@/utils/columns";

export default {
  name: "aplicantApprove",
  components: {
    ilabLayout
  },
  data() {
    return {
      noDataText: this.$i18n.t("columns.noDataText"),
      appPrefix: process.env.VUE_APP_prefix,
      name: "1",
      breadcrumbs: [
        {
          txt: this.$i18n.t("nav.applicantApprove")
        }
      ],
      columns1: [
        columns.Select,
        Object.assign(columns.ChinName(this.$i18n.t("columns.bottleName")), {
          width: 100
        }),
        columns.MaterielNumber(this.$i18n.t("page.materielNumber")),
        columns.CategoryName(this.$i18n.t("columns.categoryName")),
        columns.CASNumber(this.$i18n.t("columns.CASNumber")),
        columns.Purity(this.$i18n.t("columns.purity")),
        columns.number(this.$i18n.t("columns.number")),
        columns.Price(this.$i18n.t("columns.price")),
        columns.TotalPrice(this.$i18n.t("columns.totalPrice")),
        columns.ProjectCode(this.$i18n.t("columns.projectCode")),
        columns.ExpectationPeriod(this.$i18n.t("columns.expectationPeriod")),
        columns.Applicant(this.$i18n.t("columns.applicant")),
        columns.ApplyTime(this.$i18n.t("columns.applyTime")),
        columns.storeInfo(this.$i18n.t("page.inventoryInfo")),
        columns.Action1(this.$i18n.t("columns.operation"))
      ],
      columns2: [
        Object.assign(columns.ChinName(this.$i18n.t("columns.bottleName")), {
          width: 100
        }),
        columns.MaterielNumber(this.$i18n.t("page.materielNumber")),
        columns.CategoryName(this.$i18n.t("columns.categoryName")),
        columns.CASNumber(this.$i18n.t("columns.CASNumber")),
        columns.Purity(this.$i18n.t("columns.purity")),
        columns.number(this.$i18n.t("columns.number")),
        columns.Price(this.$i18n.t("columns.price")),
        columns.TotalPrice(this.$i18n.t("columns.totalPrice")),
        columns.ProjectCode(this.$i18n.t("columns.projectCode")),
        columns.ExpectationPeriod(this.$i18n.t("columns.expectationPeriod")),
        columns.Applicant(this.$i18n.t("columns.applicant")),
        columns.ApplyTime(this.$i18n.t("columns.applyTime")),
        columns.applicantApproveTime(this.$i18n.t("columns.approveTime")),
        columns.Action1(this.$i18n.t("columns.operation"))
      ],
      data: [],
      total: 0,
      pageIndex: 1,
      selectCount: 0,
      condition1: "",
      condition2: "",
      condition3: "",
      modal: false,
      loading: true,
      historyModal: false,
      bottlesInventory: {
        SummaryList: []
      },
      form: {
        remarks: ""
      },
      rules: {
        remarks: [
          {
            required: true,
            message: this.$i18n.t("message.notNull", [
              this.$i18n.t("form.returnReason")
            ]),
            trigger: "change"
          }
        ]
      }
    };
  },
  methods: {
    //打开撤回模态框
    openModal() {
      this.$refs.form.resetFields();
      this.modal = true;
    },
    //关闭loading
    resetLoading() {
      this.loading = false;
      setTimeout(() => {
        this.loading = true;
      }, 0);
    },
    /**
     * @description tab切换
     */
    onTabsClick(tabName) {
      this.condition1 = "";
      this.condition2 = "";
      this.condition3 = "";
      this.data = [];
      this.total = 0;
      this.selectCount = 0;
      this.fetchData();
    },
    //全选
    selectAll() {
      const isSelectAll = this.selectCount === this.data.length;
      if (isSelectAll) {
        this.$refs[`table${this.name}`].selectAll(false);
        this.selectCount = 0;
      } else {
        this.$refs[`table${this.name}`].selectAll(true);
        this.selectCount = this.data.length;
      }
    },
    getSelectCount() {
      this.selectCount = this.$refs[`table${this.name}`].getSelection().length;
    },
    /**
     * @description 获取表格数据
     */
    async fetchData(pageIndex = 1) {
      this.noDataText = this.$i18n.t("columns.noDataText");

      let resp = await api.cims[`fetchMyApplicantApproveDataTab${this.name}`]({
        pageIndex: pageIndex,
        chinName: this.condition1,
        purchaseStartDate: this.condition2.length ? this.condition2[0] : "",
        purchaseEndDate: this.condition2.length ? this.condition2[1] : "",
        casNumber: this.condition3
      });
      if (resp.code == process.env.VUE_APP_code) {
        this.data = resp.rows;
        this.total = resp.total;
      } else {
        this.data = [];
        this.total = 0;
        this.noDataText = this.$i18n.t("columns.noDataText2");
      }
      this.pageIndex = pageIndex;
      this.selectCount = 0;
    },
    //批量拒绝
    async batchDelete() {
      const valid = await this.$refs.form.validate();
      if (valid) {
        const selection = this.$refs[`table${this.name}`].getSelection();
        let resp = await api.cims.applicantApproveNo(
          selection.map(item => {
            return {
              orderNumber: item.PurchaseCode,
              orderId: item.ID,
              flowNodeId: item.FlowNodeId,
              approveUsers: item.ApproveUsers,
              approveResult: 1,
              remarks: this.form.remarks,
              orderApproveStatus: item.ApproveState
            };
          })
        );
        if (resp.code == process.env.VUE_APP_code) {
          this.$Message.success(resp.message);
          this.modal = false;
          this.fetchData();
        } else {
          this.$Message.error(resp.message);
        }
      } else {
        this.resetLoading();
      }
    },
    //批量通过
    async batchSubmit() {
      const selection = this.$refs[`table${this.name}`].getSelection();
      let resp = await api.cims.applicantApproveYes(
        selection.map(item => {
          return {
            orderNumber: item.PurchaseCode,
            orderId: item.ID,
            flowNodeId: item.FlowNodeId,
            approveUsers: item.ApproveUsers,
            approveResult: 0,
            remarks: "",
            orderApproveStatus: item.ApproveState
          };
        })
      );
      if (resp.code == process.env.VUE_APP_code) {
        this.$Message.success(resp.message);
        this.fetchData();
      } else {
        this.$Message.error(resp.message);
      }
    },
    //查看库存
    async viewInventory(item) {
      const resp = await api.cims.getBttlesInventory({
        purchaserId: item.ApplicantId,
        materielNumber: item.MaterielNumber
      });
      if (resp && resp.code) {
        this.bottlesInventory = resp.response;
      } else {
        this.bottlesInventory = {};
      }
      this.historyModal = true;
    }
  },
  created() {
    this.name = utils.getParams("name") || "1";
  },
  mounted() {
    this.fetchData();
  }
};
</script>

<style lang="less" scoped>
.ivu-icon-md-eye {
  font-size: 22px;
  cursor: pointer;
}

.historyModal {
  .b-panel {
    .ivu-row-flex {
      text-align: center;
      font-size: 14px;
    }
  }

  .store-info .a-title {
    margin-top: 16px;
    font-size: 18px;
    text-align: center;
  }

  .store-info {
    text-align: center;
  }

  .power {
    margin: 16px auto;
    display: block;
  }

  .store-info .a-subtitle {
    width: 450px;
    height: 30px;
    line-height: 30px;
    text-align: center;
    margin: 12px auto;
    font-size: 14px;
    background-color: #f1f1f1;
    background-image: linear-gradient(to right, #fdfdfd, #f0f0f0, #fdfdfd);
  }

  .stores {
    display: inline-block;
    width: 100%;
    margin-top: 20px;
    text-align: center;
  }

  .stores .store {
    width: 33.3%;
    display: inline-block;
  }

  .stores .store .s {
    width: 217px;
    margin: 0 auto;
  }

  .stores .store .h {
    height: 30px;
    line-height: 30px;
    text-align: center;
    color: #fff;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    background-color: #3496ed;
    margin: 0;
    padding: 0;
  }

  .stores .store.low .h {
    color: #3f596a;
    background-color: #ced6e1;
  }

  .stores .store .t {
    width: 200px;
    margin: 0 auto;
    background-color: #f2f2f2;
  }

  .stores .store .p {
    font-size: 20px;
    text-align: center;
    line-height: 24px;
    margin-top: 12px;
  }

  .stores .store .t .d {
    border-top: 6px solid #e2e2e2;
  }

  .stores .store .t .d span {
    border-top: 6px solid #e2e2e2;
    display: inline-block;
    width: 22px;
    height: 22px;
    margin: 10px 12px;
    background-color: #ced6e1;
    border: 1px solid #e3e6eb;
  }

  .stores .store p {
    margin: 0;
    padding: 0;
  }

  .stores .store .b {
    height: 20px;
    border-bottom-left-radius: 6px;
    border-bottom-right-radius: 6px;
    background-color: #405a6b;
  }

  .stores .store.low .b {
    background-color: #e2e2e2;
  }

  .stores .store .t .c {
    min-height: 120px;
    margin: 0 25px;
    padding: 16px 12px 12px;
    background-color: #fff;
    color: #fff;
    border: 1px solid #8d9ba6;
    border-bottom: none;
  }

  .stores .store .t p {
    height: 22px;
    line-height: 22px;
    text-align: center;
    color: #fff;
    margin-bottom: 12px;
    border-radius: 4px;
  }

  .stores .store .t p:nth-child(1) {
    background-color: #f46d57;
  }

  .stores .store .t p:nth-child(2) {
    background-color: #ffad2b;
  }

  .stores .store .t p:nth-child(3) {
    background-color: #90deaa;
  }

  .stores .store .t p:nth-child(4) {
    background-color: #596ccb;
  }

  .stores .store .t p:last-child {
    margin-bottom: 0;
  }
}
</style>
