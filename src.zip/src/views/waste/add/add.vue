<template>
<ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
        <div class="page-info">
            <Row type="flex">
                <Col class="flex-1">
                <div class="chinName">废弃新增</div>
                <div class="chemName">Waste Add</div>
                </Col>
            </Row>
        </div>

        <div class="form-title">{{$t('form.wasteTitle')}}</div>
        <table class="form-table">
            <tr>
                <td colspan="3">{{$t('form.waste1')}}
                <td colspan="9">
                    <div>{{$t('form.waste2')}}：<input type="text" v-model="form.ChemicalType" class="w350"></input></div>
                    <div>{{$t('form.waste3')}}：<input type="text" v-model="form.ChemicalName" class="w350"></div>
                    <div>{{$t('form.waste4')}}：<input type="text" v-model="form.ChemicalComponent" class="w350"></div>
                </td>
            </tr>
            <tr>
                <td colspan="2">{{$t('form.waste5')}}</td>
                <td colspan="10">
                    <div>
                        <div style="width:50%;float:left;">{{$t('form.waste6')}}：<input type="text" v-model="form.CompanyName" class="w260"></div>
                        <div style="width:50%;float:left;">{{$t('form.waste7')}}：<input type="text" v-model="form.LabName" class="w260"></div>
                        <div style="width:50%;float:left;">{{$t('columns.producer1')}}：<input type="text" v-model="form.Producer" class="w260"></div>
                        <div style="width:50%;float:left;">{{$t('form.waste8')}}：<input type="text" v-model="form.Collector" class="w260"></div>
                        <div style="width:50%;float:left;">{{$t('form.waste9')}}：<input type="text" v-model="form.Address" class="w260"></div>
                        <div style="width:50%;float:left;">{{$t('form.waste10')}}：<input type="text" v-model="form.Phone" class="w260"></div>
                    </div>
                </td>
            </tr>
            <tr>
                <td colspan="2">{{$t('form.waste11')}}</td>
                <td colspan="5">
                    <CheckboxGroup v-model="Container">
                        <Checkbox v-for="item in types.Container" :label="item.ID" :key="item.ID">{{item.Name}}</Checkbox>
                    </CheckboxGroup>
                </td>
                <td colspan="2">{{$t('form.waste12')}}</td>
                <td colspan="3">
                    <div>{{$t('form.waste13')}}：<input type="text" class="w100" v-model="form.ContainerCode"></div>
                    <div>{{$t('form.waste14')}}：<input type="text" class="w100" v-model="form.ContainerColor"></div>
                </td>
            </tr>
            <tr>
                <td colspan="3">{{$t('form.waste15')}}</td>
                <td colspan="9">{{$t('form.waste16')}}：
                    <CheckboxGroup v-model="StorageLocation">
                        <Checkbox v-for="item in types.StorageLocation" :label="item.ID" :key="item.ID">{{item.Name}}</Checkbox>
                    </CheckboxGroup>
                    <div>
                        {{$t('form.waste17')}}：<input type="text" v-model="form.StorageAddress" class="w100">
                    </div>
                </td>
            </tr>
            <tr>
                <td colspan="3">{{$t('form.waste18')}}</td>
                <td colspan="9">{{$t('form.waste19')}}：<input type="text" v-model="form.ChemicalOrigin" class="w480" :placeholder="$t('form.waste20')"></td>
            </tr>
            <tr>
                <td colspan="3">{{$t('form.waste21')}}</td>
                <td colspan="9">
                    <CheckboxGroup v-model="PhysicalStale">
                        <Checkbox v-for="item in types.PhysicalStale" :label="item.ID" :key="item.ID">{{item.Name}}</Checkbox>
                    </CheckboxGroup>
                    {{$t('form.waste14')}}：<input type="text" v-model="form.PhysicalStaleColor" class="w100">
                </td>
            </tr>
            <tr>
                <td colspan="3">{{$t('form.waste22')}}</td>
                <td colspan="9">
                    <CheckboxGroup v-model="RiskCategory">
                        <Checkbox v-for="item in types.RiskCategory" :label="item.ID" :key="item.ID">{{item.Name}}</Checkbox>
                    </CheckboxGroup>
                </td>
            </tr>
            <tr>
                <td colspan="3">{{$t('form.waste23')}}</td>
                <td colspan="9">
                    <CheckboxGroup v-model="StorageTime">
                        <div v-for="(item, index) in types.StorageTime" style="margin-bottom: 5px;" :key="item.ID">
                            <div v-if="item.Name !== $t('form.waste24')">
                                <Checkbox :label="item.ID">{{item.Name}}</Checkbox>
                                {{$t('form.waste25')}}：<DatePicker type="date" :value="StorageTimeVal[`val${index}`]" @on-change="StorageTimeVal[`val${index}`]=$event"></DatePicker>
                            </div>
                            <div v-else>
                                <Checkbox :label="item.ID">{{item.Name}}</Checkbox>
                                {{$t('form.waste26')}}
                            </div>
                        </div>
                    </CheckboxGroup>
                </td>
            </tr>
            <tr>
                <td colspan="3">{{$t('form.waste27')}}</td>
                <td colspan="9">
                    <span v-for="(item, index) in types.QuantityTotal" :key="item.ID">{{item.Name}}：<input type="text" class="w50" v-model="QuantityTotal[`val${index}`]" /></span>
                </td>
            </tr>
            <tr>
                <td colspan="3">{{$t('form.waste28')}}</td>
                <td colspan="9">
                    <CheckboxGroup v-model="OtherExplain">
                        <Checkbox v-for="item in types.OtherExplain" :label="item.ID" :key="item.ID">{{item.Name}}</Checkbox>
                    </CheckboxGroup>
                </td>
            </tr>
            <tr>
                <td colspan="3">{{$t('form.waste29')}}</td>
                <td colspan="9">
                    <DatePicker type="date" :value="form.TransferTime" @on-change="form.TransferTime=$event"></DatePicker>
                </td>
            </tr>
            <tr>
                <td colspan="3">{{$t('form.waste30')}}</td>
                <td colspan="9">
                    <input type="text" v-model="form.Comments" class="w350">
                </td>
            </tr>
            <tr>
                <td colspan="3">{{$t('form.waste31')}}</td>
                <td colspan="9"></td>
            </tr>
        </table>
        <Button type="primary" :loading="loading" size="large" @click="submit">
            <span v-if="loading">{{$t('btn.submiting')}}...</span>
            <span v-else>{{$t('btn.submit')}}</span>
        </Button>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from '@/components/layout.vue'
import api from '@/api'
import utils from '@/utils/utils'

export default {
    name: "waste-add-page",
    components: {
        ilabLayout,
    },
    data() {
        return {
            appPrefix: process.env.VUE_APP_prefix,
            breadcrumbs: [{
                txt: this.$i18n.t("nav.wasteCollection"),
                href: '/waste'
            }, {
                txt: this.$i18n.t("nav.wasteAdd")
            }],
            form: {
                ChemicalType: "",
                ChemicalName: "",
                ChemicalComponent: "",
                CompanyName: "",
                LabName: "",
                Address: "",
                Producer: "",
                Collector: "",
                Phone: "",
                ContainerCode: "",
                ContainerColor: "",
                StorageAddress: "",
                ChemicalOrigin: "",
                PhysicalStaleColor: "",
                Comments: "",
                TransferTime: "",
                ChemicalWasteSub: []
            },
            Container: [],
            StorageLocation: [],
            PhysicalStale: [],
            RiskCategory: [],
            StorageTime: [],
            StorageTimeVal: {},
            QuantityTotal: {},
            OtherExplain: [],
            types: {},
            loading: false,
        };
    },
    methods: {
        //加载初始化废弃化学品配置信息
        async fetchChemicalConfigData() {
            const resp = await api.cims.fetchChemicalConfigData();
            resp.response.map(item => {
                this.$set(this.types, item.CollectionType, item.ValueText)
            })
        },
        //提交
        async submit() {

            if (!this.form.ChemicalType) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("form.waste2")]));
            } else if (!this.form.ChemicalName) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("form.waste3")]));
            } else if (!this.form.ChemicalComponent) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("form.waste4")]));
            } else if (!this.form.CompanyName) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("form.waste6")]));
            } else if (!this.form.LabName) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("form.waste7")]));
            } else if (!this.form.Producer) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("columns.producer1")]));
            } else if (!this.form.Collector) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("form.waste8")]));
            } else if (!this.form.Address) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("form.waste9")]));
            } else if (!this.form.Phone) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("form.waste10")]));
            } else if (!this.form.ContainerCode) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("form.waste13")]));
            } else if (!this.form.ContainerColor) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("form.waste14")]));
            } else if (!this.form.StorageAddress) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("form.waste17")]));
            } else if (!this.form.ChemicalOrigin) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("form.waste19")]));
            } else if (!this.form.PhysicalStaleColor) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("form.waste21")]));
            } else if (!this.form.TransferTime) {
                this.$Message.warning(this.$i18n.t("message.notNull", [this.$i18n.t("form.waste29")]));
            } else {
                let orgData = utils.deepCopy(this.form);

                orgData.ChemicalWasteSub.push({
                    ChemicalWasteTypeId: 1,
                    Comments: this.Container.join(',')
                })

                orgData.ChemicalWasteSub.push({
                    ChemicalWasteTypeId: 2,
                    Comments: this.StorageLocation.join(',')
                })
				orgData.ChemicalWasteSub.push({
                    ChemicalWasteTypeId: 3,
                    Comments: this.PhysicalStale.join(',')
                }),
                orgData.ChemicalWasteSub.push({
                    ChemicalWasteTypeId: 4,
                    Comments: this.RiskCategory.join(',')
                })
                orgData.ChemicalWasteSub.push({
                    ChemicalWasteTypeId: 8,
                    Comments: this.StorageTime.join(',')
                })

                orgData.ChemicalWasteSub.push({
                    ChemicalWasteTypeId: 5,
                    Comments: JSON.stringify(this.StorageTimeVal)
                })

                orgData.ChemicalWasteSub.push({
                    ChemicalWasteTypeId: 6,
                    Comments: JSON.stringify(this.QuantityTotal)
                })

                orgData.ChemicalWasteSub.push({
                    ChemicalWasteTypeId: 7,
                    Comments: this.OtherExplain.join(',')
                })

                const resp = await api.cims.addChemicalData(orgData);
                if (resp.code == process.env.VUE_APP_code) {
                    this.$Message.success(resp.message);
                    await utils.sleep(1500);
                    window.location.href = "/waste";
                } else {
                    this.$Message.error(resp.message);
                    this.loading = false;
                }
            }
        }
    },
    mounted() {
        this.fetchChemicalConfigData();
    }
}
</script>

<style lang="less" scoped>
.content {

    .form-title {
        font-size: 22px;
        color: #292929;
        text-align: center;
        margin-bottom: 24px;
    }

    .form-table {
        border-top: 1px solid #9e9e9e;
        border-right: 1px solid #9e9e9e;
        border-collapse: collapse;
        border-spacing: 0;
        margin: 0 auto;
        font-size: 15px;
        width: 900px;
        table-layout: fixed;

        tr {
            border-bottom: 1px solid #9e9e9e;

            td {
                padding: 4px 12px;
                border-left: 1px solid #9e9e9e;

                &:first-child {
                    // white-space: nowrap;
                }
            }
        }

        input[type=text] {
            margin: 0 12px 0 2px;
            height: 32px;
            border: none;
            border-bottom: 1px solid #ffffff;
            transition: .4s;

            &:hover {
                border-bottom: 1px solid #9e9e9e;
            }

            &:focus {
                outline: none;

            }
        }

        .ivu-checkbox-wrapper {
            font-size: 15px;
        }

        .ivu-checkbox-group {
            display: inline-block;
        }

        .w350 {
            width: 350px;
        }

        .w260 {
            width: 200px;
        }

        .w100 {
            width: 100px;
        }

        .w480 {
            width: 480px;
        }

        .w50 {
            width: 50px;
        }
    }

    .ivu-btn {
        margin: 16px auto 0;
        display: block;
    }

}
</style>
