<template>
  <ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
      <div class="page-info">
        <Row type="flex">
          <Col class="flex-1">
            <div class="chinName">废液收集</div>
            <div class="chemName">Waste Collection</div>
          </Col>
          <Col>
            <Button
              size="large"
              :to="`${appPrefix}/waste/add`"
              icon="md-add"
              @click="modal1=true;"
              v-if="roles.WASTEMANAGER"
            >{{$t('btn.add')}}</Button>
          </Col>
        </Row>
      </div>
      <div class="filter">
        <Input
          v-model="chemicalName"
          :placeholder="$t('columns.chemicalName')"
          @on-blur="fetchData(1)"
        ></Input>
      </div>
      <Table :columns="columns" :data="data" ref="table">
        <template slot-scope="{ row }" slot="Action">
          <Button
            icon="md-create"
            size="small"
            :title="$t('btn.edit')"
            :to="`${appPrefix}/waste/edit?id=${row.ID}`"
          ></Button>
          <Poptip
            confirm
            :title="$t('message.deleteTip')"
            @on-ok="deleteWaste(row.ID)"
          >
            <Button icon="md-trash" :title="$t('btn.remove')" size="small"></Button>
          </Poptip>
        </template>
      </Table>
      <Page :total="total" @on-change="fetchData" :page-size="pageSize"></Page>
    </div>
  </ilab-layout>
</template>
<script>
import ilabLayout from "@/components/layout.vue";
import api from "@/api";
import utils from "@/utils/utils";

export default {
  name: "waste-page",
  components: {
    ilabLayout
  },
  data() {
    return {
      appPrefix: process.env.VUE_APP_prefix,
      pageSize: process.env.VUE_APP_page_size * 1,
      roles: utils.getCimsInfo().RoleCodes,
      total: 0,
      chemicalName: "",
      breadcrumbs: [
        {
          txt: this.$i18n.t("nav.wasteCollection")
        }
      ],
      columns: [
        {
          key: "WasteCode",
          title: this.$i18n.t("columns.numbering")
        },
        {
          key: "ChemicalName",
          title: this.$i18n.t("columns.chemicalName")
        },
        {
          key: "ChemicalType",
          title: this.$i18n.t("columns.chemicalType")
        },
        {
          key: "CompanyName",
          title: this.$i18n.t("columns.companyName")
        },
        {
          key: "LabName",
          title: this.$i18n.t("columns.lab")
        },
        {
          key: "Producer",
          title: this.$i18n.t("columns.producer1")
        },
        {
          key: "CreateTime",
          title: this.$i18n.t("columns.createTime")
        }
      ],
      data: []
    };
  },
  created() {
    if (this.roles.WASTEMANAGER) {
      this.columns.push({
        slot: "Action",
        title: this.$i18n.t("columns.operation"),
        align: "center"
      });
    }
  },
  methods: {
    async fetchData(pageIndex = 1) {
      const resp = await api.cims.fetchWasteData({
        pageIndex: pageIndex,
        pageSize: this.pageSize,
        chemicalName: this.chemicalName
      });
      this.data = resp.rows;
      this.total = resp.total;
    },
    async deleteWaste(id) {
      const resp = await api.cims.deleteWaste(id);

      if (resp.code == process.env.VUE_APP_code) {
        this.$Message.success(resp.message);
        this.fetchData();
      } else {
        this.$Message.error(resp.message);
      }
    }
  },
  mounted() {
    this.fetchData();
  }
};
</script>

<style lang="less" scoped>
.content {
  .filter {
    text-align: right;

    .ivu-input-wrapper {
      width: 250px;
      margin-bottom: 12px;
    }
  }

  .ivu-table-wrapper {
    overflow: inherit;
  }

  /deep/ .ivu-poptip-body {
    white-space: nowrap;

    /deep/ .ivu-icon-ios-help-circle {
      left: 16px;
    }
  }
}
</style>
