<template>
	<ilab-layout :breadcrumbs="breadcrumbs">
		<div slot="content" class="content">
			<h1 style="width: 100%;text-align: center;margin-top: 80px;">{{$t('message.noAuth')}}</h1>
		</div>
	</ilab-layout>
</template>
<script>
	import ilabLayout from '@/components/layout.vue'


	export default {
		name: "noAuth",
		components: {
			ilabLayout,
		},
		data() {
			return {
				breadcrumbs: [{
					txt: this.$i18n.t("nav.noAuth")
				}],
			};
		}
	}
</script>
