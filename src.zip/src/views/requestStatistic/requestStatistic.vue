<template>
  <ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content">
      <div class="page-info">
        <div class="chinName">领用统计</div>
        <div class="chemName">Request Report</div>
      </div>

      <Row class="search-conditions" type="flex">
        <Col class="flex-1">
          {{$t('columns.categoryName')}}：
          <Select
            v-model="categoryCode"
            style="width:130px"
            :placeholder="$t('message.placeSelect', [$t('columns.categoryName')])"
            transfer
            clearable
          >
            <Option
              v-for="item in materielTypes"
              :value="item.CategoryCode"
              :key="item.CategoryCode"
            >{{item.CategoryName}}</Option>
          </Select>
          {{$t('page.chartType')}}：
          <Select v-model="type" style="width:130px">
            <Option :value="1" :key="1">{{$t('page.lineChart')}}</Option>
            <Option :value="2" :key="2">{{$t('page.histogram')}}</Option>
          </Select>
          {{$t('page.statisticTime')}}：
          <DatePicker @on-change="condition1=$event" type="daterange" split-panels></DatePicker>
          {{$t('nav.projects')}}：
          <Select v-model="project" multiple style="width:260px">
            <Option
              v-for="item in projectList"
              :value="item.ID"
              :key="item.ID"
            >{{ item.ProjectCode }}</Option>
          </Select>
        </Col>
        <Col>
          <Button size="large" type="primary" icon="ios-search" @click="search">{{$t('btn.search')}}</Button>
        </Col>
      </Row>

      <Tabs v-model="name" class="ilab-tabs" :animated="false">
        <TabPane :label="$t('page.report')" name="1">
          <v-chart :options="requestStatistic" style="width: 100%;" />
        </TabPane>
        <TabPane :label="$t('page.requestData')" name="2">
          <Table :columns="requestColumns" :data="data2"></Table>
          <Page
            :total="total2"
            show-total
            :page-size="10"
            @on-change="fetchRequestApproveData($event, 2)"
            v-show="total2 > 0"
          />
        </TabPane>
        <TabPane :label="$t('page.returnData')" name="3">
          <Table :columns="tkColumns" :data="data3"></Table>
          <Page
            :total="total3"
            show-total
            :page-size="10"
            @on-change="fetchRequestApproveData($event, 3)"
            v-show="total3 > 0"
          />
        </TabPane>
        <TabPane :label="$t('page.scrappData')" name="4">
          <Table :columns="bfColumns" :data="data4"></Table>
          <Page
            :total="total4"
            show-total
            :page-size="10"
            @on-change="fetchRequestApproveData($event, 4)"
            v-show="total4 > 0"
          />
        </TabPane>
      </Tabs>
    </div>
  </ilab-layout>
</template>
<script>
import ECharts from "vue-echarts";
import "echarts/lib/chart/line";
import "echarts/lib/chart/bar";
import "echarts/lib/component/tooltip";
import "echarts/lib/component/toolbox";
import "echarts/lib/component/polar";
import "echarts/lib/component/legend";
import "echarts/lib/component/title";
import "echarts/lib/component/grid";
import ilabLayout from "@/components/layout";
import api from "@/api";
import columns from "@/utils/columns.js";
import utils from "@/utils/utils";

export default {
  name: "requestApprove-static",
  components: {
    "v-chart": ECharts,
    ilabLayout
  },
  data() {
    return {
      appPrefix: process.env.VUE_APP_prefix,
      name: "1",
      total2: 0,
      total3: 0,
      total4: 0,
      breadcrumbs: [
        {
          txt: this.$i18n.t("nav.requestStatistic")
        }
      ],
      condition1: "",
      projectList: [],
      project: [],
      type: 1,
      data2: [],
      data3: [],
      data4: [],
      categoryCode: "",
      materielTypes: [],
      requestStatistic: {
        title: {
          text: this.$i18n.t("nav.requestStatistic")
        },
        color: [
          "#2f80e7",
          "#564aa3",
          "#2b957a",
          "#1797be",
          "#91c7ae",
          "#749f83",
          "#ca8622",
          "#bda29a",
          "#6e7074",
          "#546570",
          "#c4ccd3"
        ],
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: []
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true
        },
        toolbox: {
          feature: {
            saveAsImage: {}
          }
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: []
        },
        yAxis: {
          type: "value"
        },
        series: []
      },
      requestColumns: [
        columns.RequestCode(this.$i18n.t("columns.requestCode")),
        columns.Barcode(this.$i18n.t("columns.barcode")),
        columns.ChinName(this.$i18n.t("form.chinName")),
        columns.CASNumber(this.$i18n.t("columns.CASNumber")),
        columns.RequestCode(this.$i18n.t("columns.requestCode")),
        columns.Requester(this.$i18n.t("columns.requester")),
        columns.RequestQuantity(this.$i18n.t("columns.requestQuantity")),
        columns.EstimatedAmount(this.$i18n.t("columns.estimatedAmount")),
        columns.RequestDate(this.$i18n.t("columns.requestDate")),
        columns.BottleType(this.$i18n.t("columns.bottleType")),
        columns.ProjectCode(this.$i18n.t("columns.projectCode")),
        columns.Lab(this.$i18n.t("columns.lab")),
        columns.Phone(this.$i18n.t("columns.phone"))
      ],
      tkColumns: [
        columns.RequestCode(this.$i18n.t("columns.requestCode")),
        columns.Barcode(this.$i18n.t("columns.barcode")),
        columns.ChinName(this.$i18n.t("form.chinName")),
        columns.InitialQuantity(this.$i18n.t("columns.initialQuantity")),
        columns.CurrentQuantity(this.$i18n.t("columns.currentQuantity")),
        columns.Purity(this.$i18n.t("columns.purity")),
        columns.WarehouseName(this.$i18n.t("page.warehouse")),
        columns.ExpiryDate(this.$i18n.t("columns.expiryDate")),
        columns.CreateUser(this.$i18n.t("columns.requester")),
        columns.CreateTime(this.$i18n.t("columns.requestDate")),
        columns.Comment(this.$i18n.t("columns.comment"))
      ],
      bfColumns: [
        columns.Barcode(this.$i18n.t("columns.barcode")),
        columns.ChinName(this.$i18n.t("form.chinName")),
        columns.InitialQuantity(this.$i18n.t("columns.initialQuantity")),
        columns.CurrentQuantity(this.$i18n.t("columns.currentQuantity")),
        columns.Purity(this.$i18n.t("columns.purity")),
        columns.BottleType(this.$i18n.t("columns.bottleType")),
        columns.WarehouseName(this.$i18n.t("page.warehouse")),
        columns.Supplier(this.$i18n.t("page.supplier")),
        columns.UnitPrice(this.$i18n.t("columns.unitPrice")),
        columns.PONumber(this.$i18n.t("columns.poNumber")),
        columns.LotNumber(this.$i18n.t("columns.lotNumber")),
      ]
    };
  },
  methods: {
    search() {
      this.requestStatistic.series = [];
      this.name = "1";
      this.fetchRequestApproveData();
    },
    //加载物料类型
    async fetchMaterielType() {
      const resp = await api.cims.fetchMaterielType();
      this.materielTypes = resp.response;
    },
    /**
     * @param {string} tabName (审批类型)
     * @description 获取我的审批列表数据
     */
    async fetchRequestApproveData(pageIndex, index) {
      let resp = await api.cims.fetchRequestStatisticData1({
        categoryCode: this.categoryCode,
        projects: this.project.join(","),
        startDate: this.condition1[0] || utils.getFirstdayOfMonth(),
        endDate: this.condition1[1] || utils.getcurDate(),
        pageIndex
      });

      this.requestStatistic.legend.data = resp.response.Legend;
      this.requestStatistic.xAxis.data = resp.response.XAxisValues;
      resp.response.YAxisValues.map((item, index) => {
        this.requestStatistic.series.push({
          name: resp.response.Legend[index],
          type: this.type === 1 ? "line" : "bar",
          data: item
        });
      });
      if (index) {
        this[`data${index}`] = resp.response.DataDetails[index - 2];
      } else {
        this.data2 = resp.response.DataDetails[0];
        this.data3 = resp.response.DataDetails[1];
        this.data4 = resp.response.DataDetails[2];
        this.total2 = resp.response.Total[0];
        this.total3 = resp.response.Total[1];
        this.total4 = resp.response.Total[2];
      }
    },
    async loadProject() {
      let resp = await api.cims.fetchMyProjects();
      if (resp.code == process.env.VUE_APP_code) {
        this.projectList = resp.response;
      }
    }
  },
  mounted() {
    this.fetchMaterielType();
    this.loadProject();
    this.fetchRequestApproveData();
  }
};
</script>

<style lang="less" scoped>
.content {
  /deep/ .ivu-tabs-bar {
    margin-bottom: 50px;
  }

  /deep/ .ivu-tabs-nav {
    float: right;
  }
}
</style>
