<template>
<div id="page">
  
</div>
</template>
<script>
import axios from 'axios'
export default {
  name: "page",
  data() {
    return {

    }
  },
  mounted() {

  }
}
</script>
<style lang="less" scoped>
</style>
