import Vue from 'vue'
import Router from 'vue-router'
import App from './ketcher.vue'
new Vue({
  Router,
  render: h => h(App)
}).$mount('#app')