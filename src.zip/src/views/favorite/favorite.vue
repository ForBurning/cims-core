<template>
<ilab-layout :breadcrumbs="breadcrumbs" ref="layout">
    <div slot="content" class="content">
        <div class="page-info">
            <Row type="flex">
                <Col class="flex-1">
                <div class="chinName">我的收藏</div>
                <div class="chemName">My Favorite</div>
                </Col>
            </Row>
        </div>
        <div class="materiels" v-if="hasData > 0">
            <div class="materiel" v-for="item in materiels" :class="{'collapsible': !item.isExpend}" :key="item.CASNumber">
                <Row type="flex">
                    <Col class="img">
                    <img :src="structurePrefix + encodeURIComponent(item.Photo)" v-if="item.CategoryCode === CR" />
                    <img :src="materielPrefix + encodeURIComponent(item.Photo)" v-else />
                    </Col>
                    <Col class="detail">
                    <a :href="`${appPrefix}/materielDetail?id=${item.MaterielId}&isCompound=${item.CategoryCode === CR}`" class="title" v-html="`${item.ChinName}${item.ChemName ? '/' + item.ChemName : ''}`"></a>
                    <div class="sub-title" v-html="$t('page.alias') + `：${item.Alias || ''}`"></div>
                    <div class="keys" v-if="item.CategoryCode === CR">
                        <Row type="flex">
                            <Col>
                            <span class="key">{{$t('page.materielNumber')}}</span>
                            <span>：</span>
                            <span class="value" v-html="item.MaterielNumber"></span>
                            </Col>
                            <Col>
                            <span class="key">{{$t('columns.CASNumber')}}</span>
                            <span>：</span>
                            <span class="value" v-html="item.CASNumber"></span>
                            </Col>
                            <Col>
                            <span class="key w73">{{$t('columns.categoryName')}}</span>
                            <span>：</span>
                            <span class="value" v-html="item.CategoryName"></span>
                            </Col>
                        </Row>
                        <Row type="flex">
                            <Col>
                            <span class="key">{{$t('page.molecularFormula')}}</span>
                            <span>：</span>
                            <span class="value" v-html="item.MolecularFormula"></span>
                            </Col>
                            <Col>
                            <span class="key">{{$t('page.molecularWeight')}}</span>
                            <span>：</span>
                            <span class="value" v-html="item.MolecularWeight"></span>
                            </Col>
                        </Row>
                    </div>
                    <div class="keys" v-else>
                        <Row type="flex">
                            <Col>
                            <span class="key">{{$t('page.materielNumber')}}</span>
                            <span>：</span>
                            <span class="value" v-html="item.MaterielNumber"></span>
                            </Col>
                        </Row>
                        <Row type="flex">
                            <Col>
                            <span class="key">{{$t('columns.categoryName')}}</span>
                            <span>：</span>
                            <span class="value" v-html="item.CategoryName"></span>
                            </Col>
                        </Row>
                    </div>
                    </Col>
                    <Col class="action">
                    <span class="toggle" @click="toggleUpDown(item)">
                        {{item.isExpend ? $t('page.open'):$t('page.close') }}
                        <Icon :type="item.isExpend ? 'ios-arrow-down' : 'ios-arrow-up'" />
                    </span>
                    <span class="favorite" :class="{'favorited': item.isFavorit}" @click="toggleFavorite(item)">
                        <Icon :type="item.isFavorit ? 'md-star' : 'md-star-outline'" />{{$t('nav.favorite')}}
                    </span>
                    <div class="buttons">
                        <Button class="i-button ml10" @click="requestHistory(item)">{{$t('page.requesthistory')}}</Button>
                    </div>
                    </Col>
                </Row>
                <div class="stocks" v-show="item.isExpend">
                    <Table :columns="mcolumns" :data="item.stock" size="small" :width="1198">
                        <template slot-scope="{ row }" slot="Barcode">
                            <a :href="`${appPrefix}/reagentDetail?id=${row.Barcode}&materielId=${row.MaterielId}`" v-html="row.Barcode"></a>
                            <span v-html="isExpiry(row.ExpiryDate)"></span>
                        </template>
                        <template slot-scope="{ row }" slot="BottleType">
                            <span class="text-dot" v-html="row.BottleType"></span>
                        </template>
                        <template slot-scope="{ row }" slot="BottleName">
                            <span class="text-dot" v-html="row.BottleName"></span>
                        </template>
                        <template slot-scope="{ row }" slot="CurrentQuantity">{{ row.CurrentQuantity + row.Unit}}</template>
                        <template slot-scope="{ row }" slot="Sublocation">
                            <span class="text-dot" v-html="row.Sublocation"></span>
                        </template>
                        <template slot-scope="{ row }" slot="CatalogNumber">
                            <span class="text-dot" v-html="row.CatalogNumber"></span>
                        </template>
                        <template slot-scope="{ row }" slot="LotNumber">
                            <span class="text-dot" v-html="row.LotNumber"></span>
                        </template>
                        <template slot-scope="{ row }" slot="Supplier">
                            <span class="text-dot" v-html="row.Supplier"></span>
                        </template>
                        <template slot-scope="{ row }" slot="Action">
                            <shopping-ball targetId="sliderCart" @click="submitRequest(row, $event)">
                                <Button class="i-button" :disabled="row.disabled">{{$t('nav.request')}}</Button>
                            </shopping-ball>
                            <Button class="i-button" :to="`${appPrefix}/applicant/add?id=${row.Barcode}&type=3`">{{$t('nav.applicant')}}</Button>
                        </template>
                    </Table>
                    <div class="no-applicant-data" v-show="item.isExpend&&item.showNoData&&item.stock.length==0">{{$t('page.noMaterielFind')}}</div>
                    <div class="more-applicant-data" style="cursor:default;" v-show="item.isExpend&&item.showNoData&&item.stock.length>0">{{$t('page.load')}}（ {{item.stock.length}}/{{item.total}} ）</div>
                    <div class="more-applicant-data" v-show="item.isExpend&&!item.showNoData" @click="fetchAvailableBottleData(item)">{{$t('page.loadMore')}}（ {{item.stock.length}}/{{item.total}} ）</div>
                </div>
            </div>
            <Page :total="mtotal" show-total :page-size="30" @on-change="fetchMaterielsData" v-show="mtotal > 0" />
        </div>
        <div v-else>
            <div class="no-data">
                <img src="@/assets/img/no-data.png" alt />
                <span>{{$t('page.noFavorite')}}</span>
            </div>
        </div>

        <ilab-modal :title="$t('page.requesthistory')" :footer-hide="true" ref="requestHistory" :width="1000">
            <Table :columns="columns" :data="data" size="small">
                <template slot-scope="{ row }" slot="RequestQuantity">{{ row.RequestQuantity + row.RequestUnit}}</template>
                <template slot-scope="{ row }" slot="EstimatedAmount">{{ row.EstimatedAmount + row.RequestUnit}}</template>
                <template slot-scope="{ row }" slot="Action">
                    <a :href="`${appPrefix}/applicant/add?id=${row.Barcode}&type=3`">{{$t('nav.applicant')}}</a>
                </template>
            </Table>
            <Page :total="total" show-total :page-size="10" @on-change="fetchRequestHistory" />
        </ilab-modal>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from "@/components/layout.vue";
import ilabModal from "@/components/modal.vue";
import shoppingBall from "@/components/shoppingBall.vue";
import api from "@/api";
import utils from "@/utils/utils";

export default {
    name: "favorite-page",
    components: {
        ilabLayout,
        ilabModal,
        shoppingBall
    },
    data() {
        return {
            appPrefix: process.env.VUE_APP_prefix,
            structurePrefix: process.env.VUE_APP_structure_img_url,
            materielPrefix: process.env.VUE_APP_materiel_img_url,
            breadcrumbs: [{
                txt: this.$i18n.t('nav.myFavorite')
            }],
            iminentExpirationDay: "",
            isMoreUp1: false,
            isMoreUp2: false,
            materielTypes: [],
            warehouses: [],
            suppliers: [{
                Name: this.$i18n.t("page.all"),
                Code: "",
                active: true
            }],
            keywords: "",
            CR: process.env.VUE_APP_CR,
            warehouse: "",
            supplier: "",
            searchType: "request",
            molecule: "",
            materiels: [],
            filterType: "",
            curTime: "",
            curMateriel: {},
            mcolumns: [{
                    slot: "Barcode",
                    title: this.$i18n.t("columns.barcode"),
                    width: 190
                },
                {
                    slot: "BottleName",
                    title: this.$i18n.t("columns.bottleName")
                },
                {
                    slot: "BottleType",
                    title: this.$i18n.t("columns.bottleType"),
                    width: 100,
                    sortable: true
                },
                {
                    key: "Purity",
                    title: this.$i18n.t("columns.purity"),
                    sortable: true
                },
                {
                    slot: "CurrentQuantity",
                    title: this.$i18n.t("columns.currentQuantity"),
                    sortable: true
                },
                {
                    key: "WarehouseName",
                    title: this.$i18n.t("page.warehouse"),
                },
                {
                    slot: "Sublocation",
                    title: this.$i18n.t("columns.sublocation"),
                },
                {
                    slot: "CatalogNumber",
                    title: this.$i18n.t("columns.catalogNumber"),
                    sortable: true
                },
                {
                    slot: "LotNumber",
                    title: this.$i18n.t("columns.lotNumber"),
                    sortable: true
                },
                {
                    slot: "Supplier",
                    title: this.$i18n.t("page.supplier")
                },
                {
                    slot: "Action",
                    title: this.$i18n.t("columns.operation"),
                    width: 160,
                    align: "center"
                }
            ],
            columns: [{
                    key: "BottleName",
                    title: this.$i18n.t("columns.bottleName")
                },
                {
                    key: "Requester",
                    title: this.$i18n.t("columns.requester")
                },
                {
                    key: "Phone",
                    title: this.$i18n.t("columns.phone")
                },
                {
                    key: "Barcode",
                    title: this.$i18n.t("columns.barcode"),
                },
                {
                    slot: "RequestQuantity",
                    title: this.$i18n.t("columns.requestQuantity"),
                    formatter: function (val, row, index) {
                        return val + row.RequestUnit;
                    }
                },
                {
                    slot: "EstimatedAmount",
                    title: this.$i18n.t("columns.estimatedAmount"),
                    formatter: function (val, row, index) {
                        return val + row.RequestUnit;
                    }
                },
                {
                    key: "RequestDate",
                    title: this.$i18n.t("columns.requestDate")
                },
                {
                    slot: "Action",
                    title: this.$i18n.t("columns.operation"),
                    formatter: function (val, row, index) {
                        return '<a href="/applicant/add?id=' + row.Barcode + '" >' + this.$i18n.t("nav.applicant") + '</a>';
                    }
                }
            ],
            data: [],
            total: 0,
            mtotal: 0,
            materielIds: [],
            molSerch: false,
            hasData: true
        };
    },
    methods: {
        //收起展开
        toggleUpDown(item) {
            item.isExpend = !item.isExpend;
            item.pageIndex = 0;
            item.stock = [];
            item.total = 0;
            this.fetchAvailableBottleData(item);
        },
        //获取物料近效期提醒时间
        async getIminentExpirationDay() {
            const resp = await api.cims.getOrganizationConfig("iminentExpirationDay");
            if (resp.code == process.env.VUE_APP_code) {
                this.iminentExpirationDay = resp.response;
            } else {
                this.$Message.error(resp.message);
            }
        },
        //加载物料
        async fetchMaterielsData(pageIndex = 1) {
            this.$Spin.show();
            const resp = await api.cims.fetchFavoriteData({
                pageIndex
            });

            if (resp.code == process.env.VUE_APP_code) {
                this.hasData = true;

                resp.rows.map(item => {
                    item.isFavorit = true;
                    item.isExpend = false;
                    item.showNoData = false;
                    item.pageIndex = 0;
                    item.total = 0;
                    item.stock = [];
                });

                this.materiels = resp.rows;
            } else {
                this.hasData = false;
            }
            this.$Spin.hide();
            this.mtotal = resp.total;
        },
        //展开时，加载库存
        async fetchAvailableBottleData(item) {
            item.pageIndex++;
            const resp = await api.cims.fetchAvailableBottleData({
                materielId: item.MaterielId,
                pageIndex: item.pageIndex
            });
            if (resp.code == process.env.VUE_APP_code) {
                item.stock = item.stock.concat(resp.rows);
                item.showNoData = item.stock.length === item.total;
                item.total = resp.total;
            } else {
                item.showNoData = true;
            }
        },
        //收藏-切换
        async toggleFavorite(item) {
            const resp = await api.cims.cancelFavorite(item.MaterielId);
            if (resp.code == process.env.VUE_APP_code) {
                this.$Message.success(resp.message);
                this.$set(item, "isFavorit", true);
                this.fetchMaterielsData();
            } else {
                this.$Message.error(resp.message);
            }
            this.$set(item, "isFavorit", false);
        },
        //判断近效期
        isExpiry(date) {
            const expireDateState = [this.$i18n.t("page.overExpiryTime"),this.$i18n.t("page.withExpiryTime"),this.$i18n.t("page.inExpiryTime")];
            return utils.isExpiry(this.iminentExpirationDay, date, expireDateState);
        },
        //领用
        async submitRequest(stock, fly) {
            this.$set(stock, "disabled", true);
            const resp = await api.cims.submitRequest({
                amount: 300,
                foreignKeyId: stock.WarehouseId,
                fKID: stock.ID,
                chinName: stock.ChinName,
                compoundId: stock.CompoundId,
                materielId: stock.MaterielId,
                requestType: 1,
                requestUnit: stock.Unit,
                requestQuantity: stock.CurrentQuantity,
                barcode: stock.Barcode,
                lab: utils.getCimsInfo().UserInfo.LabName,
                phone: utils.getUcInfo().AccountInfo.MobilePhone,
                warehouseId: stock.WarehouseId,
                bottleName: stock.BottleName,
                casNumber: stock.CASNumber,
                mdlNumber: stock.MDLNumber
            });
            if (resp.code == process.env.VUE_APP_code) {
                fly();
                this.$refs.layout.setCartCount();
            } else {
                this.$Message.warning({
                    content: resp.message,
                    onClose: () => {
                        this.$set(stock, "disabled", false);
                    }
                });
            }
        },
        //查看领用历史
        async requestHistory(item) {
            this.curMateriel = item;
            this.fetchRequestHistory();
            this.$refs.requestHistory.show();
        },
        async fetchRequestHistory(pageIndex = 1) {
            const resp = await api.cims.fetchRequestHistory({
                pageIndex,
                materielId: this.curMateriel.MaterielId
            });
            if (resp.code == process.env.VUE_APP_code) {
                this.data = resp.rows;
                this.total = resp.total;
            } else {
                this.data = [];
            }
        }
    },
    async mounted() {
        this.curTime = utils.getTimesamp();
        await this.getIminentExpirationDay();
        await this.fetchMaterielsData();
    }
};
</script>

<style lang="less" scoped>
.content {
    .text-dot {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        display: block;
    }

    .materiels {
        .materiel {
            border: 1px solid #ddd;
            border-bottom: none;
            margin-top: 15px;

            &.collapsible {
                border-bottom: 1px solid #ddd;
            }

            >.ivu-row-flex {
                padding: 12px;
            }

            .img {
                height: 130px;
                width: 130px;
                padding: 5px;
                border: 1px solid #bbb;

                img {
                    max-width: 100%;
                    max-height: 100%;
                    position: relative;
                    top: 50%;
                    -webkit-transform: translateY(-50%);
                    transform: translateY(-50%);
                }
            }

            .detail {
                width: 894px;
                padding: 0 12px;

                .title {
                    font-size: 16px;
                    line-height: 24px;
                    .text-dot;
                    width: 100%;
                }

                .sub-title {
                    color: #101010;
                    font-size: 13px;
                    margin: 9px 0;
                    .text-dot;
                }

                .ivu-row-flex {
                    margin-top: 12px;

                    .ivu-col {
                        flex: 1;
                        height: 18px;
                        line-height: 18px;

                        span {
                            float: left;
                        }
                    }

                    .key {
                        display: inline-block;
                        min-width: 50px;
                        height: 18px;
                        overflow: hidden;
                        text-align: justify;

                        &:after {
                            display: inline-block;
                            width: 100%;
                            content: "";
                        }

                        &.w73 {
                            // width: 79px;
                        }
                    }

                    .value {
                        .text-dot;
                        padding-left: 6px;
                        // width: 190px;
                        height: 18px;
                    }
                }
            }

            .action {
                height: 130px;
                width: 150px;
                position: relative;
                text-align: center;

                span {
                    display: inline-block;
                    width: 50%;
                    font-size: 12px;
                    cursor: pointer;

                    &:hover {
                        color: #1388ff;
                    }

                    &.toggle {
                        margin-top: 55px;
                        text-align: right;
                    }

                    &.favorite {
                        &.favorited {
                            .ivu-icon {
                                color: #ff9800;

                                &:before {
                                    color: #ff9800;
                                }
                            }
                        }

                        i {
                            display: block;
                            color: #c3c3c3;
                            font-size: 24px;
                        }
                    }
                }

                .buttons {
                    margin-top: 28px;
                }
            }
        }

        .stocks {
            .ivu-table-wrapper {
                border: none;

                /deep/ .ivu-table {
                    overflow: inherit;
                }

                /deep/ .ivu-table-tbody .ivu-table-column-center .ivu-table-cell {
                    overflow: inherit;
                }
            }

            /deep/ .ivu-table:after {
                display: none;
            }

            /deep/ .light-tag {
                color: #e51c22;
            }

            /deep/ .ivu-table-tbody {
                td {
                    border-bottom: 1px dashed #e8eaec;
                }
            }
        }

        .i-button {
            border: 1px solid #ff6100;
            color: #ff6100;
            transition: 0.4s;
            height: 27px;
            line-height: 14px;
            border-radius: 2px;
            margin: 0 6px 0 0;

            &:last-child {
                margin-right: 0;
            }

            &.ml10 {
                margin-left: 20px;
            }

            &:disabled {
                border-color: #999;
                background-color: #dfdfdf;
                color: #9f9f9f;
            }

            &:not(:disabled):hover {
                background-color: #ff6100;
                color: #ffffff;
            }
        }
    }

    .no-data {
        margin: 50px auto 0;
        text-align: center;
        line-height: 26px;
        font-size: 15px;

        img {
            width: 170px;
            height: 130px;
        }

        span {
            position: relative;
            top: -30px;
            left: 30px;
            text-align: left;
            display: inline-block;
            width: 370px;
        }
    }
}
</style>
