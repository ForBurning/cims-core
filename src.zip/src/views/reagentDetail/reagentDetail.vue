<template>
<ilab-layout :breadcrumbs="breadcrumbs">
    <div slot="content" class="content reagent-detail">
        <div class="page-info">
            <div class="chinName">物料详情</div>
            <div class="chemName">Material Detail</div>
        </div>
        <div class="detail">
            <div class="category">{{$t('page.materialDetail')}}</div>
            <div class="title">
                <img src="@/assets/img/d1.png" />
                {{$t('page.inventoryInfo')}}
            </div>
            <Row type="flex">
                <Col span="8">
                <span class="key">{{$t('columns.barcode')}}：</span>
                {{dto.BottleInfo.Barcode}}
                </Col>
                <Col span="8">
                <span class="key">{{$t('columns.bottleName')}}：</span>
                {{dto.BottleInfo.BottleName}}
                </Col>
                <Col span="8">
                <span class="key">{{$t('page.warehouse')}}：</span>
                {{dto.BottleInfo.WarehouseName}}
                </Col>
            </Row>
            <Row type="flex">
                <Col span="8">
                <span class="key">{{$t('columns.sublocation')}}：</span>
                {{dto.BottleInfo.Sublocation}}
                </Col>
                <Col span="8">
                <span class="key">{{$t('columns.initialQuantity')}}：</span>
                {{dto.BottleInfo.InitialQuantity+dto.BottleInfo.Unit }}
                </Col>
                <Col span="8">
                <span class="key">{{dto.BottleInfo.CategoryCode === CR ? $t('columns.purity'):$t('columns.purity1')}}：</span>
                {{dto.BottleInfo.Purity}}
                </Col>
            </Row>
            <Row type="flex">
                <Col span="8">
                <span class="key">{{$t('columns.currentQuantity')}}：</span>
                {{dto.BottleInfo.CurrentQuantity+dto.BottleInfo.Unit}}
                </Col>
                <Col span="8">
                <span class="key">{{$t('columns.bottleType')}}：</span>
                {{dto.BottleInfo.BottleType }}
                </Col>
                <Col span="8">
                <span class="key">{{$t('columns.expiryDate')}}：</span>
                {{dto.BottleInfo.ExpiryDate.substring(0,10) }}
                <span v-html="isExpiry(dto.BottleInfo.ExpiryDate)"></span>
                </Col>
            </Row>
            <Row type="flex" class="border-bottom">
                <Col span="8">
                <span class="key">{{$t('columns.origin')}}：</span>
                {{dto.BottleInfo.OriginDescription}}
                </Col>
            </Row>

            <div class="title">
                <img src="@/assets/img/d4.png" />
                {{$t('btn.purchaseInfo')}}
            </div>
            <Row type="flex">
                <Col span="8">
                <span class="key">{{$t('columns.poNumber')}}：</span>
                {{dto.BottleInfo.PONumber}}
                </Col>
                <Col span="8">
                <span class="key">{{$t('columns.price')}}：</span>
                {{dto.BottleInfo.UnitPrice}}
                </Col>
                <Col span="8">
                <span class="key">{{$t('page.supplier')}}：</span>
                {{dto.BottleInfo.Supplier}}
                </Col>
            </Row>
            <Row type="flex">
                <Col span="8">
                <span class="key">{{$t('columns.lotNumber')}}：</span>
                {{dto.BottleInfo.LotNumber}}
                </Col>
                <Col span="8">
                <span class="key">{{$t('columns.producer')}}：</span>
                {{dto.BottleInfo.Producer }}
                </Col>
                <Col span="8">
                <span class="key">{{$t('columns.catalogNumber')}}：</span>
                {{dto.BottleInfo.CatalogNumber }}
                </Col>
            </Row>
            <Row type="flex" class="border-bottom">
                <Col span="8">
                <span class="key">{{$t('columns.comment')}}：</span>
                {{dto.BottleInfo.Comments}}
                </Col>
            </Row>

            <div class="title">
                <img src="@/assets/img/d1.png" />
                {{$t('page.materielInfo')}}
            </div>
            <Row type="flex" class="border-bottom" :class="{'no-border': dto.BottleInfo.CategoryCode !== CR}">
                <Col>
                <div class="struct-img">
                    <div v-if="dto.BottleInfo.CategoryCode === CR" :style="{backgroundImage: `url(${addRandom2Url(structurePrefix + dto.MaterielInfo.Photo)})`}"></div>
                    <div v-else :style="{backgroundImage: `url(${addRandom2Url(materielPrefix + dto.MaterielInfo.Photo)})`}"></div>
                </div>
                </Col>
                <Col class="flex-1" v-if="dto.BottleInfo.CategoryCode === CR">
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('form.chinName')}}：</span>
                    {{dto.CompoundInfo.ChinName}}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('form.chemName')}}：</span>
                    {{dto.CompoundInfo.ChemName}}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('form.chinAlias')}}：</span>
                    {{dto.CompoundInfo.Alias}}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('form.chemAlias')}}：</span>
                    {{dto.CompoundInfo.ChemAlias}}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="8">
                    <span class="key">{{$t('page.materielNumber')}}：</span>
                    {{dto.CompoundInfo.MaterielNumber }}
                    </Col>
                    <Col span="8">
                    <span class="key">{{$t('columns.CASNumber')}}：</span>
                    {{dto.CompoundInfo.CASNumber}}
                    </Col>
                    <Col span="8">
                    <span class="key">{{$t('columns.mdl')}}：</span>
                    {{dto.CompoundInfo.MDLNumber }}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="8">
                    <span class="key">{{$t('page.molecularWeight')}}：</span>
                    {{dto.CompoundInfo.MolecularWeight }}
                    </Col>
                    <Col span="8">
                    <span class="key">{{$t('page.molecularFormula')}}：</span>
                    {{dto.CompoundInfo.MolecularFormula}}
                    </Col>
                    <Col span="8">
                    <span class="key">{{$t('page.accurateMass')}}：</span>
                    {{dto.CompoundInfo.ExactMass }}
                    </Col>
                </Row>

                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('page.appearance')}}：</span>
                    {{dto.CompoundInfo.AppearanceCharacter}}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('page.stereoisomerDescription')}}：</span>
                    {{dto.CompoundInfo.SteroisomerDesc}}
                    </Col>
                </Row>
                </Col>
                <Col class="flex-1" v-else>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('page.materielNumber')}}：</span>
                    {{dto.MaterielInfo.MaterielNumber}}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('form.chinName')}}：</span>
                    {{dto.MaterielInfo.ChinName}}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('form.chinAlias')}}：</span>
                    {{dto.MaterielInfo.Alias }}
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span="24">
                    <span class="key">{{$t('columns.categoryName')}}：</span>
                    {{dto.MaterielInfo.CategoryName}}
                    </Col>
                </Row>
                <Row type="flex" v-if="dto.BottleInfo.CategoryCode !== CR">
                    <neo-custom-form :domain="cimsmanage" :data="customFormData" mode="view" hasColon></neo-custom-form>
                </Row>
                </Col>
            </Row>
            <div class="title" v-if="dto.BottleInfo.CategoryCode === CR">
                <img src="@/assets/img/d2.png" />
                {{$t('page.chemProperty')}}
            </div>
            <Row type="flex" v-if="dto.BottleInfo.CategoryCode === CR">
                <Col span="6">
                <span class="key">{{$t('page.density')}}：</span>
                {{dto.CompoundInfo.MeltlingPoint}}
                </Col>
                <Col span="6">
                <span class="key">{{$t('page.meltlingPoint')}}：</span>
                {{dto.CompoundInfo.FlashPoint }}
                </Col>
                <Col span="6">
                <span class="key">{{$t('page.boilingPoint')}}：</span>
                {{dto.CompoundInfo.RefractiveIndex }}
                </Col>
                <Col span="6">
                <span class="key">{{$t('page.flashPoint')}}：</span>
                {{dto.CompoundInfo.VapourPressure }}
                </Col>
            </Row>
            <Row type="flex" class="border-bottom" v-if="dto.BottleInfo.CategoryCode === CR">
                <Col span="24">
                <span class="key">{{$t('page.stability')}}：</span>
                {{dto.CompoundInfo.Stability}}
                </Col>
            </Row>

            <div class="title" v-if="dto.BottleInfo.CategoryCode === CR">
                <img src="@/assets/img/d3.png" />{{$t('page.sAndr')}}
            </div>
            <Row type="flex" v-if="dto.BottleInfo.CategoryCode === CR">
                <Col span="24">
                <span class="key">{{$t('page.incompatibilityInfo')}}：</span>
                {{dto.IncompatibilityInfo && dto.IncompatibilityInfo.Name}}
                </Col>
                <Col span="24">
                <span class="key">{{$t('page.storageCondition')}}：</span>
                {{dto.CompoundInfo.StorageCondition}}
                </Col>
                <Col span="4">
                <span class="key">{{$t('page.toxic')}}：</span>
                {{dto.CompoundInfo.Toxic > 0 ? $t('page.yes') : $t('page.no')}}
                </Col>
                <Col span="4">
                <span class="key">{{$t('page.pretoxic')}}：</span>
                {{dto.CompoundInfo.Pretoxic > 0 ? $t('page.yes') : $t('page.no') }}
                </Col>
                <Col span="4">
                <span class="key">{{$t('page.dangerous')}}：</span>
                {{dto.CompoundInfo.Dangerous > 0 ? $t('page.yes') : $t('page.no') }}
                </Col>
            </Row>
            <Row type="flex" v-if="dto.BottleInfo.CategoryCode === CR">
                <Col span="24">
                <span style="float: left;">{{$t('page.gb')}}：</span>
                <span v-for="item in dto.CompoundInfo&&dto.CompoundInfo.Symbol ? dto.CompoundInfo.Symbol.split(',') : []" :key="item">
                    <img src="@/assets/img/爆炸物.png" v-if="item === $t('page.gb1')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/腐蚀性.png" v-else-if="item === $t('page.gb2')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/高压气体.png" v-else-if="item === $t('page.gb3')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/环境危害.png" v-else-if="item === $t('page.gb4')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/健康危害.png" v-else-if="item === $t('page.gb5')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/氧化物.png" v-else-if="item === $t('page.gb6')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/易燃物.png" v-else-if="item === $t('page.gb7')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/有毒物质.png" v-else-if="item === $t('page.gb8')" class="risk" style="margin-right:6px;" />
                    <img src="@/assets/img/有害.png" v-else-if="item === $t('page.gb9')" class="risk" style="margin-right:6px;" />
                </span>
                </Col>
            </Row>
            <Row type="flex" v-if="dto.BottleInfo.CategoryCode === CR">
                <Col span="24">
                <span class="key">{{$t('page.om')}}：</span>
                {{dto.CompoundInfo.RiskSymbol}}
                </Col>
            </Row>
            <Row type="flex" v-if="dto.BottleInfo.CategoryCode === CR">
                <Col span="24">
                <span class="key">{{$t('page.om1')}}：</span>
                {{dto.CompoundInfo.RiskPhrases}}
                </Col>
            </Row>
            <Row type="flex" v-if="dto.BottleInfo.CategoryCode === CR">
                <Col span="24">
                <span class="key">{{$t('page.om2')}}：</span>
                {{dto.CompoundInfo.HazardInfo}}
                </Col>
            </Row>
            <Row type="flex" v-if="dto.BottleInfo.CategoryCode === CR">
                <Col span="24">
                <span class="key">{{$t('page.om3')}}：</span>
                {{dto.CompoundInfo.SafetyPhrases}}
                </Col>
            </Row>
            <Row type="flex" v-if="dto.BottleInfo.CategoryCode === CR">
                <Col span="24">
                <span class="key">{{$t('page.om4')}}：</span>
                {{dto.CompoundInfo.WarningStatement}}
                </Col>
            </Row>
            <Row type="flex" class="border-bottom" v-if="dto.BottleInfo.CategoryCode === CR">
                <Col span="24">
                <span class="key">{{$t('page.om5')}}：</span>
                {{dto.CompoundInfo.StorageRequirement}}
                </Col>
            </Row>

            <div class="title" v-if="dto.BottleInfo.CategoryCode === CR">
                <img src="@/assets/img/d5.png" />MSDS
            </div>
            <Row type="flex" class="border-bottom" v-if="dto.BottleInfo.CategoryCode === CR">
                <Col span="24">
                <span class="key">MSDS：</span>
                <a :href="dto.CompoundInfo.MSDS.replace(/#/g, '%23')" v-if="dto.CompoundInfo.MSDS" target="_blank">{{dto.CompoundInfo.MSDS.substr(dto.CompoundInfo.MSDS.lastIndexOf('/')+1)}}</a>
                <span v-else>{{$t('page.not')}}</span>
                </Col>
            </Row>

            <div class="title" v-if="dto.BottleInfo.CategoryCode === CR">
                <img src="@/assets/img/d2.png" />
                {{$t('page.toxicityInfo')}}
            </div>
            <Row type="flex" class="border-bottom" v-if="dto.BottleInfo.CategoryCode === CR">
                <Col span="24">
                <span class="key">{{$t('page.toxicityInfo')}}：</span>
                <a :href="dto.CompoundInfo.ToxicityInfo.replace(/#/g, '%23')" v-if="dto.CompoundInfo.ToxicityInfo" target="_blank">{{dto.CompoundInfo.ToxicityInfo.substr(dto.CompoundInfo.ToxicityInfo.lastIndexOf('/')+1)}}</a>
                <span v-else>{{$t('page.not')}}</span>
                </Col>
            </Row>

            <div class="title" v-if="dto.BottleInfo.CategoryCode === CR">
                <img src="@/assets/img/d4.png" />{{$t('page.other')}}
            </div>
            <Row type="flex" class="border-bottom no-border" v-if="dto.BottleInfo.CategoryCode === CR">
                <Col span="6">
                <span class="key">{{$t('page.customNumber')}}：</span>
                {{dto.CompoundInfo.SelfNumber}}
                </Col>
                <Col span="6">
                <span class="key">{{$t('form.waste19')}}：</span>
                {{dto.CompoundInfo.Origin }}
                </Col>
                <Col span="6">
                <span class="key">{{$t('page.OHS1')}}：</span>
                {{dto.CompoundInfo.OHSNumber }}
                </Col>
                <Col span="6">
                <span class="key">{{$t('page.OHS2')}}：</span>
                {{dto.CompoundInfo.OHSName }}
                </Col>
            </Row>

            <div class="category">{{$t('page.requestInfo')}}</div>
            <Table :columns="columns" :data="dto.RequestInfo || []">
                <template slot-scope="{ row }" slot="Action">
                    <Button type="primary" size="small" @click="openApplicantHistory(row.StateHistory)">{{$t('page.requesthistory')}}</Button>
                    <Button type="primary" size="small" @click="openApproveHistory(row.ApprovalHistory)">{{$t('page.approvehistory')}}</Button>
                </template>
            </Table>

            <Modal :title="$t('page.requesthistory')" v-model="modal1" footer-hide :width="600">
                <Table :columns="columns1" :data="data1"></Table>
            </Modal>

            <Modal :title="$t('page.approvehistory')" v-model="modal2" footer-hide :width="600">
                <Table :columns="columns2" :data="data2"></Table>
            </Modal>

            <div class="category">{{$t('page.lifeCycle')}}</div>
            <Timeline>
                <TimelineItem v-for="item in dto.LifecycleInfo" :key="item">
                    <p class="content">{{item.Comment.replace($t('page.library'), $t('page.putIn'))}}</p>
                    <p class="time">{{item.CreateTime}}</p>
                </TimelineItem>
            </Timeline>
        </div>
    </div>
</ilab-layout>
</template>

<script>
import ilabLayout from "@/components/layout.vue";
import neoCustomForm from "@neotrident/neo-custom-form";
import utils from "@/utils/utils";
import api from "@/api";
import Vue from "vue";
import Vddl from "vddl"
Vue.use(Vddl);
import Vuebar from 'vuebar'
Vue.use(Vuebar);

export default {
    name: "reagent-page",
    components: {
        ilabLayout,
        neoCustomForm
    },
    created() {
        this.materielId = utils.getParams("materielId") * 1;
        this.id = utils.getParams("id");
    },
    data() {
        return {
            breadcrumbs: [{
                txt: this.$i18n.t("page.materialDetail")
            }],
            id: "",
            materielId: "",
            structurePrefix: process.env.VUE_APP_structure_img_url,
            materielPrefix: process.env.VUE_APP_materiel_img_url,
            cimsmanage: process.env.VUE_APP_cimsmanage,
            CR: process.env.VUE_APP_CR,
            iminentExpirationDay: "",
            dto: {
                BottleInfo: {
                    ExpiryDate: "",
                    PartialDate: "",
                    CategoryCode: process.env.VUE_APP_CR
                },
                CompoundInfo: {
                    Symbol: "",
                    MeltlingPoint: "",
                    Stability: ""
                },
                MaterielInfo: {}
            },
            modal1: false,
            modal2: false,
            data: [],
            data1: [],
            data2: [],
            columns: [{
                    title: this.$i18n.t("columns.requestCode"),
                    key: "RequestCode"
                },
                {
                    title: this.$i18n.t("form.projectCode"),
                    key: "ProjectCode"
                },
                {
                    title: this.$i18n.t("columns.requestQuantity"),
                    key: "RequestQuantity"
                },
                {
                    title: this.$i18n.t("columns.requestUnit"),
                    key: "RequestUnit"
                },
                {
                    title: this.$i18n.t("columns.requester"),
                    key: "Requester"
                },
                {
                    title: this.$i18n.t("columns.requestDate"),
                    key: "RequestDate",
                    width: 180
                },
                {
                    title: this.$i18n.t("columns.operation"),
                    slot: "Action",
                    align: "center",
                    width: 200
                }
            ],
            columns1: [{
                    title: this.$i18n.t("columns.requester"),
                    key: "CreateUser"
                },
                {
                    title: this.$i18n.t("columns.createTime"),
                    key: "CreateTime",
                    width: 180
                },
                {
                    title: this.$i18n.t("columns.state"),
                    key: "RequestStateName"
                },
                {
                    title: this.$i18n.t("columns.comment"),
                    key: "Comment"
                }
            ],
            columns2: [{
                    title: this.$i18n.t("columns.approveUsersNames"),
                    key: "ApproveUser"
                },
                {
                    title: this.$i18n.t("columns.approveTime"),
                    key: "ApproveTime",
                    width: 180
                },
                {
                    title: this.$i18n.t("columns.state"),
                    key: "ApproveStateName"
                },
                {
                    title: this.$i18n.t("form.approvalIdea"),
                    key: "ApproveReason",
                    render: (h, params) => {
                        return h('div', params.row.ApproveState ? (params.row.ApproveState === -1 ? params.row.ApproveReason : this.$i18n.t("btn.yes")) : '')
                    }
                }
            ],
            customFormData: []
        };
    },
    methods: {
        //获取物料近效期提醒时间
        async getIminentExpirationDay() {
            const resp = await api.cims.getOrganizationConfig("iminentExpirationDay");
            if (resp.code == process.env.VUE_APP_code) {
                this.iminentExpirationDay = resp.response;
            } else {
                this.$Message.error(resp.message);
            }
        },
        //判断近效期
        isExpiry(date) {
            const expireDateState = [this.$i18n.t("page.overExpiryTime"),this.$i18n.t("page.withExpiryTime"),this.$i18n.t("page.inExpiryTime")];
            return utils.isExpiry(this.iminentExpirationDay, date, expireDateState);
        },
        //物料详情
        async getReagent() {
            if (this.id) {
                const resp = await api.cims.getReagent(this.id);
                if (resp.code == process.env.VUE_APP_code) {
                    this.dto = resp.response;
                    if (resp.response.MaterielDataInfo && resp.response.MaterielDataInfo.CustomColumnsValues) {
                        this.customFormData = JSON.parse(resp.response.MaterielDataInfo.CustomColumnsValues);
                    }
                }
            }
        },
        //领用历史
        openApplicantHistory(data) {
            this.data1 = data;
            this.modal1 = true;
        },
        //审批历史
        openApproveHistory(data) {
            this.data2 = data;
            this.modal2 = true;
        },
        //结构式图片URL添加随机数
        addRandom2Url: (url) => utils.addRandom2Url(url)
    },
    async mounted() {
        await this.getIminentExpirationDay();
        await this.getReagent();
    }
};
</script>

<style lang="less" scoped>
.content {
    .detail {
        border: 1px solid #ddd;
        padding: 0 30px 30px 30px;
        font-size: 15px;

        .category {
            font-size: 16px;
            font-weight: bold;
            display: block;
            margin: -1px -30px;
            border-top: 1px solid #ddd;
            border-bottom: 1px solid #ddd;
            padding: 8px 30px;
            margin-bottom: 30px;
        }

        .title {
            font-size: 16px;
            color: #3496ed;
            font-weight: bold;
            margin-bottom: 6px;

            img {
                position: relative;
                top: 3px;
                margin-right: 10px;
            }
        }

        .ivu-row-flex {
            padding-left: 25px;

            .key {
                display: inline-block;
                width: 120px;
                text-align: right;
            }

            &.border-bottom {
                border-bottom: 1px solid #ddd;
                margin-bottom: 20px;
                padding-bottom: 15px;

                &.no-border {
                    border-bottom: none;
                }
            }
        }

        .struct-img {
            text-align: center;
            border-right: 1px solid #ddd;
            margin-bottom: 24px;
            padding-right: 12px;
            width: 190px;

            div {
                background-position: center center;
                background-repeat: no-repeat;
                background-size: contain;
                height: 165px;
                margin-right: 12px;
            }
        }

        .ivu-col {
            padding: 8px 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .ivu-table-wrapper {
            margin-bottom: 35px;
        }

        .chinName {
            margin: 16px 0 6px 0;
            text-overflow: ellipsis;
            white-space: nowrap;
            overflow: hidden;
        }

        .time {
            margin-top: 8px;
        }

        .content {
            font-size: 14px;
        }

        .chemName {
            color: #a3a3a3;
            text-overflow: ellipsis;
            white-space: nowrap;
            overflow: hidden;
        }
    }
}
</style><style lang="less">
.reagent-detail {
    .neo-form {
        width: 100%;

        .neo-body {

            .form-row-item .component {
                padding-left: 16px;

                .component-title {
                    width: 120px;
                    padding-right: 6px;
                }
            }

            .component.container-row-item {
                padding-left: 0;
            }
        }
    }

}
</style>
