import axios from 'axios';
import utils from '@/utils/utils';
import enums from "@/utils/enums";
import bus from "@/utils/bus";


//取消请求
let CancelToken = axios.CancelToken;
//设置默认请求头，如果不需要可以取消这一步
axios.defaults.headers = {
	"X-Requested-With": "XMLHttpRequest"
};

axios.defaults.baseURL = process.env.VUE_APP_api;
// 开始设置请求 发起的拦截处理
// config 代表发起请求的参数的实体
axios.interceptors.request.use(config => {
	// 得到参数中的 requestName 字段，用于决定下次发起请求，取消对应的 相同字段的请求
	// 如果没有 requestName 就默认添加一个 不同的时间戳
	// 如果isAuth为true，则不附加header
	let requestName, isAuth = true;
	if (config.method === "post") {
		if (config.data && config.data.requestName) {
			requestName = config.data.requestName;
		} else {
			requestName = config.url;
		}
		isAuth = config.data && config.data.isAuth === false ? false : true;
	} else {
		if (config.params && config.params.requestName) {
			requestName = config.params.requestName;
		} else {
			requestName = config.url;
		}
		isAuth = config.params && config.params.isAuth === false ? false : true;
	}
	// 判断，如果这里拿到的参数中的 requestName 在上一次请求中已经存在，就取消上一次的请求
	// if (requestName) {
	// 	if (axios[requestName] && axios[requestName].cancel) {
	// 		axios[requestName].cancel();
	// 	}
	// 	config.cancelToken = new CancelToken(c => {
	// 		axios[requestName] = {};
	// 		axios[requestName].cancel = c;
	// 	});
	// }
	if (isAuth) {
		Object.assign(config.headers, utils.getHeader())
	}
	return config;
}, error => {
	return Promise.reject(error);
});
// 请求到结果的拦截处理
axios.interceptors.response.use(config => {
	// 返回请求正确的结果
	return config.data;
}, error => {
	//hard code -- 国际化errorMessage
	let errorMessage = '';
	if (error.response) {
		errorMessage = error.response.data;
		if (utils.getSystemLanguage() === 'en-US') {
			errorMessage = enums.errorMessage[errorMessage];
		}
	} else {
		errorMessage = error.message;
	}


	if (error.response.status == process.env.VUE_APP_noAuth_code) {
		setTimeout(() => {
			bus.$emit('boo', {modal: true, message: errorMessage});
		}, 1000);
	}

	return {code:error.response.status, message: errorMessage };
});
// 将axios 的 post 方法，绑定到 vue 实例上面的 $post
axios.$post = function (url, params) {
	return new Promise((resolve, reject) => {
		axios.post(url, params).then(res => {
			resolve(res);
		}).catch(err => {
			reject(err);
		});
	});
};
// 将axios 的 get 方法，绑定到 vue 实例上面的 $get
axios.$get = function (url, params) {
	return new Promise((resolve, reject) => {
		axios.get(url, {
			params: params
		}).then(res => {
			resolve(res); // 返回请求成功的数据 data
		}).catch(err => {
			reject(err);
		});
	});
};

// 将axios 的 delete 方法，绑定到 vue 实例上面的 $delete
axios.$delete = function (url, params) {
	return new Promise((resolve, reject) => {
		axios.delete(url, params).then(res => {
			resolve(res);
		}).catch(err => {
			reject(err);
		});
	});
};

// 将axios 的 put 方法，绑定到 vue 实例上面的 $put
axios.$put = function (url, params) {
	return new Promise((resolve, reject) => {
		axios.put(url, params).then(res => {
			resolve(res);
		}).catch(err => {
			reject(err);
		});
	});
};


// 请求示例
// requestName 为多余的参数 作为请求的标识，下次发起相同的请求，就会自动取消上一次还没有结束的请求
// 比如正常的请求参数只有一个 name: '123'，但是这里我们需要额外再加上一个 requestName
/**
    this.$post(url, { name: '123', requestName: 'post_1' })
        .then(res => {
            console.log(`请求成功：${res}`)
        })
 */
export default axios;
