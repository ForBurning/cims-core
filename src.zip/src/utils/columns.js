import enums from '@/utils/enums';


const columns = {
	Select: {
		type: 'selection',
		width: 50,
		align: 'center'
	},
	RequestCode: title => ({
		slot: 'RequestCode',
		title: title,
		width: 125
	}),
	MaterielNumber: title => ({
		key: 'MaterielNumber',
		title: title
	}),
	number: title => ({
		key: 'Number',
		title: title,
	}),
	Price: title => ({
		key: 'Price',
		title: title,
	}),
	Applicant: title => ({
		key: 'Applicant',
		title: title,
	}),
	ProcurementScheduleStatus: title => ({
		key: 'ProcurementScheduleStatusDescription',
		title: title
	}),
	EstimatedArrival: title => ({
		key: 'EstimatedArrival',
		title: title
	}),
	TotalPrice: title => ({
		key: 'TotalPrice',
		title: title + '(￥)'
	}),
	CASNumber: title => ({
		key: 'CASNumber',
		title: title
	}),
	CategoryCode: title => ({
		key: "CategoryCode",
		title: title,
	}),
	CategoryName: title => ({
		key: "CategoryName",
		title: title,
	}),
	Barcode: title => ({
		key: "Barcode",
		title: title,
		width: 120
	}),
	BottleName: title => ({
		key: "BottleName",
		title: title,
		tooltip: true
	}),
	ChinName: title => ({
		slot: "ChinName",
		title: title,
		tooltip: true
	}),
	chinName: title => ({
		key: "ChinName",
		title: title,
		tooltip: true
	}),
	Purity: title => ({
		key: "Purity",
		title: title,
		width: 110
	}),
	RequestQuantity: title => ({
		key: "RequestQuantity",
		title: title,
		width1: 80,
		render: (h, params) => {
			return h('div', params.row.RequestQuantity + params.row.RequestUnit)
		}
	}),
	Requester: title => ({
		key: "Requester",
		title: title,
		width: 110
	}),
	EstimatedAmount: title => ({
		key: "EstimatedAmount",
		title: title,
		width1: 80,
		render: (h, params) => {
			return h('div', params.row.EstimatedAmount + params.row.RequestUnit)
		}
	}),
	InitialQuantity: title => ({
		key: "InitialQuantity",
		title: title,
		render: (h, params) => {
			return h('div', params.row.InitialQuantity + params.row.Unit);
		}
	}),
	CurrentQuantity: title => ({
		key: "CurrentQuantity",
		title: title,
	}),
	ProjectCode: title => ({
		key: "ProjectCode",
		title: title,
		width1: 80,
	}),
	RequestDate: title => ({
		key: "RequestDate",
		title: title,
		width: 100,
		render: (h, params) => {
			return h('div', params.row.RequestDate ? params.row.RequestDate.split(' ')[0] : '')
		}
	}),
	ShowState: title => ({
		key: "ShowState",
		title: title,
		width1: 80,
	}),
	ApproveUser: title => ({
		key: "ApproveUser",
		title: title,
	}),
	ApproveTime: (title, width) => ({
		key: "ApproveTime",
		title: title,
		width: width || 100,
		render: (h, params) => {
			return h('div', params.row.ApproveTime ? params.row.ApproveTime.split(' ')[0] : '')
		}
	}),
	ApproveReason: title => ({
		key: "ApproveReason",
		title: title,
	}),
	ApplyTime: title => ({
		key: "ApplyTime",
		title: title,
		width: 90
	}),
	PurchaseCode: title => ({
		key: "PurchaseCode",
		title: title,
		width: 120
	}),
	CompleteTime: title => ({
		key: "CompleteTime",
		title: title,
		width: 100,
		render: (h, params) => {
			return h('div', params.row.CompleteTime ? params.row.CompleteTime.split(' ')[0] : '')
		}
	}),
	bfTime: title => ({
		key: "CompleteTime",
		title: title,
		width: 100,
		render: (h, params) => {
			return h('div', params.row.CompleteTime ? params.row.CompleteTime.split(' ')[0] : '')
		}
	}),
	tkComments: title => ({ 
		key: "Comments",
		title: title,
	}),
	bfComments: title => ({
		key: "Comments",
		title: title,
	}),
	Comment: title => ({
		key: "Comment",
		title: title,
	}),
	ApproveUsersNames: (title, width) => ({
		key: "ApproveUsersNames",
		title: title,
		width: width || 'auto',
		tooltip: true
	}),
	applicantApproveTime: title => ({
		key: "ApproveTime",
		title: title,
		width: 90,
	}),
	StorageLocation: title => ({
		key: "StorageLocation",
		title: title,
		width1: 80,
	}),
	Deliverer: title => ({
		key: "Deliverer",
		title: title,
		width1: 80,
	}),
	ExpectationPeriod: title => ({
		key: "ExpectationPeriod",
		title: title,
		width: 90,
	}),
	storeInfo: title => ({
		slot: "storeInfo",
		title: title,
		align: 'center'
	}),
	ReceiveDate: title => ({
		key: "ReceiveDate",
		title: title,
		width: 100,
		render: (h, params) => {
			let receiveDate = '';
			if (params.row.DeliveryFlag) {
				receiveDate = params.row.DeliveryFlag === 1 ? params.row.SelfReceiveDate.split(' ')[0] : params.row.ReceiveDate.split(' ')[0]
			}
			return h('div', receiveDate)
		}
	}),
	Action: title => ({
		slot: "Action",
		title: title,
		align: 'center',
		width: 200
	}),
	Action1: title => ({
		slot: "Action1",
		title: title,
		align: 'center',
		width: 100
	}),
	RequestAction: title => ({
		slot: "RequestAction",
		title: title,
		align: 'center',
		width: 70
	}),
	Radio: {
		slot: "Radio",
		title: " ",
		align: 'center',
		width: 70
	},
	Specifications: title => ({
		key: "Specifications",
		title: title,
	}),
	Lab: title => ({
		key: "Lab",
		title: title,
	}),
	Phone: title => ({
		key: "Phone",
		title: title,
	}),
	WarehouseName: title => ({
		key: "WarehouseName",
		title: title,
	}),
	ExpiryDate: title => ({
		key: "ExpiryDate",
		title: title,
	}),
	CreateUser: title => ({
		key: "CreateUser",
		title: title,
	}),
	CreateTime: title => ({
		key: "CreateTime",
		title: title,
	}),
	BottleType: title => ({
		key: "bottleType",
		title: title,
	}),
	Supplier: title => ({
		key: "Supplier",
		title: title,
	}),
	PONumber: title => ({
		key: "PONumber",
		title: title,
	}),
	LotNumber: title => ({
		key: "LotNumber",
		title: title,
	}),
	Sublocation: title => ({
		key: "Sublocation",
		title: title,
	}),
	ApproveStateName: title => ({
		key: "ApproveStateName",
		title: title,
	}),
	UnitPrice: title => ({
		key: "UnitPrice",
		title: title,
		render: (h, params) => {
			return h("div", "￥" + params.row.UnitPrice);
		}
	}),
	IsSettleAccounts: (title, i18n) => ({
		key: "IsSettleAccounts",
		title: title,
		render: (h, params) => {
			return h('div', params.row.IsSettleAccounts ? i18n.t('columns.settle') : i18n.t('columns.notSettle'))
		}
	}),
}

export default columns
