const enums = {
    //领用状态
    requestStateTxt(i18n) {
        return {
            /// <summary>
            /// 已提交
            /// </summary>
            1: i18n.t('page.requestState1'),
            /// <summary>
            /// 待拣货
            /// </summary>
            19: i18n.t('page.requestState19'),
            /// <summary>
            /// 拣货中
            /// </summary>
            200: i18n.t('page.requestState200'),
            /// <summary>
            /// 已拣货待出库
            /// </summary>
            201: i18n.t('page.requestState201'),
            /// <summary>
            /// 已出库待自取
            /// </summary>
            300: i18n.t('page.requestState300'),
            /// <summary>
            /// 已出库待配送
            /// </summary>
            301: i18n.t('page.requestState301'),
            /// <summary>
            /// 配送中
            /// </summary>
            400: i18n.t('page.requestState400'),
            /// <summary>
            /// 已签收
            /// </summary>
            500: i18n.t('page.requestState500')
        }
    },
    requestsInfoType: {
        /// <summary>
        /// 我的领用
        /// </summary>
        MyRequests: "MyRequests",
        /// <summary>
        /// 待审批
        /// </summary>
        ApprovalPending: "ApprovalPending",
        /// <summary>
        /// 已审批
        /// </summary>
        CompleteApproval: "CompleteApproval",
        /// <summary>
        /// 待出库
        /// </summary>
        WaitingOutStock: "WaitingOutStock",
        /// <summary>
        /// 已出库
        /// </summary>
        OutStock: "OutStock",
        /// <summary>
        /// 已签收
        /// </summary>
        Receiving: "Receiving"
    },
    role: {
        //超级管理员
        ap: "ALL_PERMISSION",
        //管理员
        mp: "MANAGER_PERMISSION",
        //订单审批角色
        oa: "ORDER_APPROVE_PERMISSION",
        //领用员
        rp: "REQUEST_PERMISSION",
        //项目管理角色
        pmp: "PROJECT_MANAGER_PERMISSION",
        //申购员
        pp: "PURCHASE_PERMISSION",
        //库管员
        im: "IN_MANAGER"

    },
    //登录日志
    loginEnum: {
        /// <summary>
        /// 前台登录
        /// </summary>        
        LoginType: 0,
        /// <summary>
        /// 导入
        /// </summary>        
        LoginStatus: 0,
        /// <summary>
        /// 导入
        /// </summary>        
        LogoutStatus: 1,
    },
    procurementScheduleStatus: {
        //待提交
        Uncommitted: 0,
        //已提交
        Committed: 10,
        //待处理
        Pending: 20,
        //已处理
        Processed: 30,
        //已下单
        Placed: 40,
        //已到货
        Arrived: 50
    },
    errorMessage:{
        '未提供令牌或签名.': 'No token or signature provided.',
        '组织机构未在服务端登记或未被授权运用当前功能.': 'The organization is not registered or not authorized to use the current module.',
        '未授权或授权过期，请重新登录.': 'Unauthorized or expired, please login again.',
        '令牌未授权或授权过期，请重新登录.': 'The token is not authorized or the authorization expires, please log in again.',
        '帐号异地登录，请重新登录.': 'The account is logged in at another place, please log in again.',
        '令牌未授权或授权过期，请重新登录.': 'The token is not authorized or the authorization expires, please log in again.',
        '登录客户端无法识别，验证失败.': 'Login client is not recognized and authentication failed.',
        '签名未被许可或已经失效.': 'The signature is not licensed or has expired.',
        '签名错误.': 'Signature error.',
    }
}

export default enums
