import jscookie from "js-cookie"
import jsmd5 from "js-md5"
import Vue from 'vue'
import VueSession from 'vue-session'

Vue.use(VueSession)

const utils = {
	cookie: {
		set: (key, value, expires = 1) => {
			if (process.env.NODE_ENV == "development") {
				//开发环境
				jscookie.set(key, value, {
					expires: expires
				});
			} else {
				//生产环境
				jscookie.set(key, value, {
					expires: expires,
					domain: process.env.VUE_APP_domain
				});
			}
		},
		get(key) {
			return jscookie.getJSON(key);
		},
		remove: key => {
			if (process.env.NODE_ENV == "development") {
				//开发环境
				jscookie.remove(key)
			} else {
				//生产环境
				jscookie.remove(key, { domain: process.env.VUE_APP_domain })
			}
		}
	},
	/**
	 * @param {string} property 数据源
	 * @description 获取登录用户信息
	 */
	getUserInfo(property = 'id') {
		try {
			const accoundInfo = this.getUcInfo().AccountInfo;
			return property === 'id' ? accoundInfo.ID : property === 'name' ? accoundInfo.RealName : accoundInfo;
		} catch (e) {
			this.turnToLoginPage();
		}
	},
	/**
	 * @description 获取cims信息
	 * {
			"Token": "B0136D0D-41C3-4EF0-B79D-8BF5266E9B3A",
			"Identity": "004A286A-7E5C-4A8E-B3A8-ACA7EC4CC073",
			"OrgCode": "Org000023",
			"OrgName": "苏州创腾苏州办科技有限公司",
			"Logo": "/logo/Org000023/20181115101958.jpg",
			"ProductType": "UC",
			"LoginClient": "PC",
			"AccountInfo": {
				"ID": 3,
				"MobilePhone": "13781179110",
				"Email": "liyan.sz@neotrident.com",
				"RealName": "李彦",
				"Photo": "/photo/3/20180129152530.jpg",
				"RegTime": "2017-06-02 13:43:58",
				"LastLoginTime": "2019-01-14 15:43:24",
				"IsOrganAdmin": 1,
				"ReferralCode": null
			},
			"DeptInfo": {
				DeptId: 32,
				DeptName: "研发部",
				IsDeptHeader: 0
				
			}
		}
	 */
	getUcInfo() {
		const cookie = jscookie.getJSON(process.env.VUE_APP_uc_cookie);
		if (cookie) {
			return cookie;
		} else {
			this.turnToLoginPage();
		}
	},
	getDeptId() {
		try {
			const cimsCookie = this.getUcInfo();
			if (cimsCookie.DeptInfo) {
				return cimsCookie.DeptInfo.DeptId;
			} else {
				return 0
			}

		} catch (e) {
			this.turnToLoginPage();
		}
	},
	/**
	 * @description 获取cims信息
	 * cims: {
			"HasWebAuth": true,
			"HasBackAuth": true,
			"UserInfo": {
				"AccountId": 3,
				"RealName": "李彦",
				"IsLock": 0,
				"LabId": 29,
				"LabName": "公测实验室",
			},
			"RoleCodes": {
				"MANAGER": "管理员",
				"ORDERAPPROVE": "领用审批",
				"REQUEST": "领用员",
				"PURCHASE": "采购",
				"WAREHOUSEKEEPER": "库管员",
				"WASTEMANAGER": "废液管理员",
				"TEST": "测试111",
				"CHECK": "核查",
				"DELIVERY": "配送",
				"APPLY": "申购",
				"APPLYAPPROVE": "申购审批",
				"REPORTMANAGER": "报表管理员"
			}
		}
	 */
	getCimsInfo() {
		const cookie = jscookie.getJSON(process.env.VUE_APP_cims_cookie);
		if (cookie) {
			return cookie;
		} else {
			this.turnUserInfo();
		}
	},
	/**
	 * @description 获取时间戳
	 */
	getTimesamp() {
		let xhr = null;
		if (window.XMLHttpRequest) {
			xhr = new window.XMLHttpRequest();
		} else {
			xhr = new ActiveObject("Microsoft");
		}
		xhr.open("GET", "/?v=" + new Date().getTime(), false);
		xhr.send(null);
		let date = xhr.getResponseHeader("Date");
		return new Date(date).getTime() / 1000 + 121;
	},
	/**
	 * @description 获取年月日对应的时间戳
	 */
	getDateTimesamp() {
		const date = new Date();

		return new Date([data.getFullYear(), data.getMonth(), data.getDate()].join('-')).getTime() / 1000 + 121;
	},
	/**
	 * 计算本月第一天 
	 * @obj {null} 无
	 * @return 上周的时间 
	 */
	getFirstdayOfMonth() {
		var myDate = new Date(),
			year = myDate.getFullYear(),
			month = myDate.getMonth() + 1;

		if (month < 10) {
			month = "0" + month;
		}

		var currentDate = year + "-" + month + "-01";
		return currentDate;
	},
	/**
	 * @description 生成header
	 */
	getHeader() {
		try {
			let cookie = this.getUcInfo();
			let timeSamp = this.getTimesamp();
			let token = cookie.Token,
				uid = cookie.AccountInfo.ID;
			let Signature = jsmd5([token, uid, timeSamp].join("").split("").sort().join("")).toUpperCase();
			return {
				Token: token,
				Uid: uid,
				Identity: cookie.Identity,
				Organ: cookie.OrgCode,
				ProductType: process.env.VUE_APP_productType,
				LoginClient: process.env.VUE_APP_loginClient,
				Timesamp: timeSamp,
				Signature: Signature
			}
		} catch (e) {
			this.turnToLoginPage();
		}

	},
	/**
	 * @param {object} obj 源数组
	 * @description 深拷贝
	 */
	deepCopy(obj) {
		let objClone = Array.isArray(obj) ? [] : {};
		if (obj && typeof obj === "object") {
			for (let key in obj) {
				if (obj.hasOwnProperty(key)) {
					//判断ojb子元素是否为对象，如果是，递归复制
					if (obj[key] && typeof obj[key] === "object") {
						objClone[key] = this.deepCopy(obj[key]);
					} else {
						//如果不是，简单复制
						objClone[key] = obj[key];
					}
				}
			}
		}
		return objClone;
	},
	/**
	 * @description 睡眠，单位毫秒
	 */
	sleep(ms) {
		return new Promise(resolve => setTimeout(resolve, ms));
	},
	/**
	 * @param {String} key URL参数
	 * @description 从URL中获取参数值
	 */
	getParams(key) {
		const url = window.location.search;
		let paramVal = "";
		if (!url) {
			return paramVal;
		}

		const keyValueArr = url.split('?')[1].split('&');

		keyValueArr.forEach(item => {
			const keyValue = item.split('=');
			if (keyValue[0] === key) {
				paramVal = keyValue[1];
			}
		})
		return decodeURIComponent(paramVal)
	},
	/**
	 * @description 滚动到顶部
	 */
	scrollTop() {
		if (!window.requestAnimationFrame) {
			window.requestAnimationFrame = (
				window.webkitRequestAnimationFrame ||
				window.mozRequestAnimationFrame ||
				window.msRequestAnimationFrame ||
				function (callback) {
					return window.setTimeout(callback, 1000 / 60)
				}
			)
		}
		const difference = Math.abs(from - to)
		const step = Math.ceil(difference / duration * 50)

		const scroll = (start, end, step) => {
			if (start === end) {
				endCallback && endCallback()
				return
			}

			let d = (start + step > end) ? end : start + step
			if (start > end) {
				d = (start - step < end) ? end : start - step
			}

			if (el === window) {
				window.scrollTo(d, d)
			} else {
				el.scrollTop = d
			}
			window.requestAnimationFrame(() => scroll(d, end, step))
		}
		scroll(from, to, step)

	},
	/**
	 * @description 计算当前的时间
	 */
	getcurDate() {
		let myDate = new Date(),
			year = myDate.getFullYear(),
			month = myDate.getMonth() + 1,
			dates = myDate.getDate();

		if (dates < 10) {
			dates = "0" + dates;
		}
		if (month < 10) {
			month = "0" + month;
		}

		let currentDate = year + "-" + month + "-" + dates;

		return currentDate;
	},
	/**
	 * @description 计算一周前的时间 
	 */
	getPrevWeek() {
		let d = new Date(),
			yesterday_milliseconds = d.getTime() - 7000 * 60 * 60 * 24,
			yesterday = new Date();

		yesterday.setTime(yesterday_milliseconds);

		let strYear = yesterday.getFullYear(),
			strDay = yesterday.getDate(),
			strMonth = yesterday.getMonth() + 1;

		if (strDay < 10) {
			strDay = "0" + strDay;
		}
		if (strMonth < 10) {
			strMonth = "0" + strMonth;
		}
		return strYear + "-" + strMonth + "-" + strDay;
	},
	/**
	 * @description 退出系统
	 */
	turnToLoginPage(isManualLogout) {
		jscookie.remove(process.env.VUE_APP_uc_cookie, {
			domain: process.env.VUE_APP_domain
		})
		jscookie.remove(process.env.VUE_APP_cims_cookie, {
			domain: process.env.VUE_APP_domain
		})
		jscookie.remove(process.env.VUE_APP_lastActionTime, {
			domain: process.env.VUE_APP_domain
		})
		jscookie.remove(process.env.VUE_APP_isScreenLocked, {
			domain: process.env.VUE_APP_domain
		})
		if (isManualLogout) {
			window.location.href = process.env.VUE_APP_login;
		} else {
			window.location.href = process.env.VUE_APP_login + "?redirect=" + document.URL;
		}
	},
	/**
	* @description 跳转到个人中心
	*/
	turnUserInfo() {
		jscookie.remove(process.env.VUE_APP_cims_cookie, {
			domain: process.env.VUE_APP_domain
		})
		window.location.href = process.env.VUE_APP_user_center;
	},
	/**
	 * @description 获取ketcher
	 */
	getKetcher() {
		let ketcherFrame = document.getElementById('ketcher-id');
		let ketcher = null;
		if ('contentDocument' in ketcherFrame)
			ketcher = ketcherFrame.contentWindow.ketcher;
		else // IE7
			ketcher = document.frames['ketcherFrame'].window.ketcher;
		return ketcher;
	},
	/**
	 * @description 获取Molfile
	 */
	getMolfile() {
		return this.getKetcher().getMolfile();
	},
	// 日期，在原有日期基础上，增加days天数，默认增加1天
	addDate(days = 1, date) {
		date = date ? new Date(date) : new Date();
		date.setDate(date.getDate() + days);
		const month = date.getMonth() + 1;
		const day = date.getDate();
		return date.getFullYear() + '-' + this.getFormatDate(month) + '-' + this.getFormatDate(day);
	},
	// 日期月份/天的显示，如果是1位数，则在前面加上'0'
	getFormatDate(arg) {
		if (arg == undefined || arg == '') {
			return '';
		}

		var re = arg + '';
		if (re.length < 2) {
			re = '0' + re;
		}

		return re;
	},
	//生成过效期
	isExpiry(iminentExpirationDay, date, expireDateState) {
		const curDate = new Date();
		const expiryDate = (new Date(this.addDate(iminentExpirationDay, date)));

		if (curDate > expiryDate) {
			return `<span class='wrong-date'>${expireDateState[0]}</span>`;
		} else if (curDate - expiryDate > iminentExpirationDay * 24 * 3600 * 1000) {
			return `<span class='normal-date'>${expireDateState[1]}</span>`;
		} else {
			return `<span class='right-date'>${expireDateState[2]}</span>`;
		}
	},
	//删除数组中指定下标的元素
	removeItem(data, id, key = 'ID') {
		data.map((item, index) => {
			if (item[key] === id) {
				data.splice(index, 1)
			}
		})
	},
	//页面权限判断
	isAccessPage(pageAccessRoles) {
		const roles = utils.getCimsInfo().RoleCodes;
		const userRoleKeys = Object.keys(roles);
		if (pageAccessRoles.some(key => userRoleKeys.includes(key))) {
			return true;
		}

		window.location.href = process.env.VUE_APP_prefix + '/noAuth';
	},
	//iframe的高度自适应
	fixedIframeHeight(id = 'materielframe') {
		var num = 0;
		var timer = setInterval(function () {
			var iframe = document.getElementById(id);
			try {
				var bHeight = iframe.contentWindow.document.body.scrollHeight;
				var dHeight = iframe.contentWindow.document.documentElement.scrollHeight;
				var height = Math.max(bHeight, dHeight);
				iframe.height = height;
				num++
				if (num === 4) {
					clearInterval(timer)
				}
			} catch (ex) { }
		}, 1000);
	},
	/**
	 * @description 生成header
	 */
	md5(str) {
		return str ? jsmd5(str) : '';
	},
	getSystemLanguage() {
		const ucCookie = this.cookie.get(process.env.VUE_APP_uc_cookie);
		let lang = null;
		if (ucCookie) {
			lang = ucCookie.Lang;
		}
		if (!lang) {
			lang = (navigator.language || navigator.browserLanguage).toLowerCase();
		}
		lang = lang.includes('zh') ? 'zh' : lang.includes('en') ? 'en' : 'zh';
		return lang;
	},
	//正整数
	isInteger(num) {
		return /(^[1-9]\d*$)/.test(num);
	},
	//正数
	isPositive(num) {
		return Number(num) > 0;
	},
	//图片路径增加随机数
	addRandom2Url(url) {
		return url.replace(/#/g, '%23') + '?v=' + Math.random();
	}
}



export default utils
